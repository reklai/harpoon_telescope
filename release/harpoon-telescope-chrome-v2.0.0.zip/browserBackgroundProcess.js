"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/esBuildBundle/browserBackgroundProcess/browserBackgroundProcess.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/shared/keybindings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var MAX_TAB_MANAGER_SLOTS = 4;
  var MAX_SESSIONS = 4;
  var DEFAULT_KEYBINDINGS = {
    navigationMode: "basic",
    bindings: {
      global: {
        openTabManager: { key: "Alt+T", default: "Alt+T" },
        addTab: { key: "Alt+Shift+T", default: "Alt+Shift+T" },
        jumpSlot1: { key: "Alt+1", default: "Alt+1" },
        jumpSlot2: { key: "Alt+2", default: "Alt+2" },
        jumpSlot3: { key: "Alt+3", default: "Alt+3" },
        jumpSlot4: { key: "Alt+4", default: "Alt+4" },
        cyclePrev: { key: "Alt+-", default: "Alt+-" },
        cycleNext: { key: "Alt+=", default: "Alt+=" },
        searchInPage: { key: "Alt+F", default: "Alt+F" },
        openFrecency: { key: "Alt+Shift+F", default: "Alt+Shift+F" },
        openBookmarks: { key: "Alt+B", default: "Alt+B" },
        addBookmark: { key: "Alt+Shift+B", default: "Alt+Shift+B" },
        openHistory: { key: "Alt+Y", default: "Alt+Y" },
        openHelp: { key: "Alt+M", default: "Alt+M" },
        toggleVim: { key: "Alt+V", default: "Alt+V" }
      },
      tabManager: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        remove: { key: "D", default: "D" },
        swap: { key: "W", default: "W" },
        saveSession: { key: "S", default: "S" },
        loadSession: { key: "L", default: "L" },
        close: { key: "Escape", default: "Escape" }
      },
      search: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        switchPane: { key: "Tab", default: "Tab" },
        accept: { key: "Enter", default: "Enter" },
        close: { key: "Escape", default: "Escape" }
      }
    }
  };
  async function loadKeybindings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get("keybindings");
      if (data.keybindings) {
        return mergeWithDefaults(data.keybindings);
      }
    } catch (_) {
    }
    return JSON.parse(JSON.stringify(DEFAULT_KEYBINDINGS));
  }
  async function saveKeybindings(config) {
    await import_webextension_polyfill.default.storage.local.set({ keybindings: config });
  }
  function mergeWithDefaults(stored) {
    const merged = JSON.parse(
      JSON.stringify(DEFAULT_KEYBINDINGS)
    );
    merged.navigationMode = stored.navigationMode || "basic";
    for (const scope of Object.keys(merged.bindings)) {
      if (!stored.bindings?.[scope]) continue;
      for (const action of Object.keys(merged.bindings[scope])) {
        const storedBinding = stored.bindings[scope]?.[action];
        if (storedBinding) {
          merged.bindings[scope][action].key = storedBinding.key;
        }
      }
    }
    return merged;
  }

  // src/lib/shared/frecencyScoring.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var MAX_FRECENCY_ENTRIES = 50;
  var frecencyMap = /* @__PURE__ */ new Map();
  var frecencyLoaded = false;
  async function ensureFrecencyLoaded() {
    if (!frecencyLoaded) {
      const data = await import_webextension_polyfill2.default.storage.local.get("frecencyData");
      const arr = data.frecencyData || [];
      frecencyMap = new Map(arr.map((e) => [e.tabId, e]));
      frecencyLoaded = true;
    }
  }
  async function saveFrecency() {
    await import_webextension_polyfill2.default.storage.local.set({
      frecencyData: Array.from(frecencyMap.values())
    });
  }
  function computeFrecencyScore(entry) {
    const age = Date.now() - entry.lastVisit;
    const MINUTE = 6e4;
    const HOUR = 36e5;
    const DAY = 864e5;
    const WEEK = 6048e5;
    let recencyWeight;
    if (age < 4 * MINUTE) recencyWeight = 100;
    else if (age < HOUR) recencyWeight = 70;
    else if (age < DAY) recencyWeight = 50;
    else if (age < WEEK) recencyWeight = 30;
    else recencyWeight = 10;
    return entry.visitCount * recencyWeight;
  }
  async function recordFrecencyVisit(tab) {
    await ensureFrecencyLoaded();
    if (!tab.id) return;
    const existing = frecencyMap.get(tab.id);
    if (existing) {
      existing.visitCount++;
      existing.lastVisit = Date.now();
      existing.url = tab.url || existing.url;
      existing.title = tab.title || existing.title;
      existing.frecencyScore = computeFrecencyScore(existing);
    } else {
      const entry = {
        tabId: tab.id,
        url: tab.url || "",
        title: tab.title || "",
        visitCount: 1,
        lastVisit: Date.now(),
        frecencyScore: 100
        // first visit = 1 * 100 recency weight
      };
      frecencyMap.set(tab.id, entry);
      if (frecencyMap.size > MAX_FRECENCY_ENTRIES) {
        let lowestId = null;
        let lowestScore = Infinity;
        for (const [id, e] of frecencyMap) {
          if (e.frecencyScore < lowestScore) {
            lowestScore = e.frecencyScore;
            lowestId = id;
          }
        }
        if (lowestId !== null) frecencyMap.delete(lowestId);
      }
    }
    await saveFrecency();
  }
  async function getFrecencyList() {
    await ensureFrecencyLoaded();
    const tabs = await import_webextension_polyfill2.default.tabs.query({ currentWindow: true });
    const tabIds = new Set(tabs.map((t) => t.id));
    for (const id of frecencyMap.keys()) {
      if (!tabIds.has(id)) frecencyMap.delete(id);
    }
    const entries = tabs.map((t) => {
      const existing = frecencyMap.get(t.id);
      if (existing) {
        existing.url = t.url || existing.url;
        existing.title = t.title || existing.title;
        existing.frecencyScore = computeFrecencyScore(existing);
        return { ...existing };
      }
      return {
        tabId: t.id,
        url: t.url || "",
        title: t.title || "",
        visitCount: 0,
        lastVisit: 0,
        frecencyScore: 0
      };
    });
    entries.sort((a, b) => b.frecencyScore - a.frecencyScore);
    return entries;
  }
  async function removeFrecencyEntry(tabId) {
    await ensureFrecencyLoaded();
    if (frecencyMap.delete(tabId)) await saveFrecency();
  }

  // src/lib/shared/sessions.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  async function sessionSave(state, name) {
    await state.ensureLoaded();
    if (state.getList().length === 0) {
      return { ok: false, reason: "Cannot save empty tab manager list" };
    }
    const sessionEntries = state.getList().map((e) => ({
      url: e.url,
      title: e.title,
      scrollX: e.scrollX,
      scrollY: e.scrollY
    }));
    const session = {
      name,
      entries: sessionEntries,
      savedAt: Date.now()
    };
    const stored = await import_webextension_polyfill3.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const nameTaken = sessions.some((s) => s.name.toLowerCase() === name.toLowerCase());
    if (nameTaken) {
      return { ok: false, reason: `"${name}" already exists` };
    }
    if (sessions.length >= MAX_SESSIONS) {
      return { ok: false, reason: `Max ${MAX_SESSIONS} sessions \u2014 delete one first` };
    }
    sessions.push(session);
    await import_webextension_polyfill3.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionList() {
    const stored = await import_webextension_polyfill3.default.storage.local.get("tabManagerSessions");
    return stored.tabManagerSessions || [];
  }
  async function sessionLoad(state, name) {
    const stored = await import_webextension_polyfill3.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((s) => s.name === name);
    if (!session) return { ok: false, reason: "Session not found" };
    const newList = [];
    for (const entry of session.entries) {
      try {
        const tab = await import_webextension_polyfill3.default.tabs.create({ url: entry.url, active: false });
        newList.push({
          tabId: tab.id,
          url: entry.url,
          title: entry.title,
          scrollX: entry.scrollX,
          scrollY: entry.scrollY,
          slot: newList.length + 1
        });
        if (entry.scrollX || entry.scrollY) {
          state.queueScrollRestore(tab.id, entry.scrollX, entry.scrollY);
        }
      } catch (_) {
      }
    }
    state.setList(newList);
    state.recompactSlots();
    await state.save();
    if (newList.length > 0) {
      await import_webextension_polyfill3.default.tabs.update(newList[0].tabId, { active: true });
    }
    return { ok: true, count: newList.length };
  }
  async function sessionRename(oldName, newName) {
    const trimmed = newName.trim();
    if (!trimmed) return { ok: false, reason: "Name cannot be empty" };
    const stored = await import_webextension_polyfill3.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((s) => s.name === oldName);
    if (!session) return { ok: false, reason: "Session not found" };
    const nameTaken = sessions.some(
      (s) => s.name !== oldName && s.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (nameTaken) return { ok: false, reason: `"${trimmed}" already exists` };
    session.name = trimmed;
    await import_webextension_polyfill3.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionUpdate(state, name) {
    await state.ensureLoaded();
    if (state.getList().length === 0) {
      return { ok: false, reason: "Cannot update \u2014 tab manager list is empty" };
    }
    const stored = await import_webextension_polyfill3.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const session = sessions.find((s) => s.name === name);
    if (!session) return { ok: false, reason: "Session not found" };
    session.entries = state.getList().map((e) => ({
      url: e.url,
      title: e.title,
      scrollX: e.scrollX,
      scrollY: e.scrollY
    }));
    session.savedAt = Date.now();
    await import_webextension_polyfill3.default.storage.local.set({ tabManagerSessions: sessions });
    return { ok: true };
  }
  async function sessionDelete(name) {
    const stored = await import_webextension_polyfill3.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    const filtered = sessions.filter((s) => s.name !== name);
    await import_webextension_polyfill3.default.storage.local.set({ tabManagerSessions: filtered });
    return { ok: true };
  }

  // src/esBuildBundle/browserBackgroundProcess/browserBackgroundProcess.ts
  var tabManagerList = [];
  var tabManagerLoaded = false;
  async function ensureTabManagerLoaded() {
    if (!tabManagerLoaded) {
      const data = await import_webextension_polyfill4.default.storage.local.get("tabManagerList");
      tabManagerList = data.tabManagerList || [];
      tabManagerLoaded = true;
    }
  }
  async function saveTabManager() {
    await import_webextension_polyfill4.default.storage.local.set({ tabManagerList });
  }
  async function reconcileTabManager() {
    await ensureTabManagerLoaded();
    const tabs = await import_webextension_polyfill4.default.tabs.query({});
    const tabIds = new Set(tabs.map((t) => t.id));
    for (const entry of tabManagerList) {
      entry.closed = !tabIds.has(entry.tabId);
    }
    recompactSlots();
    await saveTabManager();
  }
  function recompactSlots() {
    tabManagerList.forEach((entry, i) => {
      entry.slot = i + 1;
    });
  }
  var tabManagerState = {
    getList: () => tabManagerList,
    setList: (list) => {
      tabManagerList = list;
    },
    recompactSlots,
    save: saveTabManager,
    ensureLoaded: ensureTabManagerLoaded,
    queueScrollRestore: (tabId, scrollX, scrollY) => {
      pendingScrollRestore.set(tabId, { scrollX, scrollY });
    }
  };
  var pendingScrollRestore = /* @__PURE__ */ new Map();
  async function tabManagerAdd(tab) {
    await reconcileTabManager();
    if (tabManagerList.length >= MAX_TAB_MANAGER_SLOTS) {
      try {
        await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, {
          type: "TAB_MANAGER_FULL_FEEDBACK",
          max: MAX_TAB_MANAGER_SLOTS
        });
      } catch (_) {
      }
      return { ok: false, reason: `Tab Manager list is full (max ${MAX_TAB_MANAGER_SLOTS}).` };
    }
    const existing = tabManagerList.find(
      (e) => e.tabId === tab.id || e.url === tab.url
    );
    if (existing) {
      if (existing.closed && existing.url === tab.url) {
        existing.tabId = tab.id;
        existing.closed = false;
        existing.title = tab.title || existing.title;
        await saveTabManager();
      }
      try {
        await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, {
          type: "TAB_MANAGER_ADDED_FEEDBACK",
          slot: existing.slot,
          title: tab.title,
          alreadyAdded: true
        });
      } catch (_) {
      }
      return { ok: false, reason: "Tab already in Tab Manager list." };
    }
    let scrollX = 0;
    let scrollY = 0;
    try {
      const response = await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, {
        type: "GET_SCROLL"
      });
      scrollX = response.scrollX || 0;
      scrollY = response.scrollY || 0;
    } catch (_) {
    }
    const slot = tabManagerList.length + 1;
    tabManagerList.push({
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || "",
      scrollX,
      scrollY,
      slot
    });
    await saveTabManager();
    try {
      await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, {
        type: "TAB_MANAGER_ADDED_FEEDBACK",
        slot,
        title: tab.title
      });
    } catch (_) {
    }
    return { ok: true, slot };
  }
  async function tabManagerRemove(tabId) {
    await ensureTabManagerLoaded();
    tabManagerList = tabManagerList.filter((e) => e.tabId !== tabId);
    recompactSlots();
    await saveTabManager();
  }
  async function tabManagerJump(slot) {
    await ensureTabManagerLoaded();
    const entry = tabManagerList.find((e) => e.slot === slot);
    if (!entry) return;
    if (entry.closed) {
      await saveCurrentTabScroll();
      try {
        const newTab = await import_webextension_polyfill4.default.tabs.create({ url: entry.url, active: true });
        entry.tabId = newTab.id;
        entry.closed = false;
        await saveTabManager();
        if (entry.scrollX || entry.scrollY) {
          pendingScrollRestore.set(newTab.id, { scrollX: entry.scrollX, scrollY: entry.scrollY });
        }
      } catch (_) {
        tabManagerList = tabManagerList.filter((e) => e.slot !== slot);
        recompactSlots();
        await saveTabManager();
      }
      return;
    }
    const [, switchResult] = await Promise.all([
      saveCurrentTabScroll(),
      import_webextension_polyfill4.default.tabs.update(entry.tabId, { active: true }).catch(() => null)
    ]);
    if (!switchResult) {
      entry.closed = true;
      await saveTabManager();
      await tabManagerJump(slot);
      return;
    }
    import_webextension_polyfill4.default.tabs.sendMessage(entry.tabId, {
      type: "SET_SCROLL",
      scrollX: entry.scrollX,
      scrollY: entry.scrollY
    }).catch(() => {
    });
  }
  async function saveCurrentTabScroll() {
    await ensureTabManagerLoaded();
    const [activeTab] = await import_webextension_polyfill4.default.tabs.query({
      active: true,
      currentWindow: true
    });
    if (!activeTab) return;
    const entry = tabManagerList.find((e) => e.tabId === activeTab.id);
    if (!entry || entry.closed) return;
    try {
      const response = await import_webextension_polyfill4.default.tabs.sendMessage(activeTab.id, {
        type: "GET_SCROLL"
      });
      entry.scrollX = response.scrollX || 0;
      entry.scrollY = response.scrollY || 0;
      await saveTabManager();
    } catch (_) {
    }
  }
  var lastActiveTabId = null;
  import_webextension_polyfill4.default.tabs.onRemoved.addListener(async (tabId) => {
    await ensureTabManagerLoaded();
    const entry = tabManagerList.find((e) => e.tabId === tabId);
    if (entry) {
      entry.closed = true;
      await saveTabManager();
    }
    await removeFrecencyEntry(tabId);
  });
  var onUpdatedSaveTimer = null;
  import_webextension_polyfill4.default.tabs.onUpdated.addListener(
    async (tabId, changeInfo) => {
      await ensureTabManagerLoaded();
      const entry = tabManagerList.find((e) => e.tabId === tabId);
      if (entry) {
        let changed = false;
        if (changeInfo.url) {
          entry.url = changeInfo.url;
          changed = true;
        }
        if (changeInfo.title) {
          entry.title = changeInfo.title;
          changed = true;
        }
        if (changed) {
          if (onUpdatedSaveTimer) clearTimeout(onUpdatedSaveTimer);
          onUpdatedSaveTimer = setTimeout(() => {
            onUpdatedSaveTimer = null;
            saveTabManager();
          }, 500);
        }
      }
    }
  );
  import_webextension_polyfill4.default.tabs.onActivated.addListener(
    async (activeInfo) => {
      const prevTabId = lastActiveTabId;
      lastActiveTabId = activeInfo.tabId;
      try {
        const tab = await import_webextension_polyfill4.default.tabs.get(activeInfo.tabId);
        await recordFrecencyVisit(tab);
      } catch (_) {
      }
      if (prevTabId === null) return;
      await ensureTabManagerLoaded();
      const entry = tabManagerList.find((e) => e.tabId === prevTabId);
      if (!entry || entry.closed) return;
      try {
        const response = await import_webextension_polyfill4.default.tabs.sendMessage(prevTabId, {
          type: "GET_SCROLL"
        });
        entry.scrollX = response.scrollX || 0;
        entry.scrollY = response.scrollY || 0;
        await saveTabManager();
      } catch (_) {
      }
    }
  );
  async function grepCurrentTab(query, filters = []) {
    const [tab] = await import_webextension_polyfill4.default.tabs.query({
      active: true,
      currentWindow: true
    });
    if (!tab) return [];
    try {
      return await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, {
        type: "GREP",
        query,
        filters
      });
    } catch (_) {
      return [];
    }
  }
  async function getPageContent(tabId) {
    try {
      return await import_webextension_polyfill4.default.tabs.sendMessage(tabId, {
        type: "GET_CONTENT"
      });
    } catch (_) {
      return { text: "", lines: [] };
    }
  }
  var bookmarkUsageMap = {};
  var bookmarkUsageLoaded = false;
  async function ensureBookmarkUsageLoaded() {
    if (!bookmarkUsageLoaded) {
      const data = await import_webextension_polyfill4.default.storage.local.get("bookmarkUsage");
      bookmarkUsageMap = data.bookmarkUsage || {};
      bookmarkUsageLoaded = true;
    }
  }
  async function saveBookmarkUsage() {
    await import_webextension_polyfill4.default.storage.local.set({ bookmarkUsage: bookmarkUsageMap });
  }
  function computeBookmarkUsageScore(usage) {
    if (!usage) return 0;
    const ageMs = Date.now() - usage.lastVisit;
    const ageMin = ageMs / 6e4;
    let weight;
    if (ageMin < 240) weight = 100;
    else if (ageMin < 1440) weight = 70;
    else if (ageMin < 10080) weight = 50;
    else if (ageMin < 43200) weight = 30;
    else weight = 10;
    return Math.round(usage.visitCount * weight);
  }
  async function recordBookmarkVisit(url) {
    await ensureBookmarkUsageLoaded();
    const existing = bookmarkUsageMap[url];
    if (existing) {
      existing.visitCount++;
      existing.lastVisit = Date.now();
    } else {
      bookmarkUsageMap[url] = { visitCount: 1, lastVisit: Date.now() };
    }
    await saveBookmarkUsage();
  }
  async function getBookmarkList() {
    await ensureBookmarkUsageLoaded();
    const tree = await import_webextension_polyfill4.default.bookmarks.getTree();
    const results = [];
    function walk(nodes, parentTitle, parentPath, parentId) {
      for (const node of nodes) {
        if (node.url) {
          const usage = bookmarkUsageMap[node.url];
          results.push({
            id: node.id,
            url: node.url,
            title: node.title || "",
            dateAdded: node.dateAdded,
            parentId,
            parentTitle,
            folderPath: parentPath,
            usageScore: usage ? computeBookmarkUsageScore(usage) : 0
          });
        }
        if (node.children) {
          const newTitle = node.title || parentTitle;
          const newPath = node.title ? parentPath ? parentPath + " \u203A " + node.title : node.title : parentPath;
          walk(node.children, newTitle, newPath, node.id);
        }
      }
    }
    walk(tree);
    results.sort((a, b) => {
      if ((a.usageScore || 0) !== (b.usageScore || 0)) {
        return (b.usageScore || 0) - (a.usageScore || 0);
      }
      return (b.dateAdded || 0) - (a.dateAdded || 0);
    });
    return results;
  }
  async function getBookmarkFolders() {
    const tree = await import_webextension_polyfill4.default.bookmarks.getTree();
    const folders = [];
    function walk(nodes, depth) {
      for (const node of nodes) {
        if (!node.url && node.children) {
          const folder = {
            id: node.id,
            title: node.title || "(root)",
            depth,
            children: []
          };
          const subFolders = [];
          for (const child of node.children) {
            if (!child.url && child.children) {
              walkInto(child, depth + 1, subFolders);
            }
          }
          folder.children = subFolders;
          folders.push(folder);
        }
      }
    }
    function walkInto(node, depth, target) {
      const folder = {
        id: node.id,
        title: node.title || "(unnamed)",
        depth,
        children: []
      };
      if (node.children) {
        for (const child of node.children) {
          if (!child.url && child.children) {
            walkInto(child, depth + 1, folder.children);
          }
        }
      }
      target.push(folder);
    }
    walk(tree, 0);
    return folders;
  }
  import_webextension_polyfill4.default.commands.onCommand.addListener(async (command) => {
    const [activeTab] = await import_webextension_polyfill4.default.tabs.query({
      active: true,
      currentWindow: true
    });
    if (!activeTab) return;
    switch (command) {
      case "open-search-current":
        try {
          await import_webextension_polyfill4.default.tabs.sendMessage(activeTab.id, {
            type: "OPEN_SEARCH_CURRENT_PAGE"
          });
        } catch (_) {
        }
        break;
      case "open-tab-manager":
        try {
          await import_webextension_polyfill4.default.tabs.sendMessage(activeTab.id, {
            type: "OPEN_TAB_MANAGER"
          });
        } catch (_) {
        }
        break;
      case "tab-manager-add":
        await tabManagerAdd(activeTab);
        break;
      case "tab-manager-tab-1":
        await tabManagerJump(1);
        break;
      case "tab-manager-tab-2":
        await tabManagerJump(2);
        break;
      case "tab-manager-tab-3":
        await tabManagerJump(3);
        break;
      case "tab-manager-tab-4":
        await tabManagerJump(4);
        break;
    }
  });
  import_webextension_polyfill4.default.runtime.onMessage.addListener(
    async (msg, sender) => {
      const m = msg;
      switch (m.type) {
        case "GREP_CURRENT":
          return await grepCurrentTab(m.query, m.filters || []);
        case "GET_PAGE_CONTENT":
          return await getPageContent(m.tabId);
        case "TAB_MANAGER_ADD": {
          const [tab] = await import_webextension_polyfill4.default.tabs.query({
            active: true,
            currentWindow: true
          });
          return await tabManagerAdd(tab);
        }
        case "TAB_MANAGER_REMOVE":
          await tabManagerRemove(m.tabId);
          return { ok: true };
        case "TAB_MANAGER_LIST":
          await reconcileTabManager();
          return tabManagerList;
        case "TAB_MANAGER_JUMP":
          await tabManagerJump(m.slot);
          return { ok: true };
        case "TAB_MANAGER_CYCLE": {
          await ensureTabManagerLoaded();
          if (tabManagerList.length === 0) return { ok: false };
          const [curTab] = await import_webextension_polyfill4.default.tabs.query({
            active: true,
            currentWindow: true
          });
          const curIdx = curTab ? tabManagerList.findIndex((e) => e.tabId === curTab.id) : -1;
          const dir = m.direction;
          let targetIdx;
          if (curIdx === -1) {
            targetIdx = dir === "next" ? 0 : tabManagerList.length - 1;
          } else {
            targetIdx = dir === "next" ? (curIdx + 1) % tabManagerList.length : (curIdx - 1 + tabManagerList.length) % tabManagerList.length;
          }
          await tabManagerJump(tabManagerList[targetIdx].slot);
          return { ok: true };
        }
        case "TAB_MANAGER_SAVE_SCROLL":
          await saveCurrentTabScroll();
          return { ok: true };
        case "TAB_MANAGER_REORDER":
          await ensureTabManagerLoaded();
          tabManagerList = m.list;
          recompactSlots();
          await saveTabManager();
          return { ok: true };
        case "GET_CURRENT_TAB": {
          const [tab] = await import_webextension_polyfill4.default.tabs.query({
            active: true,
            currentWindow: true
          });
          return tab || null;
        }
        case "GET_KEYBINDINGS":
          return await loadKeybindings();
        case "SAVE_KEYBINDINGS":
          await saveKeybindings(m.config);
          return { ok: true };
        case "SWITCH_TO_TAB":
          try {
            await import_webextension_polyfill4.default.tabs.update(m.tabId, { active: true });
          } catch (_) {
          }
          return { ok: true };
        case "FRECENCY_LIST":
          return await getFrecencyList();
        case "BOOKMARK_LIST":
          return await getBookmarkList();
        case "HISTORY_LIST": {
          const maxResults = m.maxResults || 500;
          const text = m.text || "";
          const items = await import_webextension_polyfill4.default.history.search({
            text,
            maxResults,
            startTime: 0
          });
          const entries = items.filter((item) => item.url).map((item) => ({
            url: item.url,
            title: item.title || "",
            lastVisitTime: item.lastVisitTime || 0,
            visitCount: item.visitCount || 0
          }));
          entries.sort((a, b) => b.lastVisitTime - a.lastVisitTime);
          return entries;
        }
        case "OPEN_BOOKMARK_TAB": {
          const url = m.url;
          try {
            const tabs = await import_webextension_polyfill4.default.tabs.query({ currentWindow: true });
            const existing = tabs.find((t) => t.url === url);
            if (existing && existing.id) {
              await import_webextension_polyfill4.default.tabs.update(existing.id, { active: true });
            } else {
              await import_webextension_polyfill4.default.tabs.create({ url, active: true });
            }
            await recordBookmarkVisit(url);
          } catch (_) {
          }
          return { ok: true };
        }
        case "BOOKMARK_ADD": {
          const [tab] = await import_webextension_polyfill4.default.tabs.query({ active: true, currentWindow: true });
          if (!tab?.url) return { ok: false, reason: "No active tab" };
          try {
            const opts = {
              url: tab.url,
              title: tab.title || tab.url
            };
            if (m.parentId) {
              opts.parentId = m.parentId;
            }
            const created = await import_webextension_polyfill4.default.bookmarks.create(opts);
            return { ok: true, id: created.id, title: tab.title };
          } catch (_) {
            return { ok: false, reason: "Failed to create bookmark" };
          }
        }
        case "BOOKMARK_REMOVE": {
          try {
            await import_webextension_polyfill4.default.bookmarks.remove(m.id);
            if (m.url) {
              await ensureBookmarkUsageLoaded();
              delete bookmarkUsageMap[m.url];
              await saveBookmarkUsage();
            }
            return { ok: true };
          } catch (_) {
            return { ok: false, reason: "Failed to remove bookmark" };
          }
        }
        case "BOOKMARK_REMOVE_TREE": {
          try {
            await import_webextension_polyfill4.default.bookmarks.removeTree(m.id);
            return { ok: true };
          } catch (_) {
            return { ok: false, reason: "Failed to remove folder" };
          }
        }
        case "BOOKMARK_FOLDERS":
          return await getBookmarkFolders();
        case "BOOKMARK_CREATE_FOLDER": {
          try {
            const opts = {
              title: m.title
            };
            if (m.parentId) {
              opts.parentId = m.parentId;
            }
            const created = await import_webextension_polyfill4.default.bookmarks.create(opts);
            return { ok: true, title: m.title, id: created.id };
          } catch (_) {
            return { ok: false, reason: "Failed to create folder" };
          }
        }
        case "BOOKMARK_MOVE": {
          try {
            const dest = {};
            if (m.parentId) dest.parentId = m.parentId;
            await import_webextension_polyfill4.default.bookmarks.move(m.id, dest);
            return { ok: true };
          } catch (_) {
            return { ok: false, reason: "Failed to move bookmark" };
          }
        }
        case "CONTENT_SCRIPT_READY": {
          const tabId = sender.tab?.id;
          if (tabId == null) return { ok: true };
          const pending = pendingScrollRestore.get(tabId);
          if (pending) {
            pendingScrollRestore.delete(tabId);
            import_webextension_polyfill4.default.tabs.sendMessage(tabId, { type: "SET_SCROLL", scrollX: pending.scrollX, scrollY: pending.scrollY }).catch(() => {
            });
          }
          return { ok: true };
        }
        case "SESSION_SAVE":
          return await sessionSave(tabManagerState, m.name);
        case "SESSION_LIST":
          return await sessionList();
        case "SESSION_LOAD":
          return await sessionLoad(tabManagerState, m.name);
        case "SESSION_DELETE":
          return await sessionDelete(m.name);
        case "SESSION_RENAME":
          return await sessionRename(m.oldName, m.newName);
        case "SESSION_UPDATE":
          return await sessionUpdate(tabManagerState, m.name);
        default:
          return null;
      }
    }
  );
  ensureTabManagerLoaded();
  import_webextension_polyfill4.default.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (tab?.id) lastActiveTabId = tab.id;
  }).catch(() => {
  });
  import_webextension_polyfill4.default.runtime.onStartup.addListener(async () => {
    const stored = await import_webextension_polyfill4.default.storage.local.get("tabManagerSessions");
    const sessions = stored.tabManagerSessions || [];
    if (sessions.length === 0) return;
    await ensureTabManagerLoaded();
    tabManagerList = [];
    await saveTabManager();
    let attempts = 0;
    const tryPrompt = async () => {
      attempts++;
      const [tab] = await import_webextension_polyfill4.default.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) {
        if (attempts < 5) setTimeout(tryPrompt, 1e3);
        return;
      }
      try {
        await import_webextension_polyfill4.default.tabs.sendMessage(tab.id, {
          type: "SHOW_SESSION_RESTORE"
        });
      } catch (_) {
        if (attempts < 5) setTimeout(tryPrompt, 1e3);
      }
    };
    setTimeout(tryPrompt, 1500);
  });
})();
