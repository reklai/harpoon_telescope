"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache2 = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache2;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache2) {
                    return cache2[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache2, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache2[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache2) {
                    cache2[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache2, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache2, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill8 = __toESM(require_browser_polyfill());

  // src/lib/shared/keybindings.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var MAX_TAB_MANAGER_SLOTS = 4;
  var MAX_SESSIONS = 4;
  var DEFAULT_KEYBINDINGS = {
    navigationMode: "basic",
    bindings: {
      global: {
        openTabManager: { key: "Alt+T", default: "Alt+T" },
        addTab: { key: "Alt+Shift+T", default: "Alt+Shift+T" },
        jumpSlot1: { key: "Alt+1", default: "Alt+1" },
        jumpSlot2: { key: "Alt+2", default: "Alt+2" },
        jumpSlot3: { key: "Alt+3", default: "Alt+3" },
        jumpSlot4: { key: "Alt+4", default: "Alt+4" },
        cyclePrev: { key: "Alt+-", default: "Alt+-" },
        cycleNext: { key: "Alt+=", default: "Alt+=" },
        searchInPage: { key: "Alt+F", default: "Alt+F" },
        openFrecency: { key: "Alt+Shift+F", default: "Alt+Shift+F" },
        openBookmarks: { key: "Alt+B", default: "Alt+B" },
        addBookmark: { key: "Alt+Shift+B", default: "Alt+Shift+B" },
        openHistory: { key: "Alt+Y", default: "Alt+Y" },
        openHelp: { key: "Alt+M", default: "Alt+M" },
        toggleVim: { key: "Alt+V", default: "Alt+V" }
      },
      tabManager: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        jump: { key: "Enter", default: "Enter" },
        remove: { key: "D", default: "D" },
        swap: { key: "W", default: "W" },
        saveSession: { key: "S", default: "S" },
        loadSession: { key: "L", default: "L" },
        close: { key: "Escape", default: "Escape" }
      },
      search: {
        moveUp: { key: "ArrowUp", default: "ArrowUp" },
        moveDown: { key: "ArrowDown", default: "ArrowDown" },
        switchPane: { key: "Tab", default: "Tab" },
        accept: { key: "Enter", default: "Enter" },
        close: { key: "Escape", default: "Escape" }
      }
    }
  };
  var VIM_ENHANCED_ALIASES = {
    tabManager: {
      moveUp: ["K"],
      moveDown: ["J"]
    },
    search: {
      moveUp: ["K"],
      moveDown: ["J"]
    }
  };
  async function loadKeybindings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get("keybindings");
      if (data.keybindings) {
        return mergeWithDefaults(data.keybindings);
      }
    } catch (_) {
    }
    return JSON.parse(JSON.stringify(DEFAULT_KEYBINDINGS));
  }
  async function saveKeybindings(config) {
    await import_webextension_polyfill.default.storage.local.set({ keybindings: config });
  }
  function mergeWithDefaults(stored) {
    const merged = JSON.parse(
      JSON.stringify(DEFAULT_KEYBINDINGS)
    );
    merged.navigationMode = stored.navigationMode || "basic";
    for (const scope of Object.keys(merged.bindings)) {
      if (!stored.bindings?.[scope]) continue;
      for (const action of Object.keys(merged.bindings[scope])) {
        const storedBinding = stored.bindings[scope]?.[action];
        if (storedBinding) {
          merged.bindings[scope][action].key = storedBinding.key;
        }
      }
    }
    return merged;
  }
  var KEY_NAME_MAP = {
    ArrowUp: "ArrowUp",
    ArrowDown: "ArrowDown",
    ArrowLeft: "ArrowLeft",
    ArrowRight: "ArrowRight",
    " ": "Space",
    Escape: "Escape",
    Enter: "Enter",
    Tab: "Tab",
    Backspace: "Backspace",
    Delete: "Delete",
    PageUp: "PageUp",
    PageDown: "PageDown",
    Home: "Home",
    End: "End",
    Insert: "Insert"
  };
  var KEY_COMBO_CACHE = /* @__PURE__ */ new Map();
  function normalizeKeyName(keyName) {
    if (KEY_NAME_MAP[keyName]) return KEY_NAME_MAP[keyName];
    if (keyName.length === 1) return keyName.toUpperCase();
    return keyName;
  }
  function parseKeyCombo(keyString) {
    if (!keyString) return null;
    const cached = KEY_COMBO_CACHE.get(keyString);
    if (cached) return cached;
    const parts = keyString.split("+");
    if (parts.length === 0) return null;
    const parsed = {
      key: normalizeKeyName(parts[parts.length - 1]),
      ctrl: false,
      alt: false,
      shift: false,
      meta: false
    };
    for (let i = 0; i < parts.length - 1; i++) {
      if (parts[i] === "Ctrl") parsed.ctrl = true;
      else if (parts[i] === "Alt") parsed.alt = true;
      else if (parts[i] === "Shift") parsed.shift = true;
      else if (parts[i] === "Meta") parsed.meta = true;
    }
    KEY_COMBO_CACHE.set(keyString, parsed);
    return parsed;
  }
  function matchesKey(event, keyString) {
    const parsed = parseKeyCombo(keyString);
    if (!parsed) return false;
    if (event.ctrlKey !== parsed.ctrl) return false;
    if (event.altKey !== parsed.alt) return false;
    if (event.shiftKey !== parsed.shift) return false;
    if (event.metaKey !== parsed.meta) return false;
    return normalizeKeyName(event.key) === parsed.key;
  }
  function matchesAction(event, config, scope, action) {
    const scopeBindings = config.bindings[scope];
    const binding = scopeBindings?.[action];
    if (!binding) return false;
    if (matchesKey(event, binding.key)) return true;
    if (config.navigationMode !== "vim") return false;
    const vimAliases = VIM_ENHANCED_ALIASES[scope]?.[action];
    if (!vimAliases) return false;
    for (const alias of vimAliases) {
      if (matchesKey(event, alias)) return true;
    }
    return false;
  }
  function keyToDisplay(keyString) {
    if (!keyString) return "";
    return keyString.replace("ArrowUp", "\u2191").replace("ArrowDown", "\u2193").replace("ArrowLeft", "\u2190").replace("ArrowRight", "\u2192").replace("Escape", "Esc").replace("Delete", "Del").replace("Backspace", "Bksp");
  }

  // src/lib/searchCurrentPage/grep.ts
  var CONTEXT_LINES = 5;
  var MAX_RESULTS = 200;
  var SCORE_CONSECUTIVE = 8;
  var SCORE_WORD_BOUNDARY = 10;
  var SCORE_START = 6;
  var SCORE_BASE = 1;
  var PENALTY_DISTANCE = -1;
  var WORD_SEPARATORS = /* @__PURE__ */ new Set([" ", "-", "_", ".", "/", "\\", ":", "(", ")"]);
  var cache = {
    all: null,
    code: null,
    headings: null,
    links: null,
    images: null,
    observer: null,
    invalidateTimer: null
  };
  function invalidateCache() {
    cache.all = null;
    cache.code = null;
    cache.headings = null;
    cache.links = null;
    cache.images = null;
  }
  function initLineCache() {
    invalidateCache();
    if (cache.observer) cache.observer.disconnect();
    cache.observer = new MutationObserver(() => {
      if (cache.invalidateTimer) clearTimeout(cache.invalidateTimer);
      cache.invalidateTimer = setTimeout(invalidateCache, 500);
    });
    cache.observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }
  function destroyLineCache() {
    if (cache.observer) {
      cache.observer.disconnect();
      cache.observer = null;
    }
    if (cache.invalidateTimer) {
      clearTimeout(cache.invalidateTimer);
      cache.invalidateTimer = null;
    }
    invalidateCache();
  }
  function isVisible(el) {
    if (el === document.body) return true;
    if (!el.offsetParent && el.style.position !== "fixed" && el.style.position !== "sticky") {
      return false;
    }
    return true;
  }
  var HEADING_TAGS = /* @__PURE__ */ new Set(["H1", "H2", "H3", "H4", "H5", "H6"]);
  function findAncestorHeading(node) {
    let el = node instanceof Element ? node : node.parentElement;
    if (!el) return void 0;
    let cur = el;
    while (cur && cur !== document.body) {
      if (HEADING_TAGS.has(cur.tagName)) {
        return (cur.textContent || "").replace(/\s+/g, " ").trim() || void 0;
      }
      cur = cur.parentElement;
    }
    cur = el;
    while (cur && cur !== document.body) {
      let sib = cur.previousElementSibling;
      while (sib) {
        if (HEADING_TAGS.has(sib.tagName)) {
          return (sib.textContent || "").replace(/\s+/g, " ").trim() || void 0;
        }
        const headings = sib.querySelectorAll("h1, h2, h3, h4, h5, h6");
        if (headings.length > 0) {
          const last = headings[headings.length - 1];
          return (last.textContent || "").replace(/\s+/g, " ").trim() || void 0;
        }
        sib = sib.previousElementSibling;
      }
      cur = cur.parentElement;
    }
    return void 0;
  }
  function findHref(node) {
    let el = node instanceof Element ? node : node.parentElement;
    while (el && el !== document.body) {
      if (el.tagName === "A") {
        return el.href || void 0;
      }
      el = el.parentElement;
    }
    return void 0;
  }
  function getDomContext(node, matchText, tag) {
    const el = node instanceof Element ? node : node.parentElement;
    if (!el) return [matchText];
    if (tag === "PRE" || tag === "CODE") {
      let codeBlock = el;
      while (codeBlock && codeBlock.tagName !== "PRE" && codeBlock !== document.body) {
        codeBlock = codeBlock.parentElement;
      }
      if (codeBlock && codeBlock.tagName === "PRE") {
        const lines = (codeBlock.textContent || "").split("\n");
        const trimmedMatch = matchText.replace(/\s+/g, " ").trim();
        let matchIdx = -1;
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].replace(/\s+/g, " ").trim() === trimmedMatch) {
            matchIdx = i;
            break;
          }
        }
        if (matchIdx >= 0) {
          const start = Math.max(0, matchIdx - CONTEXT_LINES);
          const end = Math.min(lines.length, matchIdx + CONTEXT_LINES + 1);
          return lines.slice(start, end).map((l) => l.replace(/\t/g, "  "));
        }
        return lines.slice(0, CONTEXT_LINES * 2 + 1).map((l) => l.replace(/\t/g, "  "));
      }
    }
    const blockTags = /* @__PURE__ */ new Set([
      "P",
      "DIV",
      "SECTION",
      "ARTICLE",
      "BLOCKQUOTE",
      "LI",
      "TD",
      "TH",
      "FIGCAPTION",
      "DETAILS",
      "SUMMARY",
      "ASIDE",
      "MAIN",
      "NAV",
      "HEADER",
      "FOOTER"
    ]);
    let block = el;
    while (block && block !== document.body) {
      if (blockTags.has(block.tagName) || HEADING_TAGS.has(block.tagName)) break;
      block = block.parentElement;
    }
    if (!block || block === document.body) block = el;
    const blockText = (block.textContent || "").replace(/\s+/g, " ").trim();
    if (blockText.length <= 200) return [blockText];
    const sentences = blockText.split(/(?<=[.!?])\s+/);
    const matchLower = matchText.toLowerCase();
    let matchSentIdx = -1;
    for (let i = 0; i < sentences.length; i++) {
      if (sentences[i].toLowerCase().includes(matchLower)) {
        matchSentIdx = i;
        break;
      }
    }
    if (matchSentIdx >= 0) {
      const start = Math.max(0, matchSentIdx - 2);
      const end = Math.min(sentences.length, matchSentIdx + 3);
      return sentences.slice(start, end);
    }
    return [blockText.slice(0, 300)];
  }
  function scoreTerm(term, candidate) {
    const termLen = term.length;
    const candLen = candidate.length;
    if (termLen === 0) return 0;
    if (termLen > candLen) return null;
    let score = 0;
    let termIdx = 0;
    let prevMatchIdx = -2;
    for (let i = 0; i < candLen && termIdx < termLen; i++) {
      if (candidate[i] === term[termIdx]) {
        score += SCORE_BASE;
        if (i === prevMatchIdx + 1) {
          score += SCORE_CONSECUTIVE;
        }
        if (i === 0) {
          score += SCORE_START;
        } else {
          const prev = candidate[i - 1];
          if (WORD_SEPARATORS.has(prev)) {
            score += SCORE_WORD_BOUNDARY;
          }
        }
        if (prevMatchIdx >= 0) {
          const gap = i - prevMatchIdx - 1;
          if (gap > 0) {
            score += gap * PENALTY_DISTANCE;
          }
        }
        prevMatchIdx = i;
        termIdx++;
      }
    }
    if (termIdx < termLen) return null;
    return score;
  }
  function fuzzyMatch(query, candidate) {
    const terms = query.split(" ");
    let totalScore = 0;
    for (let termIndex = 0; termIndex < terms.length; termIndex++) {
      const term = terms[termIndex];
      if (term.length === 0) continue;
      const termScore = scoreTerm(term, candidate);
      if (termScore === null) return null;
      totalScore += termScore;
    }
    return totalScore;
  }
  function resolveTag(el) {
    let cur = el;
    while (cur && cur !== document.body) {
      const tag = cur.tagName;
      if (tag === "PRE" || tag === "CODE" || tag === "A" || tag === "H1" || tag === "H2" || tag === "H3" || tag === "H4" || tag === "H5" || tag === "H6" || tag === "LI" || tag === "TD" || tag === "TH" || tag === "BLOCKQUOTE" || tag === "LABEL" || tag === "BUTTON" || tag === "FIGCAPTION") {
        return tag;
      }
      cur = cur.parentElement;
    }
    return el.tagName || "BODY";
  }
  function collectHeadings() {
    if (cache.headings) return cache.headings;
    const lines = [];
    const headings = document.querySelectorAll("h1, h2, h3, h4, h5, h6");
    for (const heading of headings) {
      const el = heading;
      if (!isVisible(el)) continue;
      const text = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (text.length > 0) {
        lines.push({ text, lower: text.toLowerCase(), tag: el.tagName, nodeRef: new WeakRef(el) });
      }
    }
    cache.headings = lines;
    return lines;
  }
  function collectCode() {
    if (cache.code) return cache.code;
    const lines = [];
    const codeEls = document.querySelectorAll("pre, code");
    for (const codeEl of codeEls) {
      const el = codeEl;
      if (!isVisible(el)) continue;
      if (el.tagName === "CODE" && el.parentElement?.tagName === "PRE") continue;
      if (el.tagName === "PRE") {
        const raw = el.textContent || "";
        const splitLines = raw.split("\n");
        for (const line of splitLines) {
          const trimmed = line.replace(/\s+/g, " ").trim();
          if (trimmed.length > 0) {
            lines.push({ text: trimmed, lower: trimmed.toLowerCase(), tag: "PRE", nodeRef: new WeakRef(el) });
          }
        }
      } else {
        const text = (el.textContent || "").replace(/\s+/g, " ").trim();
        if (text.length > 0) {
          lines.push({ text, lower: text.toLowerCase(), tag: "CODE", nodeRef: new WeakRef(el) });
        }
      }
    }
    cache.code = lines;
    return lines;
  }
  function collectLinks() {
    if (cache.links) return cache.links;
    const lines = [];
    const links = document.querySelectorAll("a[href]");
    for (const link of links) {
      const el = link;
      if (!isVisible(el)) continue;
      const text = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (text.length > 0) {
        lines.push({
          text,
          lower: text.toLowerCase(),
          tag: "A",
          nodeRef: new WeakRef(el),
          href: el.href || void 0
        });
      }
    }
    cache.links = lines;
    return lines;
  }
  function collectImages() {
    if (cache.images) return cache.images;
    const lines = [];
    const images = document.querySelectorAll("img");
    for (const img of images) {
      const el = img;
      if (!isVisible(el)) continue;
      const text = el.alt?.trim() || el.title?.trim() || (el.src ? el.src.split("/").pop()?.split("?")[0] || "" : "").trim();
      if (text.length > 0) {
        lines.push({ text, lower: text.toLowerCase(), tag: "IMG", nodeRef: new WeakRef(el) });
      }
    }
    cache.images = lines;
    return lines;
  }
  function collectAll() {
    if (cache.all) return cache.all;
    const lines = [];
    const preEls = document.querySelectorAll("pre");
    const preSet = /* @__PURE__ */ new Set();
    for (const pre of preEls) {
      if (!isVisible(pre)) continue;
      preSet.add(pre);
      const raw = pre.textContent || "";
      const splitLines = raw.split("\n");
      for (const line of splitLines) {
        const trimmed = line.replace(/\s+/g, " ").trim();
        if (trimmed.length > 0) {
          lines.push({ text: trimmed, lower: trimmed.toLowerCase(), tag: "PRE", nodeRef: new WeakRef(pre) });
        }
      }
    }
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node2) {
          const el = node2.parentElement;
          if (!el) return NodeFilter.FILTER_REJECT;
          if (!isVisible(el)) return NodeFilter.FILTER_REJECT;
          let ancestor = el;
          while (ancestor) {
            if (preSet.has(ancestor)) return NodeFilter.FILTER_REJECT;
            ancestor = ancestor.parentElement;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    let node;
    while (node = walker.nextNode()) {
      const raw = node.textContent;
      if (!raw || raw.length === 0) continue;
      const text = raw.replace(/\s+/g, " ").trim();
      if (text.length > 0) {
        const tag = resolveTag(node.parentElement);
        lines.push({ text, lower: text.toLowerCase(), tag, nodeRef: new WeakRef(node) });
      }
    }
    cache.all = lines;
    return lines;
  }
  function collectLines(filters) {
    if (filters.length === 0) return collectAll();
    if (filters.length === 1) {
      switch (filters[0]) {
        case "code":
          return collectCode();
        case "headings":
          return collectHeadings();
        case "links":
          return collectLinks();
        case "images":
          return collectImages();
      }
    }
    const seen = /* @__PURE__ */ new Set();
    const lines = [];
    for (const filter of filters) {
      let source;
      switch (filter) {
        case "code":
          source = collectCode();
          break;
        case "headings":
          source = collectHeadings();
          break;
        case "links":
          source = collectLinks();
          break;
        case "images":
          source = collectImages();
          break;
      }
      for (const line of source) {
        if (!seen.has(line)) {
          seen.add(line);
          lines.push(line);
        }
      }
    }
    return lines;
  }
  function getVisibleText() {
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null
    );
    const lines = [];
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent?.trim();
      if (text && text.length > 0) {
        lines.push(text);
      }
    }
    return lines;
  }
  function getPageContent() {
    const lines = getVisibleText();
    return { text: lines.join("\n"), lines };
  }
  function grepPage(query, filters = []) {
    if (!query || query.length === 0) return [];
    const lowerQuery = query.toLowerCase().replace(/\s+/g, " ").trim();
    if (lowerQuery.length === 0) return [];
    const allLines = collectLines(filters);
    const scored = [];
    for (let i = 0; i < allLines.length; i++) {
      const line = allLines[i];
      const score = fuzzyMatch(lowerQuery, line.lower);
      if (score === null) continue;
      scored.push({ idx: i, score, line });
      if (scored.length >= MAX_RESULTS * 3) break;
    }
    scored.sort((a, b) => b.score - a.score);
    const results = [];
    const limit = Math.min(scored.length, MAX_RESULTS);
    for (let i = 0; i < limit; i++) {
      const { idx, score, line } = scored[i];
      const start = Math.max(0, idx - CONTEXT_LINES);
      const end = Math.min(allLines.length, idx + CONTEXT_LINES + 1);
      const context = allLines.slice(start, end).map((l) => l.text);
      results.push({
        lineNumber: idx + 1,
        text: line.text,
        tag: line.tag,
        score,
        context,
        nodeRef: line.nodeRef,
        href: line.href
        // domContext and ancestorHeading are computed lazily via enrichResult()
      });
    }
    return results;
  }
  function enrichResult(result) {
    if (result.domContext) return;
    const node = result.nodeRef?.deref();
    if (!node) return;
    result.domContext = getDomContext(node, result.text, result.tag || "");
    result.ancestorHeading = findAncestorHeading(node);
    if (!result.href && result.tag === "A") result.href = findHref(node);
  }

  // src/lib/shared/scroll.ts
  function scrollToText(text, nodeRef) {
    if (!text) return;
    const cached = nodeRef?.deref();
    if (cached) {
      const el = cached instanceof HTMLElement ? cached : cached.parentElement;
      if (el && document.body.contains(el)) {
        scrollToElement(el, text);
        return;
      }
    }
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null
    );
    let node;
    while (node = walker.nextNode()) {
      if (node.textContent?.includes(text)) {
        scrollToElement(node, text);
        return;
      }
    }
  }
  function scrollToElement(node, text) {
    const range = document.createRange();
    if (node.nodeType === Node.TEXT_NODE) {
      range.selectNodeContents(node);
    } else {
      const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null);
      let textNode;
      while (textNode = walker.nextNode()) {
        if (textNode.textContent?.includes(text)) {
          range.selectNodeContents(textNode);
          highlightTextNode(textNode, text);
          const rect2 = range.getBoundingClientRect();
          window.scrollTo({
            top: window.scrollY + rect2.top - window.innerHeight / 3,
            behavior: "smooth"
          });
          return;
        }
      }
      range.selectNodeContents(node);
    }
    const rect = range.getBoundingClientRect();
    window.scrollTo({
      top: window.scrollY + rect.top - window.innerHeight / 3,
      behavior: "smooth"
    });
    if (node.nodeType === Node.TEXT_NODE) {
      highlightTextNode(node, text);
    }
  }
  function highlightTextNode(node, text) {
    const parent = node.parentElement;
    if (!parent) return;
    const content = node.textContent || "";
    const idx = content.indexOf(text);
    if (idx === -1) return;
    const range = document.createRange();
    range.setStart(node, idx);
    range.setEnd(node, idx + text.length);
    const highlight = document.createElement("mark");
    Object.assign(highlight.style, {
      background: "#f9d45c",
      color: "#1e1e1e",
      borderRadius: "3px",
      padding: "0 2px",
      transition: "opacity 0.5s"
    });
    try {
      range.surroundContents(highlight);
      setTimeout(() => {
        highlight.style.opacity = "0";
        setTimeout(() => {
          const textNode = document.createTextNode(highlight.textContent || "");
          highlight.parentNode?.replaceChild(textNode, highlight);
          textNode.parentNode?.normalize();
        }, 500);
      }, 2e3);
    } catch (_) {
    }
  }

  // src/lib/shared/feedback.ts
  function showFeedback(message) {
    const existing = document.getElementById("ht-feedback-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "ht-feedback-toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      padding: "8px 20px",
      background: "#2d2d2d",
      color: "#e0e0e0",
      border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: "8px",
      fontFamily: "'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace",
      fontSize: "13px",
      zIndex: "2147483647",
      boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
      transition: "opacity 0.3s",
      opacity: "1"
    });
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 300);
    }, 1500);
  }

  // src/lib/tabManager/tabManager.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/shared/panelHost.ts
  var activePanelCleanup = null;
  function registerPanelCleanup(fn) {
    activePanelCleanup = fn;
  }
  function createPanelHost() {
    if (activePanelCleanup) {
      activePanelCleanup();
      activePanelCleanup = null;
    }
    const existing = document.getElementById("ht-panel-host");
    if (existing) existing.remove();
    const host = document.createElement("div");
    host.id = "ht-panel-host";
    host.tabIndex = -1;
    host.style.cssText = "position:fixed;top:0;left:0;width:100vw;height:100vh;width:100dvw;height:100dvh;z-index:2147483647;pointer-events:auto;contain:layout style paint;overscroll-behavior:contain;isolation:isolate;";
    const shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
    let reclaimId = 0;
    host.addEventListener("focusout", (event) => {
      const related = event.relatedTarget;
      const staysInPanel = related && (host.contains(related) || host.shadowRoot.contains(related));
      if (!staysInPanel) {
        cancelAnimationFrame(reclaimId);
        reclaimId = requestAnimationFrame(() => {
          if (document.getElementById("ht-panel-host")) {
            host.focus({ preventScroll: true });
          }
        });
      }
    });
    host.addEventListener("mousedown", (event) => {
      if (event.target === host) {
        event.preventDefault();
      }
    });
    return { host, shadow };
  }
  function removePanelHost() {
    const host = document.getElementById("ht-panel-host");
    if (host) host.remove();
  }
  function dismissPanel() {
    if (activePanelCleanup) {
      activePanelCleanup();
      activePanelCleanup = null;
    }
    removePanelHost();
  }
  function vimBadgeHtml(config) {
    const isVim = config.navigationMode === "vim";
    return `<span class="ht-vim-badge ${isVim ? "on" : "off"}">vim</span>`;
  }
  function getBaseStyles() {
    return `
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: rgba(255,255,255,0.1);
      --ht-color-border-soft: rgba(255,255,255,0.06);
      --ht-color-border-faint: rgba(255,255,255,0.04);
      --ht-color-border-ultra-faint: rgba(255,255,255,0.03);
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
      --ht-radius: 10px;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    .ht-backdrop {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      width: 100dvw; height: 100dvh;
      background: rgba(0, 0, 0, 0.55);
    }

    .ht-titlebar {
      display: flex; align-items: center;
      padding: 10px 14px;
      background: var(--ht-color-bg-soft);
      border-bottom: 1px solid var(--ht-color-border-soft);
      border-radius: var(--ht-radius) var(--ht-radius) 0 0;
      user-select: none;
    }
    .ht-traffic-lights {
      display: flex; gap: 7px; margin-right: 14px; flex-shrink: 0;
    }
    .ht-dot {
      width: 12px; height: 12px; border-radius: 50%;
      cursor: pointer; border: none;
      transition: filter 0.15s;
    }
    .ht-dot:hover { filter: brightness(1.2); }
    .ht-dot-close { background: var(--ht-color-danger); }
    .ht-titlebar-text {
      flex: 1; text-align: center; font-size: 12px;
      color: var(--ht-color-text-title); font-weight: 500;
    }

    .ht-vim-badge {
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      padding: 2px 6px; border-radius: 4px;
      text-transform: uppercase; flex-shrink: 0;
      line-height: 1; margin-left: 8px;
    }
    .ht-vim-badge.on {
      background: var(--ht-color-success); color: #1a1a1a;
    }
    .ht-vim-badge.off {
      background: var(--ht-color-surface); color: var(--ht-color-text-dim);
    }

    .ht-footer {
      display: flex; gap: 16px; padding: 8px 14px;
      background: var(--ht-color-bg-elevated); border-top: 1px solid var(--ht-color-border-soft);
      font-size: 11px; color: var(--ht-color-text-muted); flex-wrap: wrap;
      border-radius: 0 0 var(--ht-radius) var(--ht-radius); justify-content: center;
    }
    .ht-footer-row {
      display: flex; gap: 16px; justify-content: center; width: 100%; flex-wrap: wrap;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }
  `;
  }

  // src/lib/shared/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var HTML_ESCAPE_RE = /[&<>"']/;
  function escapeHtml(text) {
    if (!HTML_ESCAPE_RE.test(text)) return text;
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }
  function escapeRegex(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function buildFuzzyPattern(query) {
    const terms = query.trim().split(/\s+/).filter(Boolean);
    if (terms.length === 0) return null;
    const pattern = terms.map(
      (term) => term.split("").map((character) => escapeRegex(character)).join("[^]*?")
    ).join("[^]*?");
    try {
      return new RegExp(pattern, "i");
    } catch (_) {
      return null;
    }
  }
  var DOMAIN_CACHE_MAX = 500;
  var domainCache = /* @__PURE__ */ new Map();
  function cacheDomain(url, value) {
    if (domainCache.size >= DOMAIN_CACHE_MAX) {
      const firstKey = domainCache.keys().next().value;
      if (firstKey !== void 0) domainCache.delete(firstKey);
    }
    domainCache.set(url, value);
    return value;
  }
  function extractDomain(url) {
    const cached = domainCache.get(url);
    if (cached) return cached;
    try {
      return cacheDomain(url, new URL(url).hostname);
    } catch (_) {
      return cacheDomain(url, url.length > 30 ? url.substring(0, 30) + "\u2026" : url);
    }
  }

  // src/lib/tabManager/session.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/tabManager/session.css
  var session_default = ".ht-session-restore-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 420px); max-height: min(84vh, 520px);\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius); overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  display: flex; flex-direction: column;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-session-restore-list { max-height: 260px; overflow-y: auto; }\n.ht-session-restore-item {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  cursor: pointer; border-bottom: 1px solid var(--ht-color-border-faint);\n  transition: background 0.1s; user-select: none;\n}\n.ht-session-restore-item:hover { background: var(--ht-color-border-soft); }\n.ht-session-restore-item.active {\n  background: var(--ht-color-accent-active); border-left: 2px solid var(--ht-color-accent);\n}\n.ht-session-restore-name {\n  flex: 1; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-session-restore-meta {\n  font-size: 10px; color: var(--ht-color-text-muted); flex-shrink: 0;\n}\n.ht-session-restore-empty {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-session-restore-container { border-radius: 8px; }\n  .ht-session-restore-item { padding: 8px 10px; }\n}\n";

  // src/lib/tabManager/session.ts
  var isRenameModeActive = false;
  var isOverwriteConfirmationActive = false;
  async function renderSaveSession(ctx) {
    const { shadow, container } = ctx;
    const currentSessions = await import_webextension_polyfill2.default.runtime.sendMessage({
      type: "SESSION_LIST"
    });
    const count = currentSessions.length;
    let html = `<div class="ht-backdrop"></div>
    <div class="ht-tab-manager-container">
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
        </div>
        <span class="ht-titlebar-text">Save Session (${count}/${MAX_SESSIONS})</span>
      </div>
      <div class="ht-session-input-wrap">
        <span class="ht-session-prompt">Name:</span>
        <input type="text" class="ht-session-input" placeholder="e.g. Research, Debug, Feature..." maxlength="30" />
      </div>
      <div class="ht-session-error" style="display:none; padding: 4px 14px; font-size: 10px; color: #ff5f57;"></div>
      <div class="ht-footer">
        <div class="ht-footer-row">
          <span>Enter save</span>
          <span>Esc back</span>
        </div>
      </div>
    </div>`;
    container.innerHTML = html;
    const backdrop = shadow.querySelector(".ht-backdrop");
    const closeBtn = shadow.querySelector(".ht-dot-close");
    const input = shadow.querySelector(".ht-session-input");
    backdrop.addEventListener("click", () => {
      ctx.setViewMode("tabManager");
      ctx.render();
    });
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    closeBtn.addEventListener("click", () => {
      ctx.setViewMode("tabManager");
      ctx.render();
    });
    input.focus();
  }
  function renderSessionList(ctx) {
    const { shadow, container, config, sessions, sessionIndex } = ctx;
    const titleText = isOverwriteConfirmationActive && sessions[sessionIndex] ? `Overwrite "${escapeHtml(sessions[sessionIndex].name)}"? y / n` : "Sessions";
    let html = `<div class="ht-backdrop"></div>
    <div class="ht-tab-manager-container">
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
        </div>
        <span class="ht-titlebar-text">${titleText}</span>
      </div>
      <div class="ht-tab-manager-list">`;
    if (sessions.length === 0) {
      html += `<div class="ht-session-empty">No saved sessions</div>`;
    } else {
      for (let i = 0; i < sessions.length; i++) {
        const s = sessions[i];
        const cls = i === sessionIndex ? "ht-session-item active" : "ht-session-item";
        const date = new Date(s.savedAt).toLocaleDateString();
        const nameContent = isRenameModeActive && i === sessionIndex ? `<input type="text" class="ht-session-rename-input" value="${escapeHtml(s.name)}" maxlength="30" />` : `<div class="ht-session-name">${escapeHtml(s.name)}</div>`;
        html += `<div class="${cls}" data-index="${i}">
        ${nameContent}
        <span class="ht-session-meta">${s.entries.length} tabs \xB7 ${date}</span>
        <button class="ht-session-delete" data-index="${i}" title="Delete">\xD7</button>
      </div>`;
      }
    }
    const moveUpKey = keyToDisplay(config.bindings.tabManager.moveUp.key);
    const moveDownKey = keyToDisplay(config.bindings.tabManager.moveDown.key);
    const removeKey = keyToDisplay(config.bindings.tabManager.remove.key);
    html += `</div><div class="ht-footer">
    <div class="ht-footer-row">
      <span>j/k (vim) ${moveUpKey}/${moveDownKey} nav</span>
      <span>R rename</span>
      <span>O overwrite</span>
      <span>${removeKey} del</span>
    </div>
    <div class="ht-footer-row">
      <span>Enter load</span>
      <span>Esc back</span>
    </div>
  </div></div>`;
    container.innerHTML = html;
    const backdrop = shadow.querySelector(".ht-backdrop");
    const closeBtn = shadow.querySelector(".ht-dot-close");
    backdrop.addEventListener("click", () => {
      ctx.setViewMode("tabManager");
      ctx.render();
    });
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    closeBtn.addEventListener("click", () => {
      ctx.setViewMode("tabManager");
      ctx.render();
    });
    shadow.querySelectorAll(".ht-session-item").forEach((el) => {
      el.addEventListener("click", (event) => {
        if (event.target.closest(".ht-session-delete")) return;
        const idx = parseInt(el.dataset.index);
        loadSession(ctx, sessions[idx]);
      });
    });
    shadow.querySelectorAll(".ht-session-delete").forEach((el) => {
      el.addEventListener("click", (event) => {
        event.stopPropagation();
        const idx = parseInt(el.dataset.index);
        deleteSession(ctx, idx);
      });
    });
    const activeEl = shadow.querySelector(".ht-session-item.active");
    if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
  }
  function renderReplaceSession(ctx) {
    const { shadow, container, sessions, sessionIndex } = ctx;
    let html = `<div class="ht-backdrop"></div>
    <div class="ht-tab-manager-container">
      <div class="ht-titlebar">
        <div class="ht-traffic-lights">
          <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
        </div>
        <span class="ht-titlebar-text">Replace which session?</span>
      </div>
      <div class="ht-tab-manager-list">`;
    for (let i = 0; i < sessions.length; i++) {
      const s = sessions[i];
      const cls = i === sessionIndex ? "ht-session-item active" : "ht-session-item";
      const date = new Date(s.savedAt).toLocaleDateString();
      html += `<div class="${cls}" data-index="${i}">
      <div class="ht-session-name">${escapeHtml(s.name)}</div>
      <span class="ht-session-meta">${s.entries.length} tabs \xB7 ${date}</span>
    </div>`;
    }
    html += `</div><div class="ht-footer">
    <div class="ht-footer-row">
      <span>\u2191/\u2193 nav</span>
       <span>Enter replace</span>
      <span>Esc back</span>
    </div>
  </div></div>`;
    container.innerHTML = html;
    const backdrop = shadow.querySelector(".ht-backdrop");
    const closeBtn = shadow.querySelector(".ht-dot-close");
    backdrop.addEventListener("click", () => {
      ctx.setViewMode("saveSession");
      ctx.render();
    });
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    closeBtn.addEventListener("click", () => {
      ctx.setViewMode("saveSession");
      ctx.render();
    });
    shadow.querySelectorAll(".ht-session-item").forEach((el) => {
      el.addEventListener("click", () => {
        const idx = parseInt(el.dataset.index);
        replaceSession(ctx, idx);
      });
    });
    const activeEl = shadow.querySelector(".ht-session-item.active");
    if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
  }
  async function replaceSession(ctx, idx) {
    const oldName = ctx.sessions[idx].name;
    await import_webextension_polyfill2.default.runtime.sendMessage({ type: "SESSION_DELETE", name: oldName });
    const result = await import_webextension_polyfill2.default.runtime.sendMessage({
      type: "SESSION_SAVE",
      name: ctx.pendingSaveName
    });
    if (result.ok) {
      showFeedback(`Session "${ctx.pendingSaveName}" saved (replaced "${oldName}")`);
    } else {
      showFeedback(result.reason || "Failed to save session");
    }
    ctx.setViewMode("tabManager");
    ctx.render();
  }
  function handleReplaceSessionKey(ctx, event) {
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      ctx.setViewMode("saveSession");
      ctx.render();
      return true;
    }
    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions[ctx.sessionIndex]) replaceSession(ctx, ctx.sessionIndex);
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveDown")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length > 0) {
        ctx.setSessionIndex(Math.min(ctx.sessionIndex + 1, ctx.sessions.length - 1));
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveUp")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length > 0) {
        ctx.setSessionIndex(Math.max(ctx.sessionIndex - 1, 0));
        ctx.render();
      }
      return true;
    }
    event.stopPropagation();
    return true;
  }
  async function saveSession(ctx, name) {
    if (!name.trim()) return;
    const result = await import_webextension_polyfill2.default.runtime.sendMessage({
      type: "SESSION_SAVE",
      name: name.trim()
    });
    if (result.ok) {
      showFeedback(`Session "${name.trim()}" saved`);
      ctx.setViewMode("tabManager");
      ctx.render();
    } else if (result.reason && result.reason.includes(`Max ${MAX_SESSIONS}`)) {
      ctx.setPendingSaveName(name.trim());
      const sessions = await import_webextension_polyfill2.default.runtime.sendMessage({
        type: "SESSION_LIST"
      });
      ctx.setSessions(sessions);
      ctx.setSessionIndex(0);
      ctx.setViewMode("replaceSession");
      ctx.render();
    } else {
      showFeedback(result.reason || "Failed to save session");
      ctx.setViewMode("tabManager");
      ctx.render();
    }
  }
  async function loadSession(ctx, session) {
    ctx.close();
    const result = await import_webextension_polyfill2.default.runtime.sendMessage({
      type: "SESSION_LOAD",
      name: session.name
    });
    if (result.ok) {
      showFeedback(`Session "${session.name}" loaded (${result.count} tabs)`);
    }
  }
  async function deleteSession(ctx, idx) {
    const name = ctx.sessions[idx].name;
    await import_webextension_polyfill2.default.runtime.sendMessage({
      type: "SESSION_DELETE",
      name
    });
    const sessions = await import_webextension_polyfill2.default.runtime.sendMessage({
      type: "SESSION_LIST"
    });
    ctx.setSessions(sessions);
    ctx.setSessionIndex(Math.min(ctx.sessionIndex, Math.max(sessions.length - 1, 0)));
    ctx.render();
  }
  async function validateSessionSave(name) {
    const [tabManagerList, sessions] = await Promise.all([
      import_webextension_polyfill2.default.runtime.sendMessage({ type: "TAB_MANAGER_LIST" }),
      import_webextension_polyfill2.default.runtime.sendMessage({ type: "SESSION_LIST" })
    ]);
    const currentUrls = tabManagerList.map((entry) => entry.url).join("\n");
    for (const s of sessions) {
      const sessionUrls = s.entries.map((entry) => entry.url).join("\n");
      if (currentUrls === sessionUrls) return `Identical to "${s.name}"`;
    }
    const trimmed = name.trim().toLowerCase();
    for (const s of sessions) {
      if (s.name.toLowerCase() === trimmed) return `"${s.name}" already exists`;
    }
    return null;
  }
  function handleSaveSessionKey(ctx, event) {
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      ctx.setViewMode("tabManager");
      ctx.render();
      return true;
    }
    if (event.key === "Enter") {
      event.preventDefault();
      event.stopPropagation();
      const input = ctx.shadow.querySelector(".ht-session-input");
      if (input && !input.value.trim()) {
        const errorEl = ctx.shadow.querySelector(".ht-session-error");
        if (errorEl) {
          errorEl.textContent = "A session name is required";
          errorEl.style.display = "";
          input.style.borderBottom = "1px solid #ff5f57";
          setTimeout(() => {
            errorEl.style.display = "none";
            input.style.borderBottom = "";
          }, 2e3);
        }
        return true;
      }
      if (input) {
        validateSessionSave(input.value).then((err) => {
          if (err) {
            const errorEl = ctx.shadow.querySelector(".ht-session-error");
            if (errorEl) {
              errorEl.textContent = err;
              errorEl.style.display = "";
              input.style.borderBottom = "1px solid #ff5f57";
              setTimeout(() => {
                errorEl.style.display = "none";
                input.style.borderBottom = "";
              }, 2e3);
            }
          } else {
            saveSession(ctx, input.value);
          }
        });
      }
      return true;
    }
    event.stopPropagation();
    return true;
  }
  function handleSessionListKey(ctx, event) {
    if (isRenameModeActive) {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        isRenameModeActive = false;
        ctx.render();
        return true;
      }
      if (event.key === "Enter") {
        event.preventDefault();
        event.stopPropagation();
        const input = ctx.shadow.querySelector(".ht-session-rename-input");
        if (input && input.value.trim()) {
          const oldName = ctx.sessions[ctx.sessionIndex].name;
          const newName = input.value.trim();
          (async () => {
            const result = await import_webextension_polyfill2.default.runtime.sendMessage({
              type: "SESSION_RENAME",
              oldName,
              newName
            });
            isRenameModeActive = false;
            if (result.ok) {
              showFeedback(`Renamed to "${newName}"`);
              const sessions = await import_webextension_polyfill2.default.runtime.sendMessage({
                type: "SESSION_LIST"
              });
              ctx.setSessions(sessions);
            } else {
              showFeedback(result.reason || "Rename failed");
            }
            ctx.render();
          })();
        }
        return true;
      }
      event.stopPropagation();
      return true;
    }
    if (isOverwriteConfirmationActive) {
      event.preventDefault();
      event.stopPropagation();
      if (event.key.toLowerCase() === "y") {
        const session = ctx.sessions[ctx.sessionIndex];
        isOverwriteConfirmationActive = false;
        (async () => {
          const result = await import_webextension_polyfill2.default.runtime.sendMessage({
            type: "SESSION_UPDATE",
            name: session.name
          });
          if (result.ok) {
            showFeedback(`Session "${session.name}" overwritten`);
            const sessions = await import_webextension_polyfill2.default.runtime.sendMessage({
              type: "SESSION_LIST"
            });
            ctx.setSessions(sessions);
          } else {
            showFeedback(result.reason || "Overwrite failed");
          }
          ctx.render();
        })();
      } else {
        isOverwriteConfirmationActive = false;
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "close") || event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      isRenameModeActive = false;
      isOverwriteConfirmationActive = false;
      ctx.setViewMode("tabManager");
      ctx.render();
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveDown")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length > 0) {
        ctx.setSessionIndex(Math.min(ctx.sessionIndex + 1, ctx.sessions.length - 1));
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "moveUp")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length > 0) {
        ctx.setSessionIndex(Math.max(ctx.sessionIndex - 1, 0));
        ctx.render();
      }
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "jump")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions[ctx.sessionIndex]) loadSession(ctx, ctx.sessions[ctx.sessionIndex]);
      return true;
    }
    if (matchesAction(event, ctx.config, "tabManager", "remove")) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions[ctx.sessionIndex]) deleteSession(ctx, ctx.sessionIndex);
      return true;
    }
    if (event.key.toLowerCase() === "r" && !event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length === 0) return true;
      isRenameModeActive = true;
      ctx.render();
      const input = ctx.shadow.querySelector(".ht-session-rename-input");
      if (input) input.focus();
      return true;
    }
    if (event.key.toLowerCase() === "o" && !event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
      event.preventDefault();
      event.stopPropagation();
      if (ctx.sessions.length === 0) return true;
      isOverwriteConfirmationActive = true;
      ctx.render();
      return true;
    }
    event.stopPropagation();
    return true;
  }
  async function openSessionRestoreOverlay() {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        removePanelHost();
      }, render2 = function() {
        let html = `<div class="ht-backdrop"></div>
        <div class="ht-session-restore-container">
          <div class="ht-titlebar">
            <div class="ht-traffic-lights">
              <button class="ht-dot ht-dot-close" title="Decline (Esc)"></button>
            </div>
            <span class="ht-titlebar-text">Restore Session?</span>
          </div>
          <div class="ht-session-restore-list">`;
        for (let i = 0; i < sessions.length; i++) {
          const s = sessions[i];
          const cls = i === activeIndex ? "ht-session-restore-item active" : "ht-session-restore-item";
          const date = new Date(s.savedAt).toLocaleDateString();
          html += `<div class="${cls}" data-index="${i}">
          <div class="ht-session-restore-name">${escapeHtml(s.name)}</div>
          <span class="ht-session-restore-meta">${s.entries.length} tabs \xB7 ${date}</span>
        </div>`;
        }
        html += `</div>
        <div class="ht-footer">
          <div class="ht-footer-row">
      <span>j/k (vim) \u2191/\u2193 nav</span>
             <span>Enter restore</span>
            <span>Esc decline</span>
          </div>
        </div>
      </div>`;
        container.innerHTML = html;
        const backdrop = shadow.querySelector(".ht-backdrop");
        const closeBtn = shadow.querySelector(".ht-dot-close");
        backdrop.addEventListener("click", close2);
        backdrop.addEventListener("mousedown", (event) => event.preventDefault());
        closeBtn.addEventListener("click", close2);
        shadow.querySelectorAll(".ht-session-restore-item").forEach((el) => {
          el.addEventListener("click", () => {
            const idx = parseInt(el.dataset.index);
            restoreSession(sessions[idx]);
          });
        });
        const activeEl = shadow.querySelector(".ht-session-restore-item.active");
        if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (event.key === "Enter") {
          event.preventDefault();
          event.stopPropagation();
          if (sessions[activeIndex]) restoreSession(sessions[activeIndex]);
          return;
        }
        if (matchesAction(event, config, "tabManager", "moveDown")) {
          event.preventDefault();
          event.stopPropagation();
          activeIndex = Math.min(activeIndex + 1, sessions.length - 1);
          render2();
          return;
        }
        if (matchesAction(event, config, "tabManager", "moveUp")) {
          event.preventDefault();
          event.stopPropagation();
          activeIndex = Math.max(activeIndex - 1, 0);
          render2();
          return;
        }
        event.stopPropagation();
      };
      var close = close2, render = render2, keyHandler = keyHandler2;
      const sessions = await import_webextension_polyfill2.default.runtime.sendMessage({
        type: "SESSION_LIST"
      });
      if (sessions.length === 0) return;
      const config = await loadKeybindings();
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + session_default;
      shadow.appendChild(style);
      const container = document.createElement("div");
      shadow.appendChild(container);
      let activeIndex = 0;
      async function restoreSession(session) {
        close2();
        const result = await import_webextension_polyfill2.default.runtime.sendMessage({
          type: "SESSION_LOAD",
          name: session.name
        });
        if (result.ok) {
          showFeedback(`Session "${session.name}" restored (${result.count} tabs)`);
        }
      }
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      render2();
      host.focus();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open session restore overlay:", err);
    }
  }

  // src/lib/tabManager/tabManager.css
  var tabManager_default = "/* Tab Manager overlay \u2014 panel layout, slot items, swap mode, session inputs */\n\n.ht-tab-manager-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 420px); max-height: min(88vh, 620px);\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius); overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  display: flex; flex-direction: column;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-tab-manager-list { max-height: min(340px, 50vh); overflow-y: auto; }\n.ht-tab-manager-item {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  cursor: pointer; border-bottom: 1px solid var(--ht-color-border-faint);\n  transition: background 0.1s, opacity 0.15s;\n  user-select: none; position: relative;\n}\n.ht-tab-manager-item:hover { background: var(--ht-color-border-soft); }\n.ht-tab-manager-item.active { background: var(--ht-color-surface); border-left: 2px solid var(--ht-color-accent); }\n.ht-tab-manager-item.closed { opacity: 0.5; }\n.ht-tab-manager-item.closed .ht-tab-manager-slot { background: var(--ht-color-border-faint); }\n.ht-tab-manager-item.swap-source {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-warning);\n}\n.ht-tab-manager-slot {\n  background: var(--ht-color-surface); color: var(--ht-color-text); width: 22px; height: 22px;\n  border: none; border-radius: 5px;\n  display: flex; align-items: center; justify-content: center;\n  font-weight: 600; font-size: 12px; flex-shrink: 0;\n  pointer-events: none;\n}\n.ht-tab-manager-item.active .ht-tab-manager-slot {\n  background: var(--ht-color-accent); color: var(--ht-color-text-strong);\n}\n.ht-tab-manager-info { flex: 1; overflow: hidden; pointer-events: none; }\n.ht-tab-manager-item-title {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 12px; color: var(--ht-color-text);\n}\n.ht-tab-manager-item-url {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 10px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-tab-manager-delete {\n  color: var(--ht-color-text-muted); cursor: pointer; font-size: 14px; transition: color 0.2s;\n  background: none; border: none; font-family: inherit; padding: 4px;\n  line-height: 1;\n}\n.ht-tab-manager-delete:hover { color: var(--ht-color-danger); }\n.ht-tab-manager-empty {\n  padding: 32px 24px; text-align: center; color: var(--ht-color-text-muted);\n  line-height: 1.6; font-size: 12px;\n}\n.ht-tab-manager-empty-slot {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  border-bottom: 1px solid var(--ht-color-border-faint); color: var(--ht-color-text-faint);\n}\n.ht-tab-manager-empty-slot .ht-tab-manager-slot {\n  background: var(--ht-color-border-faint); color: var(--ht-color-text-faint);\n}\n.ht-footer-hint-active { color: var(--ht-color-accent); }\n\n/* Session sub-views (save, list, replace) \u2014 rendered inside Tab Manager */\n.ht-session-input-wrap {\n  display: flex; align-items: center; padding: 8px 14px;\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-session-prompt { color: var(--ht-color-accent); margin-right: 8px; font-weight: 600; font-size: 13px; }\n.ht-session-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text); font-family: inherit; font-size: 13px; caret-color: var(--ht-color-accent);\n}\n.ht-session-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-session-item {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  cursor: pointer; border-bottom: 1px solid var(--ht-color-border-faint);\n  transition: background 0.1s; user-select: none;\n}\n.ht-session-item:hover { background: var(--ht-color-border-soft); }\n.ht-session-item.active { background: var(--ht-color-surface); border-left: 2px solid var(--ht-color-accent); }\n.ht-session-name {\n  flex: 1; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-session-meta {\n  font-size: 10px; color: var(--ht-color-text-muted); flex-shrink: 0;\n}\n.ht-session-delete {\n  color: var(--ht-color-text-muted); cursor: pointer; font-size: 14px; transition: color 0.2s;\n  background: none; border: none; font-family: inherit; padding: 4px;\n  line-height: 1; flex-shrink: 0;\n}\n.ht-session-delete:hover { color: var(--ht-color-danger); }\n.ht-session-empty {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n.ht-session-rename-input {\n  flex: 1; background: transparent; border: none; border-bottom: 1px solid var(--ht-color-accent);\n  outline: none; color: var(--ht-color-text); font-family: inherit; font-size: 12px;\n  caret-color: var(--ht-color-accent); padding: 0 2px;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-tab-manager-container { border-radius: 8px; }\n  .ht-tab-manager-list { max-height: min(58vh, 380px); }\n  .ht-tab-manager-item { padding: 8px 10px; }\n}\n";

  // src/lib/tabManager/tabManager.ts
  async function openTabManager(config) {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        removePanelHost();
      }, exitSwapMode2 = function() {
        swapMode = false;
        swapSourceIndex = null;
      }, renderTabManager2 = function() {
        const titleText = !swapMode ? "Tab Manager" : swapSourceIndex === null ? "Select source item" : "Select target to swap";
        let html = `<div class="ht-backdrop"></div>
        <div class="ht-tab-manager-container">
          <div class="ht-titlebar">
            <div class="ht-traffic-lights">
              <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
            </div>
            <span class="ht-titlebar-text">${titleText}</span>
            ${vimBadgeHtml(config)}
          </div>
          <div class="ht-tab-manager-list">`;
        for (let i = 0; i < MAX_TAB_MANAGER_SLOTS; i++) {
          const item = list[i];
          if (item) {
            const shortUrl = extractDomain(item.url);
            const classes = ["ht-tab-manager-item"];
            if (i === activeIndex) classes.push("active");
            if (i === swapSourceIndex) classes.push("swap-source");
            if (item.closed) classes.push("closed");
            html += `<div class="${classes.join(" ")}" data-index="${i}">
            <span class="ht-tab-manager-slot">${item.slot}</span>
            <div class="ht-tab-manager-info">
              <div class="ht-tab-manager-item-title">${escapeHtml(item.title || "Untitled")}</div>
              <div class="ht-tab-manager-item-url">${escapeHtml(shortUrl)}</div>
            </div>
            <button class="ht-tab-manager-delete" data-tab-id="${item.tabId}" title="Remove">\xD7</button>
          </div>`;
          } else {
            html += `<div class="ht-tab-manager-empty-slot">
            <span class="ht-tab-manager-slot">${i + 1}</span>
            <span>---</span>
          </div>`;
          }
        }
        html += `</div><div class="ht-footer">`;
        const moveUpKey = keyToDisplay(config.bindings.tabManager.moveUp.key);
        const moveDownKey = keyToDisplay(config.bindings.tabManager.moveDown.key);
        const jumpKey = keyToDisplay(config.bindings.tabManager.jump.key);
        const removeKey = keyToDisplay(config.bindings.tabManager.remove.key);
        const swapKey = keyToDisplay(config.bindings.tabManager.swap.key);
        const saveKey = keyToDisplay(config.bindings.tabManager.saveSession.key);
        const loadKey = keyToDisplay(config.bindings.tabManager.loadSession.key);
        const closeKey = keyToDisplay(config.bindings.tabManager.close.key);
        html += `<div class="ht-footer-row">`;
        html += `<span>j/k (vim) ${moveUpKey}/${moveDownKey} nav</span>`;
        html += `<span>${saveKey} save</span>`;
        html += `<span>${loadKey} load</span>`;
        html += `<span>${removeKey} del</span>`;
        html += `</div><div class="ht-footer-row">`;
        html += `<span class="${swapMode ? "ht-footer-hint-active" : ""}">${swapKey} swap</span>`;
        html += `<span>U undo</span>`;
        html += `<span>${jumpKey} jump</span>`;
        html += `<span>${closeKey} close</span>`;
        html += `</div>`;
        html += `</div></div>`;
        container.innerHTML = html;
        const backdrop = shadow.querySelector(".ht-backdrop");
        const closeBtn = shadow.querySelector(".ht-dot-close");
        backdrop.addEventListener("click", () => {
          if (swapMode) {
            exitSwapMode2();
            render2();
            return;
          }
          close2();
        });
        backdrop.addEventListener("mousedown", (event) => event.preventDefault());
        closeBtn.addEventListener("click", close2);
        shadow.querySelectorAll(".ht-tab-manager-item").forEach((el) => {
          el.addEventListener("click", (event) => {
            const target = event.target;
            if (target.closest(".ht-tab-manager-delete")) return;
            const idx = parseInt(el.dataset.index);
            if (!list[idx]) return;
            if (!swapMode) {
              jumpToSlot(list[idx]);
              return;
            }
            performSwapPick2(idx);
          });
        });
        shadow.querySelectorAll(".ht-tab-manager-delete").forEach((el) => {
          el.addEventListener("click", async (event) => {
            event.stopPropagation();
            const tabId = parseInt(el.dataset.tabId);
            const idx = list.findIndex((item) => item.tabId === tabId);
            if (idx !== -1) undoEntry = { entry: { ...list[idx] }, index: idx };
            await import_webextension_polyfill3.default.runtime.sendMessage({ type: "TAB_MANAGER_REMOVE", tabId });
            list = await import_webextension_polyfill3.default.runtime.sendMessage({
              type: "TAB_MANAGER_LIST"
            });
            activeIndex = Math.min(activeIndex, Math.max(list.length - 1, 0));
            if (swapMode) exitSwapMode2();
            render2();
          });
        });
        const activeEl = shadow.querySelector(".ht-tab-manager-item.active");
        if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
      }, render2 = function() {
        switch (viewMode) {
          case "tabManager":
            renderTabManager2();
            break;
          case "saveSession":
            renderSaveSession(sessionCtx);
            break;
          case "sessionList":
            renderSessionList(sessionCtx);
            break;
          case "replaceSession":
            renderReplaceSession(sessionCtx);
            break;
        }
      }, setActiveIndex2 = function(newIndex) {
        if (newIndex === activeIndex) return;
        const tabManagerList = shadow.querySelector(".ht-tab-manager-list");
        if (!tabManagerList) return;
        const prev = tabManagerList.querySelector(".ht-tab-manager-item.active");
        if (prev) prev.classList.remove("active");
        activeIndex = newIndex;
        const next = tabManagerList.querySelector(
          `.ht-tab-manager-item[data-index="${activeIndex}"]`
        );
        if (next) {
          next.classList.add("active");
          next.scrollIntoView({ block: "nearest" });
        }
      }, performSwapPick2 = function(idx) {
        if (swapSourceIndex === null) {
          swapSourceIndex = idx;
          render2();
        } else if (swapSourceIndex === idx) {
          swapSourceIndex = null;
          render2();
        } else {
          const srcIdx = swapSourceIndex;
          const temp = list[srcIdx];
          list[srcIdx] = list[idx];
          list[idx] = temp;
          activeIndex = idx;
          swapSourceIndex = null;
          import_webextension_polyfill3.default.runtime.sendMessage({ type: "TAB_MANAGER_REORDER", list }).then(() => import_webextension_polyfill3.default.runtime.sendMessage({ type: "TAB_MANAGER_LIST" })).then((fresh) => {
            list = fresh;
            render2();
          });
        }
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (viewMode === "saveSession") {
          handleSaveSessionKey(sessionCtx, event);
          return;
        }
        if (viewMode === "sessionList") {
          handleSessionListKey(sessionCtx, event);
          return;
        }
        if (viewMode === "replaceSession") {
          handleReplaceSessionKey(sessionCtx, event);
          return;
        }
        if (!event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
          const num = parseInt(event.key);
          if (num >= 1 && num <= MAX_TAB_MANAGER_SLOTS) {
            event.preventDefault();
            event.stopPropagation();
            const item = list.find((it) => it.slot === num);
            if (item) jumpToSlot(item);
            return;
          }
        }
        if (matchesAction(event, config, "tabManager", "swap")) {
          event.preventDefault();
          event.stopPropagation();
          if (swapMode) {
            exitSwapMode2();
          } else {
            swapMode = true;
            swapSourceIndex = null;
          }
          render2();
          return;
        }
        if (matchesAction(event, config, "tabManager", "saveSession")) {
          event.preventDefault();
          event.stopPropagation();
          if (list.length === 0) return;
          viewMode = "saveSession";
          render2();
          return;
        }
        if (matchesAction(event, config, "tabManager", "loadSession")) {
          event.preventDefault();
          event.stopPropagation();
          (async () => {
            sessions = await import_webextension_polyfill3.default.runtime.sendMessage({
              type: "SESSION_LIST"
            });
            sessionIndex = 0;
            viewMode = "sessionList";
            render2();
          })();
          return;
        }
        if (matchesAction(event, config, "tabManager", "close")) {
          event.preventDefault();
          event.stopPropagation();
          if (swapMode) {
            exitSwapMode2();
            render2();
            return;
          }
          close2();
        } else if (matchesAction(event, config, "tabManager", "moveDown")) {
          event.preventDefault();
          event.stopPropagation();
          if (list.length > 0) {
            const newIdx = Math.min(activeIndex + 1, list.length - 1);
            if (swapMode) {
              activeIndex = newIdx;
              render2();
            } else {
              setActiveIndex2(newIdx);
            }
          }
        } else if (matchesAction(event, config, "tabManager", "moveUp")) {
          event.preventDefault();
          event.stopPropagation();
          if (list.length > 0) {
            const newIdx = Math.max(activeIndex - 1, 0);
            if (swapMode) {
              activeIndex = newIdx;
              render2();
            } else {
              setActiveIndex2(newIdx);
            }
          }
        } else if (matchesAction(event, config, "tabManager", "jump")) {
          event.preventDefault();
          event.stopPropagation();
          if (swapMode && list[activeIndex]) {
            performSwapPick2(activeIndex);
          } else if (list[activeIndex]) {
            jumpToSlot(list[activeIndex]);
          }
        } else if (matchesAction(event, config, "tabManager", "remove")) {
          event.preventDefault();
          event.stopPropagation();
          if (list[activeIndex]) {
            (async () => {
              undoEntry = { entry: { ...list[activeIndex] }, index: activeIndex };
              await import_webextension_polyfill3.default.runtime.sendMessage({
                type: "TAB_MANAGER_REMOVE",
                tabId: list[activeIndex].tabId
              });
              list = await import_webextension_polyfill3.default.runtime.sendMessage({
                type: "TAB_MANAGER_LIST"
              });
              activeIndex = Math.min(
                activeIndex,
                Math.max(list.length - 1, 0)
              );
              render2();
            })();
          }
        } else if (event.key.toLowerCase() === "u" && !event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
          event.preventDefault();
          event.stopPropagation();
          if (!undoEntry) return;
          if (list.length >= MAX_TAB_MANAGER_SLOTS) {
            undoEntry = null;
            showFeedback(`Tab Manager full (max ${MAX_TAB_MANAGER_SLOTS})`);
            return;
          }
          (async () => {
            const restoreIdx = Math.min(undoEntry.index, list.length);
            list.splice(restoreIdx, 0, undoEntry.entry);
            undoEntry = null;
            await import_webextension_polyfill3.default.runtime.sendMessage({ type: "TAB_MANAGER_REORDER", list });
            list = await import_webextension_polyfill3.default.runtime.sendMessage({
              type: "TAB_MANAGER_LIST"
            });
            activeIndex = restoreIdx;
            render2();
          })();
        } else {
          event.stopPropagation();
        }
      };
      var close = close2, exitSwapMode = exitSwapMode2, renderTabManager = renderTabManager2, render = render2, setActiveIndex = setActiveIndex2, performSwapPick = performSwapPick2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + tabManager_default;
      shadow.appendChild(style);
      const container = document.createElement("div");
      shadow.appendChild(container);
      let list = await import_webextension_polyfill3.default.runtime.sendMessage({
        type: "TAB_MANAGER_LIST"
      });
      let activeIndex = 0;
      let viewMode = "tabManager";
      let swapMode = false;
      let swapSourceIndex = null;
      let undoEntry = null;
      let sessions = [];
      let sessionIndex = 0;
      let pendingSaveName = "";
      const sessionCtx = {
        shadow,
        container,
        config,
        get sessions() {
          return sessions;
        },
        get sessionIndex() {
          return sessionIndex;
        },
        get pendingSaveName() {
          return pendingSaveName;
        },
        setSessionIndex(i) {
          sessionIndex = i;
        },
        setSessions(s) {
          sessions = s;
        },
        setPendingSaveName(name) {
          pendingSaveName = name;
        },
        setViewMode(mode) {
          viewMode = mode;
        },
        render: render2,
        close: close2
      };
      async function jumpToSlot(item) {
        if (!item) return;
        close2();
        await import_webextension_polyfill3.default.runtime.sendMessage({
          type: "TAB_MANAGER_JUMP",
          slot: item.slot
        });
      }
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      render2();
      host.focus();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open tab manager overlay:", err);
    }
  }

  // src/lib/shared/filterInput.ts
  function parseSlashFilterQuery(rawInput, validFilters) {
    const tokens = rawInput.trimStart().split(/\s+/);
    const filters = [];
    let queryStartIndex = 0;
    for (let i = 0; i < tokens.length; i++) {
      const token = tokens[i];
      const filter = validFilters[token];
      if (!filter) break;
      if (!filters.includes(filter)) filters.push(filter);
      queryStartIndex = i + 1;
    }
    const query = tokens.slice(queryStartIndex).join(" ").trim();
    return { filters, query };
  }

  // src/lib/shared/perfBudgets.json
  var perfBudgets_default = {
    "searchOpenTabs.applyFilter": 14,
    "searchCurrentPage.renderResults": 16,
    "searchCurrentPage.renderVisibleItems": 8,
    "bookmarks.applyFilter": 18,
    "bookmarks.renderVisibleItems": 10,
    "history.applyFilter": 18,
    "history.renderVisibleItems": 10
  };

  // src/lib/shared/perf.ts
  var runtime = globalThis;
  function nowMs() {
    if (typeof performance !== "undefined" && typeof performance.now === "function") {
      return performance.now();
    }
    return Date.now();
  }
  function getBudgetMs(key) {
    return perfBudgets_default[key];
  }
  function recordPerf(key, durationMs) {
    const budgetMs = getBudgetMs(key);
    const stats = runtime.__HT_PERF_STATS__ || {};
    const prev = stats[key] || {
      count: 0,
      totalMs: 0,
      maxMs: 0,
      lastMs: 0,
      budgetMs,
      overBudgetCount: 0
    };
    prev.count += 1;
    prev.totalMs += durationMs;
    prev.maxMs = Math.max(prev.maxMs, durationMs);
    prev.lastMs = durationMs;
    prev.budgetMs = budgetMs;
    if (durationMs > budgetMs) prev.overBudgetCount += 1;
    stats[key] = prev;
    runtime.__HT_PERF_STATS__ = stats;
    if (runtime.__HT_DEBUG_PERF__ && durationMs > budgetMs) {
      console.warn(`[ht:perf] ${key} exceeded budget: ${durationMs.toFixed(2)}ms > ${budgetMs}ms`);
    }
  }
  function withPerfTrace(key, fn) {
    const start = nowMs();
    const result = fn();
    recordPerf(key, nowMs() - start);
    return result;
  }

  // src/lib/searchCurrentPage/searchCurrentPage.css
  var searchCurrentPage_default = "/* Search Current Page overlay \u2014 split-pane, virtual scrolling, filter pills */\n\n.ht-search-page-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 980px); height: min(78vh, 680px); min-height: 300px;\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-search-page-body { flex: 1; display: flex; flex-direction: column; overflow: hidden; }\n.ht-search-page-input-wrap {\n  display: flex; align-items: center; padding: 8px 14px;\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-prompt { color: var(--ht-color-accent); margin-right: 8px; font-weight: 600; font-size: 14px; }\n.ht-search-page-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text); font-family: inherit; font-size: 13px;\n  caret-color: var(--ht-color-text-strong); caret-shape: block;\n}\n.ht-search-page-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-search-page-columns { flex: 1; display: flex; overflow: hidden; }\n.ht-results-pane {\n  width: 40%; border-right: 1px solid var(--ht-color-border-soft);\n  overflow-y: auto; position: relative;\n}\n.ht-results-sentinel {\n  width: 100%; pointer-events: none;\n}\n.ht-results-list {\n  position: absolute; top: 0; left: 0; right: 0;\n  padding: 0;\n}\n.ht-result-item {\n  padding: 5px 14px; cursor: pointer; border-bottom: 1px solid var(--ht-color-border-ultra-faint);\n  transition: background 0.1s; white-space: nowrap; overflow: hidden;\n  text-overflow: ellipsis; display: flex; align-items: baseline; gap: 6px;\n  font-size: 12px; outline: none;\n  height: 28px; box-sizing: border-box;\n}\n.ht-result-item:hover { background: var(--ht-color-border-soft); }\n.ht-result-item.active {\n  background: var(--ht-color-accent-active); color: var(--ht-color-text-strong);\n  border-left: 2px solid var(--ht-color-accent);\n}\n.ht-results-pane.focused .ht-result-item.active {\n  background: var(--ht-color-focus-active);\n  border-left: 2px solid var(--ht-color-text-strong);\n}\n.ht-result-tag {\n  font-size: 9px; padding: 1px 4px; border-radius: 3px;\n  font-weight: 600; flex-shrink: 0; letter-spacing: 0.3px;\n}\n.ht-result-text { flex: 1; overflow: hidden; text-overflow: ellipsis; }\n.ht-result-text mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-preview-pane {\n  width: 60%; display: flex; flex-direction: column; overflow: hidden;\n}\n.ht-preview-header {\n  padding: 5px 14px; font-size: 11px; color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated); border-bottom: 1px solid var(--ht-color-border-faint);\n  font-weight: 500;\n}\n.ht-preview-content {\n  flex: 1; overflow-y: auto; padding: 12px 14px;\n  font-family: inherit; font-size: 12px; line-height: 1.7;\n  background: var(--ht-color-bg); white-space: pre-wrap; word-wrap: break-word;\n}\n.ht-preview-line {\n  color: var(--ht-color-text-muted); display: block; padding: 1px 0;\n}\n.ht-preview-line.match {\n  color: var(--ht-color-text); background: var(--ht-color-accent-soft);\n  border-left: 2px solid var(--ht-color-accent); padding-left: 8px; margin-left: -10px;\n}\n.ht-preview-line .ht-line-num {\n  display: inline-block; width: 36px; text-align: right;\n  margin-right: 12px; color: var(--ht-color-text-faint); user-select: none;\n}\n.ht-preview-line.match .ht-line-num { color: var(--ht-color-accent); }\n.ht-preview-line mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-preview-breadcrumb {\n  padding: 4px 14px; font-size: 10px; color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated); border-bottom: 1px solid var(--ht-color-border-faint);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-preview-breadcrumb .ht-bc-heading {\n  color: var(--ht-color-success); font-weight: 500;\n}\n.ht-preview-breadcrumb .ht-bc-tag {\n  color: var(--ht-color-accent-alt); font-weight: 600; font-size: 9px;\n  background: var(--ht-color-accent-alt-soft); padding: 1px 4px; border-radius: 3px;\n  margin-right: 4px;\n}\n.ht-preview-breadcrumb .ht-bc-href {\n  color: var(--ht-color-accent); font-size: 10px; margin-left: 4px;\n}\n.ht-preview-code-ctx {\n  background: var(--ht-color-bg-code); border-radius: 4px; padding: 8px 0;\n  margin: 4px 0; font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;\n  font-size: 11px; line-height: 1.5;\n}\n.ht-preview-code-ctx .ht-preview-line {\n  padding: 1px 12px; font-family: inherit;\n}\n.ht-preview-code-ctx .ht-preview-line.match {\n  background: var(--ht-color-accent-soft-strong); padding-left: 10px;\n}\n.ht-preview-prose-ctx {\n  padding: 4px 0; font-size: 12px; line-height: 1.7;\n}\n.ht-filter-pills {\n  display: flex; gap: 6px; padding: 0 14px 6px; flex-wrap: wrap;\n}\n.ht-filter-pill {\n  display: inline-flex; align-items: center; gap: 3px;\n  background: var(--ht-color-accent-active); color: var(--ht-color-accent);\n  font-size: 10px; font-weight: 600; padding: 2px 8px;\n  border-radius: var(--ht-radius); user-select: none;\n}\n.ht-filter-pill-x {\n  cursor: pointer; opacity: 0.6; font-size: 11px;\n}\n.ht-filter-pill-x:hover { opacity: 1; }\n.ht-titlebar-text {\n  flex: 1; text-align: left; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  display: flex; align-items: center; gap: 8px;\n  margin-right: 0;\n}\n.ht-title-label { flex-shrink: 0; color: var(--ht-color-text-title); }\n.ht-title-sep { color: var(--ht-color-text-faint); flex-shrink: 0; }\n.ht-title-filters { color: var(--ht-color-text-muted); font-size: 11px; flex-shrink: 0; }\n.ht-title-filter { color: var(--ht-color-text-dim); }\n.ht-title-filter.active { color: var(--ht-color-accent); font-weight: 600; }\n.ht-title-count { color: var(--ht-color-text-muted); font-size: 11px; margin-left: auto; flex-shrink: 0; }\n.ht-preview-placeholder {\n  flex: 1; display: flex; align-items: center; justify-content: center;\n  color: var(--ht-color-text-faint); font-size: 14px; background: var(--ht-color-bg);\n}\n.ht-no-results {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n\n@media (max-width: 860px), (max-height: 620px) {\n  .ht-search-page-container {\n    width: 96vw;\n    height: min(90vh, 760px);\n    min-height: 260px;\n  }\n  .ht-search-page-columns {\n    flex-direction: column;\n  }\n  .ht-results-pane {\n    width: 100%;\n    height: 46%;\n    border-right: none;\n    border-bottom: 1px solid var(--ht-color-border-soft);\n  }\n  .ht-preview-pane {\n    width: 100%;\n    height: 54%;\n  }\n}\n\n@media (max-width: 520px) {\n  .ht-search-page-container { border-radius: 8px; }\n  .ht-search-page-input-wrap { padding: 8px 10px; }\n  .ht-result-item { padding: 5px 10px; }\n  .ht-preview-content { padding: 10px; }\n}\n";

  // src/lib/searchCurrentPage/searchCurrentPage.ts
  var MAX_DOM_ELEMENTS = 2e5;
  var MAX_TEXT_BYTES = 10 * 1024 * 1024;
  var VALID_FILTERS = {
    "/code": "code",
    "/headings": "headings",
    "/img": "images",
    "/links": "links"
  };
  var TAG_COLORS = {
    PRE: { bg: "rgba(175,130,255,0.2)", fg: "#af82ff" },
    CODE: { bg: "rgba(175,130,255,0.2)", fg: "#af82ff" },
    H1: { bg: "rgba(50,215,75,0.2)", fg: "#32d74b" },
    H2: { bg: "rgba(50,215,75,0.2)", fg: "#32d74b" },
    H3: { bg: "rgba(50,215,75,0.2)", fg: "#32d74b" },
    H4: { bg: "rgba(50,215,75,0.2)", fg: "#32d74b" },
    H5: { bg: "rgba(50,215,75,0.2)", fg: "#32d74b" },
    H6: { bg: "rgba(50,215,75,0.2)", fg: "#32d74b" },
    A: { bg: "rgba(255,159,10,0.2)", fg: "#ff9f0a" },
    IMG: { bg: "rgba(0,199,190,0.2)", fg: "#00c7be" }
  };
  var DEFAULT_TAG_COLOR = { bg: "rgba(255,255,255,0.08)", fg: "#808080" };
  var ITEM_HEIGHT = 28;
  var POOL_BUFFER = 5;
  var lastSearchState = null;
  async function openSearchCurrentPage(config) {
    try {
      let setFocusedPane2 = function(pane) {
        focusedPane = pane;
        resultsPane.classList.toggle("focused", pane === "results");
      }, close2 = function() {
        panelOpen = false;
        lastSearchState = { query: input.value };
        document.removeEventListener("keydown", keyHandler2, true);
        if (previewRafId !== null) cancelAnimationFrame(previewRafId);
        if (scrollRafId !== null) cancelAnimationFrame(scrollRafId);
        destroyLineCache();
        removePanelHost();
      }, updateTitle2 = function() {
        titleFilterSpans.forEach((span) => {
          const filter = span.dataset.filter;
          span.classList.toggle("active", activeFilters.includes(filter));
        });
        titleCount.textContent = results.length > 0 ? `${results.length} match${results.length !== 1 ? "es" : ""}` : "";
      }, updateFilterPills2 = function() {
        if (activeFilters.length === 0) {
          filterPills.style.display = "none";
          return;
        }
        filterPills.style.display = "flex";
        filterPills.innerHTML = activeFilters.map(
          (filter) => `<span class="ht-filter-pill" data-filter="${filter}">/${filter}<span class="ht-filter-pill-x">\xD7</span></span>`
        ).join("");
        filterPills.querySelectorAll(".ht-filter-pill-x").forEach((removeButton) => {
          removeButton.addEventListener("click", (event) => {
            event.stopPropagation();
            const pill = removeButton.parentElement;
            const filter = pill.dataset.filter;
            const tokens = input.value.trimStart().split(/\s+/);
            const remainingTokens = tokens.filter((token) => token !== `/${filter}`);
            input.value = remainingTokens.join(" ");
            input.dispatchEvent(new Event("input"));
            input.focus();
          });
        });
      }, parseInput2 = function(raw) {
        return parseSlashFilterQuery(raw, VALID_FILTERS);
      }, buildHighlightRegex2 = function() {
        if (!currentQuery) {
          highlightRegex = null;
          return;
        }
        try {
          const terms = currentQuery.split(/\s+/).filter(Boolean);
          const pattern = terms.map((term) => `(${escapeRegex(escapeHtml(term))})`).join("|");
          highlightRegex = new RegExp(pattern, "gi");
        } catch (_) {
          highlightRegex = null;
        }
      }, highlightMatch2 = function(text) {
        const escaped = escapeHtml(text);
        if (!highlightRegex) return escaped;
        return escaped.replace(highlightRegex, "<mark>$1</mark>");
      }, getPoolItem2 = function(poolIdx) {
        if (poolIdx < itemPool.length) return itemPool[poolIdx];
        const item = document.createElement("div");
        item.className = "ht-result-item";
        item.tabIndex = -1;
        const badge = document.createElement("span");
        badge.className = "ht-result-tag";
        item.appendChild(badge);
        const span = document.createElement("span");
        span.className = "ht-result-text";
        item.appendChild(span);
        itemPool.push(item);
        return item;
      }, bindPoolItem2 = function(item, resultIdx) {
        const result = results[resultIdx];
        item.dataset.index = String(resultIdx);
        const badge = item.firstElementChild;
        if (result.tag) {
          const colors = TAG_COLORS[result.tag] || DEFAULT_TAG_COLOR;
          badge.style.background = colors.bg;
          badge.style.color = colors.fg;
          badge.textContent = result.tag;
          badge.style.display = "";
        } else {
          badge.style.display = "none";
        }
        const span = item.lastElementChild;
        span.innerHTML = highlightMatch2(result.text);
        if (resultIdx === activeIndex) {
          item.classList.add("active");
          activeItemEl = item;
        } else {
          item.classList.remove("active");
        }
      }, renderVisibleItems2 = function() {
        withPerfTrace("searchCurrentPage.renderVisibleItems", () => {
          const scrollTop = resultsPane.scrollTop;
          const viewHeight = resultsPane.clientHeight;
          const newStart = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT) - POOL_BUFFER);
          const newEnd = Math.min(
            results.length,
            Math.ceil((scrollTop + viewHeight) / ITEM_HEIGHT) + POOL_BUFFER
          );
          if (newStart === vsStart && newEnd === vsEnd) return;
          vsStart = newStart;
          vsEnd = newEnd;
          resultsList.style.top = `${vsStart * ITEM_HEIGHT}px`;
          const count = vsEnd - vsStart;
          while (resultsList.children.length > count) {
            resultsList.removeChild(resultsList.lastChild);
          }
          activeItemEl = null;
          for (let i = 0; i < count; i++) {
            const item = getPoolItem2(i);
            bindPoolItem2(item, vsStart + i);
            if (i < resultsList.children.length) {
              if (resultsList.children[i] !== item) {
                resultsList.replaceChild(item, resultsList.children[i]);
              }
            } else {
              resultsList.appendChild(item);
            }
          }
        });
      }, renderResults2 = function() {
        withPerfTrace("searchCurrentPage.renderResults", () => {
          buildHighlightRegex2();
          if (results.length === 0) {
            resultsSentinel.style.height = "0px";
            resultsList.style.top = "0px";
            resultsList.textContent = "";
            resultsList.innerHTML = input.value ? '<div class="ht-no-results">No matches found</div>' : '<div class="ht-no-results">Type to search...</div>';
            previewHeader.textContent = "Preview";
            showPreviewPlaceholder2(true);
            activeItemEl = null;
            vsStart = 0;
            vsEnd = 0;
            return;
          }
          resultsSentinel.style.height = `${results.length * ITEM_HEIGHT}px`;
          resultsPane.scrollTop = 0;
          vsStart = 0;
          vsEnd = 0;
          resultsList.textContent = "";
          renderVisibleItems2();
        });
      }, scheduleVisibleRender2 = function() {
        if (scrollRafId !== null) return;
        scrollRafId = requestAnimationFrame(() => {
          scrollRafId = null;
          if (results.length > 0) renderVisibleItems2();
        });
      }, setActiveIndex2 = function(newIndex) {
        if (newIndex < 0 || newIndex >= results.length) return;
        if (newIndex === activeIndex && activeItemEl) {
          schedulePreviewUpdate2();
          return;
        }
        if (activeItemEl) activeItemEl.classList.remove("active");
        activeIndex = newIndex;
        activeItemEl = null;
        if (newIndex >= vsStart && newIndex < vsEnd) {
          const poolIdx = newIndex - vsStart;
          const el = resultsList.children[poolIdx];
          if (el) {
            el.classList.add("active");
            activeItemEl = el;
          }
        }
        scrollActiveIntoView2();
        schedulePreviewUpdate2();
      }, scrollActiveIntoView2 = function() {
        const itemTop = activeIndex * ITEM_HEIGHT;
        const itemBottom = itemTop + ITEM_HEIGHT;
        const scrollTop = resultsPane.scrollTop;
        const viewHeight = resultsPane.clientHeight;
        if (itemTop < scrollTop) {
          resultsPane.scrollTop = itemTop;
        } else if (itemBottom > scrollTop + viewHeight) {
          resultsPane.scrollTop = itemBottom - viewHeight;
        }
      }, showPreviewPlaceholder2 = function(show) {
        previewPlaceholder.style.display = show ? "flex" : "none";
        previewContent.style.display = show ? "none" : "block";
        previewBreadcrumb.style.display = show ? "none" : "";
      }, schedulePreviewUpdate2 = function() {
        if (previewRafId !== null) return;
        previewRafId = requestAnimationFrame(() => {
          previewRafId = null;
          updatePreview2();
        });
      }, updatePreview2 = function() {
        if (results.length === 0 || !results[activeIndex]) {
          previewHeader.textContent = "Preview";
          previewBreadcrumb.style.display = "none";
          showPreviewPlaceholder2(true);
          return;
        }
        const activeResult = results[activeIndex];
        enrichResult(activeResult);
        const tag = activeResult.tag || "";
        previewHeader.textContent = `Preview \u2014 L${activeResult.lineNumber}`;
        showPreviewPlaceholder2(false);
        let breadcrumbHtml = "";
        if (tag) breadcrumbHtml += `<span class="ht-bc-tag">${escapeHtml(tag)}</span>`;
        if (activeResult.ancestorHeading) {
          breadcrumbHtml += `<span class="ht-bc-heading">${escapeHtml(activeResult.ancestorHeading)}</span>`;
        }
        if (activeResult.href) {
          let displayHref = activeResult.href;
          try {
            displayHref = new URL(activeResult.href).pathname + new URL(activeResult.href).hash;
          } catch (_) {
          }
          if (displayHref.length > 60) displayHref = displayHref.slice(0, 57) + "...";
          breadcrumbHtml += `<span class="ht-bc-href">\u2192 ${escapeHtml(displayHref)}</span>`;
        }
        if (breadcrumbHtml) {
          previewBreadcrumb.innerHTML = breadcrumbHtml;
          previewBreadcrumb.style.display = "";
        } else {
          previewBreadcrumb.style.display = "none";
        }
        const contextLines = activeResult.domContext && activeResult.domContext.length > 0 ? activeResult.domContext : activeResult.context && activeResult.context.length > 0 ? activeResult.context : [activeResult.text];
        const isCode = tag === "PRE" || tag === "CODE";
        let html = "";
        if (isCode) {
          html += '<div class="ht-preview-code-ctx">';
          for (let i = 0; i < contextLines.length; i++) {
            const line = contextLines[i];
            const trimmed = line.replace(/\s+/g, " ").trim();
            const isMatch = trimmed === activeResult.text || line.replace(/\s+/g, " ").trim() === activeResult.text;
            const cls = isMatch ? "ht-preview-line match" : "ht-preview-line";
            const lineContent = isMatch ? highlightMatch2(line) : escapeHtml(line);
            html += `<span class="${cls}"><span class="ht-line-num">${i + 1}</span>${lineContent}</span>`;
          }
          html += "</div>";
        } else {
          html += '<div class="ht-preview-prose-ctx">';
          for (let i = 0; i < contextLines.length; i++) {
            const line = contextLines[i];
            const isMatch = line === activeResult.text || line.replace(/\s+/g, " ").trim() === activeResult.text;
            const cls = isMatch ? "ht-preview-line match" : "ht-preview-line";
            const lineContent = isMatch ? highlightMatch2(line) : escapeHtml(line);
            html += `<span class="${cls}">${lineContent}</span>`;
          }
          html += "</div>";
        }
        previewContent.innerHTML = html;
        const matchLine = previewContent.querySelector(".match");
        if (matchLine) matchLine.scrollIntoView({ block: "center" });
      }, doGrep2 = function(query) {
        if (!query || query.trim().length === 0) {
          results = [];
          renderResults2();
          return;
        }
        currentQuery = query.trim();
        results = grepPage(currentQuery, activeFilters);
        activeIndex = 0;
        updateTitle2();
        renderResults2();
        schedulePreviewUpdate2();
      }, keyHandler2 = function(event) {
        if (!panelOpen) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (matchesAction(event, config, "search", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (event.key === "Backspace" && focusedPane === "input" && input.value === "" && activeFilters.length > 0) {
          event.preventDefault();
          activeFilters.pop();
          input.value = activeFilters.map((filter) => `/${filter}`).join(" ") + (activeFilters.length ? " " : "");
          updateTitle2();
          updateFilterPills2();
          results = [];
          currentQuery = "";
          renderResults2();
          schedulePreviewUpdate2();
          return;
        }
        if (matchesAction(event, config, "search", "switchPane")) {
          event.preventDefault();
          event.stopPropagation();
          if (focusedPane === "input") {
            if (activeItemEl) {
              activeItemEl.focus();
            } else {
              const first = resultsList.querySelector(".ht-result-item");
              if (first) first.focus();
            }
            setFocusedPane2("results");
          } else {
            input.focus();
            setFocusedPane2("input");
          }
          return;
        }
        if (event.key.toLowerCase() === "c" && !event.ctrlKey && !event.altKey && !event.metaKey && focusedPane === "results") {
          event.preventDefault();
          event.stopPropagation();
          input.value = "";
          activeFilters = [];
          currentQuery = "";
          results = [];
          activeIndex = 0;
          updateTitle2();
          updateFilterPills2();
          renderResults2();
          schedulePreviewUpdate2();
          input.focus();
          setFocusedPane2("input");
          return;
        }
        if (matchesAction(event, config, "search", "accept")) {
          event.preventDefault();
          event.stopPropagation();
          if (results[activeIndex]) jumpToResult(results[activeIndex]);
          return;
        }
        if (matchesAction(event, config, "search", "moveDown")) {
          const lowerKey = event.key.toLowerCase();
          if ((lowerKey === "j" || lowerKey === "k") && focusedPane === "input") return;
          event.preventDefault();
          event.stopPropagation();
          if (results.length > 0) {
            setActiveIndex2(Math.min(activeIndex + 1, results.length - 1));
          }
          return;
        }
        if (matchesAction(event, config, "search", "moveUp")) {
          const lowerKey = event.key.toLowerCase();
          if ((lowerKey === "j" || lowerKey === "k") && focusedPane === "input") return;
          event.preventDefault();
          event.stopPropagation();
          if (results.length > 0) {
            setActiveIndex2(Math.max(activeIndex - 1, 0));
          }
          return;
        }
        event.stopPropagation();
      };
      var setFocusedPane = setFocusedPane2, close = close2, updateTitle = updateTitle2, updateFilterPills = updateFilterPills2, parseInput = parseInput2, buildHighlightRegex = buildHighlightRegex2, highlightMatch = highlightMatch2, getPoolItem = getPoolItem2, bindPoolItem = bindPoolItem2, renderVisibleItems = renderVisibleItems2, renderResults = renderResults2, scheduleVisibleRender = scheduleVisibleRender2, setActiveIndex = setActiveIndex2, scrollActiveIntoView = scrollActiveIntoView2, showPreviewPlaceholder = showPreviewPlaceholder2, schedulePreviewUpdate = schedulePreviewUpdate2, updatePreview = updatePreview2, doGrep = doGrep2, keyHandler = keyHandler2;
      initLineCache();
      const elementCount = document.body.querySelectorAll("*").length;
      const textLength = document.body.textContent?.length ?? 0;
      if (elementCount > MAX_DOM_ELEMENTS || textLength > MAX_TEXT_BYTES) {
        destroyLineCache();
        showFeedback("Page too large to search");
        return;
      }
      const { host, shadow } = createPanelHost();
      let panelOpen = true;
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + searchCurrentPage_default;
      shadow.appendChild(style);
      const wrapper = document.createElement("div");
      wrapper.innerHTML = `
      <div class="ht-backdrop"></div>
      <div class="ht-search-page-container">
        <div class="ht-titlebar">
          <div class="ht-traffic-lights">
            <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
          </div>
          <span class="ht-titlebar-text">
            <span class="ht-title-label">Search \u2014 Current Page</span>
            <span class="ht-title-sep">|</span>
            <span class="ht-title-filters">Filters:
              <span class="ht-title-filter" data-filter="code">/code</span>
              <span class="ht-title-filter" data-filter="headings">/headings</span>
              <span class="ht-title-filter" data-filter="images">/img</span>
              <span class="ht-title-filter" data-filter="links">/links</span>
            </span>
            <span class="ht-title-count"></span>
          </span>
          ${vimBadgeHtml(config)}
        </div>
        <div class="ht-search-page-body">
          <div class="ht-search-page-input-wrap">
            <span class="ht-prompt">&gt;</span>
            <input type="text" class="ht-search-page-input" placeholder="Search..." />
          </div>
          <div class="ht-filter-pills"></div>
          <div class="ht-search-page-columns">
            <div class="ht-results-pane">
              <div class="ht-results-sentinel"></div>
              <div class="ht-results-list"></div>
            </div>
            <div class="ht-preview-pane">
              <div class="ht-preview-header">Preview</div>
              <div class="ht-preview-breadcrumb" style="display:none;"></div>
              <div class="ht-preview-placeholder">Select a result to preview</div>
              <div class="ht-preview-content" style="display:none;"></div>
            </div>
          </div>
          <div class="ht-footer"></div>
        </div>
      </div>
    `;
      shadow.appendChild(wrapper);
      const footer = shadow.querySelector(".ht-footer");
      const upKey = keyToDisplay(config.bindings.search.moveUp.key);
      const downKey = keyToDisplay(config.bindings.search.moveDown.key);
      const acceptKey = keyToDisplay(config.bindings.search.accept.key);
      const switchKey = keyToDisplay(config.bindings.search.switchPane.key);
      const closeKey = keyToDisplay(config.bindings.search.close.key);
      footer.innerHTML = `
      <div class="ht-footer-row">
        <span>j/k (vim) ${upKey}/${downKey} nav</span>
        <span>${switchKey} list</span>
        <span>C clear</span>
        <span>${acceptKey} jump</span>
        <span>${closeKey} close</span>
      </div>
    `;
      const input = shadow.querySelector(".ht-search-page-input");
      const resultsList = shadow.querySelector(".ht-results-list");
      const resultsSentinel = shadow.querySelector(".ht-results-sentinel");
      const previewHeader = shadow.querySelector(".ht-preview-header");
      const previewBreadcrumb = shadow.querySelector(".ht-preview-breadcrumb");
      const previewPane = shadow.querySelector(".ht-preview-pane");
      const previewPlaceholder = shadow.querySelector(".ht-preview-placeholder");
      const previewContent = shadow.querySelector(".ht-preview-content");
      const filterPills = shadow.querySelector(".ht-filter-pills");
      const closeBtn = shadow.querySelector(".ht-dot-close");
      const backdrop = shadow.querySelector(".ht-backdrop");
      const resultsPane = shadow.querySelector(".ht-results-pane");
      const titleText = shadow.querySelector(".ht-titlebar-text");
      const titleFilterSpans = shadow.querySelectorAll(".ht-title-filter");
      const titleCount = shadow.querySelector(".ht-title-count");
      let results = [];
      let activeIndex = 0;
      let debounceTimer = null;
      let currentQuery = "";
      let activeFilters = [];
      let activeItemEl = null;
      let focusedPane = "input";
      let previewRafId = null;
      let scrollRafId = null;
      let vsStart = 0;
      let vsEnd = 0;
      let itemPool = [];
      let highlightRegex = null;
      resultsPane.addEventListener("scroll", scheduleVisibleRender2, { passive: true });
      resultsList.addEventListener("click", (event) => {
        const item = event.target.closest(".ht-result-item");
        if (!item || !item.dataset.index) return;
        setActiveIndex2(Number(item.dataset.index));
      });
      resultsList.addEventListener("dblclick", (event) => {
        const item = event.target.closest(".ht-result-item");
        if (!item || !item.dataset.index) return;
        const selectedIndex = Number(item.dataset.index);
        activeIndex = selectedIndex;
        if (results[selectedIndex]) jumpToResult(results[selectedIndex]);
      });
      closeBtn.addEventListener("click", close2);
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      input.addEventListener("focus", () => {
        setFocusedPane2("input");
      });
      resultsList.addEventListener("focus", () => {
        setFocusedPane2("results");
      }, true);
      input.addEventListener("input", () => {
        if (debounceTimer) clearTimeout(debounceTimer);
        const { filters, query } = parseInput2(input.value);
        activeFilters = filters;
        updateTitle2();
        updateFilterPills2();
        if (query.length < 2) {
          results = [];
          currentQuery = "";
          renderResults2();
          schedulePreviewUpdate2();
          return;
        }
        debounceTimer = setTimeout(() => doGrep2(query), 200);
      });
      async function jumpToResult(result) {
        close2();
        scrollToText(result.text, result.nodeRef);
      }
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      resultsPane.addEventListener("wheel", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (results.length === 0) return;
        if (event.deltaY > 0) {
          setActiveIndex2(Math.min(activeIndex + 1, results.length - 1));
        } else {
          setActiveIndex2(Math.max(activeIndex - 1, 0));
        }
      });
      input.focus();
      setTimeout(() => {
        if (panelOpen) input.focus();
      }, 50);
      if (lastSearchState && lastSearchState.query) {
        input.value = lastSearchState.query;
        const { filters, query } = parseInput2(lastSearchState.query);
        activeFilters = filters;
        updateTitle2();
        if (query.length >= 2) {
          doGrep2(query);
        }
      }
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open search current page:", err);
    }
  }

  // src/lib/searchOpenTabs/searchOpenTabs.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/searchOpenTabs/searchOpenTabs.css
  var searchOpenTabs_default = "/* Search Open Tabs overlay \u2014 sorted tab list with fuzzy filter */\n\n.ht-open-tabs-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 560px); max-height: min(88vh, 620px); background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border); border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-open-tabs-input-wrap {\n  display: flex; align-items: center; padding: 8px 14px;\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-open-tabs-prompt { color: var(--ht-color-accent); margin-right: 8px; font-weight: 600; font-size: 14px; }\n.ht-open-tabs-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text); font-family: inherit; font-size: 13px;\n  caret-color: var(--ht-color-text-strong); caret-shape: block;\n}\n.ht-open-tabs-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-open-tabs-list { max-height: 380px; overflow-y: auto; }\n.ht-open-tabs-item {\n  display: flex; align-items: center; padding: 8px 14px; gap: 10px;\n  cursor: pointer; border-bottom: 1px solid var(--ht-color-border-faint);\n  user-select: none; outline: none;\n}\n.ht-open-tabs-item:hover { background: var(--ht-color-border-soft); }\n.ht-open-tabs-item.active {\n  background: var(--ht-color-accent-active); border-left: 2px solid var(--ht-color-accent);\n}\n.ht-open-tabs-list.focused .ht-open-tabs-item.active {\n  background: var(--ht-color-focus-active); border-left: 2px solid var(--ht-color-text-strong);\n}\n.ht-open-tabs-score {\n  font-size: 10px; color: var(--ht-color-text-muted); min-width: 36px; text-align: right;\n  flex-shrink: 0;\n}\n.ht-open-tabs-info { flex: 1; overflow: hidden; }\n.ht-open-tabs-title {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 12px; color: var(--ht-color-text);\n}\n.ht-open-tabs-title mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-open-tabs-url {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 10px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-open-tabs-empty {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-open-tabs-container { border-radius: 8px; }\n  .ht-open-tabs-input-wrap { padding: 8px 10px; }\n  .ht-open-tabs-item { padding: 8px 10px; }\n}\n";

  // src/lib/searchOpenTabs/searchOpenTabs.ts
  async function openSearchOpenTabs(config) {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        removePanelHost();
      }, buildHighlightRegex2 = function() {
        const terms = query.trim().split(/\s+/).filter(Boolean);
        if (terms.length === 0) {
          highlightRegex = null;
          return;
        }
        const pattern = terms.map((t) => `(${escapeRegex(escapeHtml(t))})`).join("|");
        try {
          highlightRegex = new RegExp(pattern, "gi");
        } catch (_) {
          highlightRegex = null;
        }
      }, highlightMatch2 = function(text) {
        const escaped = escapeHtml(text);
        if (!highlightRegex) return escaped;
        return escaped.replace(highlightRegex, "<mark>$1</mark>");
      }, buildListFragment2 = function() {
        const frag = document.createDocumentFragment();
        for (let i = 0; i < filtered.length; i++) {
          const entry = filtered[i];
          const shortUrl = extractDomain(entry.url);
          const item = document.createElement("div");
          item.className = i === activeIndex ? "ht-open-tabs-item active" : "ht-open-tabs-item";
          item.dataset.index = String(i);
          item.dataset.tabId = String(entry.tabId);
          item.tabIndex = -1;
          const score = document.createElement("span");
          score.className = "ht-open-tabs-score";
          score.textContent = String(entry.frecencyScore);
          const info = document.createElement("div");
          info.className = "ht-open-tabs-info";
          const title = document.createElement("div");
          title.className = "ht-open-tabs-title";
          title.innerHTML = highlightMatch2(entry.title || "Untitled");
          const url = document.createElement("div");
          url.className = "ht-open-tabs-url";
          url.textContent = shortUrl;
          info.appendChild(title);
          info.appendChild(url);
          item.appendChild(score);
          item.appendChild(info);
          frag.appendChild(item);
        }
        return frag;
      }, commitList2 = function(frag) {
        listEl.textContent = "";
        listEl.appendChild(frag);
        activeItemEl = listEl.children[activeIndex];
        if (activeItemEl) activeItemEl.scrollIntoView({ block: "nearest" });
      }, renderList2 = function() {
        titleText.textContent = query ? `Search Open Tabs (${filtered.length})` : "Search Open Tabs";
        if (filtered.length === 0) {
          cancelAnimationFrame(renderRafId);
          listEl.innerHTML = `<div class="ht-open-tabs-empty">${query ? "No matching tabs" : "No open tabs"}</div>`;
          activeItemEl = null;
          return;
        }
        if (firstRender) {
          firstRender = false;
          commitList2(buildListFragment2());
          return;
        }
        cancelAnimationFrame(renderRafId);
        renderRafId = requestAnimationFrame(() => {
          commitList2(buildListFragment2());
        });
      }, updateActiveHighlight2 = function(newIndex) {
        if (newIndex === activeIndex && activeItemEl) return;
        if (activeItemEl) activeItemEl.classList.remove("active");
        activeIndex = newIndex;
        activeItemEl = listEl.children[activeIndex] || null;
        if (activeItemEl) {
          activeItemEl.classList.add("active");
          activeItemEl.scrollIntoView({ block: "nearest" });
        }
      }, onListClick2 = function(event) {
        const item = event.target.closest(".ht-open-tabs-item");
        if (!item) return;
        const idx = parseInt(item.dataset.index);
        if (filtered[idx]) jumpToTab(filtered[idx]);
      }, scoreMatch2 = function(lowerText, rawText, queryLower, fuzzyRe) {
        if (lowerText === queryLower) return 0;
        if (lowerText.startsWith(queryLower)) return 1;
        if (lowerText.includes(queryLower)) return 2;
        if (fuzzyRe.test(rawText)) return 3;
        return -1;
      }, applyFilter2 = function() {
        withPerfTrace("searchOpenTabs.applyFilter", () => {
          const trimmedQuery = query.trim();
          if (!trimmedQuery) {
            filtered = [...allEntries];
            activeIndex = 0;
            return;
          }
          const re = buildFuzzyPattern(trimmedQuery);
          const substringRe = new RegExp(escapeRegex(trimmedQuery), "i");
          if (!re) {
            filtered = [...allEntries];
            activeIndex = 0;
            return;
          }
          const queryLower = trimmedQuery.toLowerCase();
          const ranked = [];
          for (const entry of allEntries) {
            const title = entry.title || "";
            const url = entry.url || "";
            if (!(substringRe.test(title) || substringRe.test(url) || re.test(title) || re.test(url))) {
              continue;
            }
            const titleScore = scoreMatch2(title.toLowerCase(), title, queryLower, re);
            const urlScore = scoreMatch2(url.toLowerCase(), url, queryLower, re);
            ranked.push({
              entry,
              titleScore,
              titleHit: titleScore >= 0,
              titleLen: title.length,
              urlScore,
              urlHit: urlScore >= 0
            });
          }
          ranked.sort((a, b) => {
            if (a.titleHit !== b.titleHit) return a.titleHit ? -1 : 1;
            if (a.titleHit && b.titleHit) {
              if (a.titleScore !== b.titleScore) return a.titleScore - b.titleScore;
              return a.titleLen - b.titleLen;
            }
            if (a.urlHit !== b.urlHit) return a.urlHit ? -1 : 1;
            if (a.urlHit && b.urlHit) return a.urlScore - b.urlScore;
            return 0;
          });
          filtered = ranked.map((r) => r.entry);
          activeIndex = 0;
        });
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (matchesAction(event, config, "search", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (event.key === "Tab" && !event.ctrlKey && !event.altKey && !event.metaKey) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length === 0) return;
          const shadowActive = host.shadowRoot?.activeElement;
          if (shadowActive === input) {
            if (activeItemEl) {
              activeItemEl.focus();
            } else {
              const first = listEl.querySelector(".ht-open-tabs-item");
              if (first) first.focus();
            }
            listEl.classList.add("focused");
          } else {
            input.focus();
            listEl.classList.remove("focused");
          }
          return;
        }
        const inputFocused = host.shadowRoot?.activeElement === input;
        if (event.key.toLowerCase() === "c" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          input.value = "";
          query = "";
          buildHighlightRegex2();
          applyFilter2();
          renderList2();
          return;
        }
        if (matchesAction(event, config, "search", "accept")) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered[activeIndex]) jumpToTab(filtered[activeIndex]);
          return;
        }
        if (matchesAction(event, config, "search", "moveDown")) {
          const lk = event.key.toLowerCase();
          if ((lk === "j" || lk === "k") && inputFocused) return;
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length > 0) {
            updateActiveHighlight2(Math.min(activeIndex + 1, filtered.length - 1));
            if (!inputFocused && activeItemEl) activeItemEl.focus();
          }
          return;
        }
        if (matchesAction(event, config, "search", "moveUp")) {
          const lk = event.key.toLowerCase();
          if ((lk === "j" || lk === "k") && inputFocused) return;
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length > 0) {
            updateActiveHighlight2(Math.max(activeIndex - 1, 0));
            if (!inputFocused && activeItemEl) activeItemEl.focus();
          }
          return;
        }
        event.stopPropagation();
      };
      var close = close2, buildHighlightRegex = buildHighlightRegex2, highlightMatch = highlightMatch2, buildListFragment = buildListFragment2, commitList = commitList2, renderList = renderList2, updateActiveHighlight = updateActiveHighlight2, onListClick = onListClick2, scoreMatch = scoreMatch2, applyFilter = applyFilter2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      const upKey = keyToDisplay(config.bindings.search.moveUp.key);
      const downKey = keyToDisplay(config.bindings.search.moveDown.key);
      const switchKey = keyToDisplay(config.bindings.search.switchPane.key);
      const acceptKey = keyToDisplay(config.bindings.search.accept.key);
      const closeKey = keyToDisplay(config.bindings.search.close.key);
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + searchOpenTabs_default;
      shadow.appendChild(style);
      const backdrop = document.createElement("div");
      backdrop.className = "ht-backdrop";
      shadow.appendChild(backdrop);
      const panel = document.createElement("div");
      panel.className = "ht-open-tabs-container";
      shadow.appendChild(panel);
      const titlebar = document.createElement("div");
      titlebar.className = "ht-titlebar";
      titlebar.innerHTML = `
      <div class="ht-traffic-lights">
        <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
      </div>
      <span class="ht-titlebar-text">Search Open Tabs</span>
      ${vimBadgeHtml(config)}`;
      panel.appendChild(titlebar);
      const titleText = titlebar.querySelector(".ht-titlebar-text");
      const inputWrap = document.createElement("div");
      inputWrap.className = "ht-open-tabs-input-wrap";
      inputWrap.innerHTML = `<span class="ht-open-tabs-prompt">&gt;</span>`;
      const input = document.createElement("input");
      input.type = "text";
      input.className = "ht-open-tabs-input";
      input.placeholder = "Filter tabs...";
      inputWrap.appendChild(input);
      panel.appendChild(inputWrap);
      const listEl = document.createElement("div");
      listEl.className = "ht-open-tabs-list";
      panel.appendChild(listEl);
      const footer = document.createElement("div");
      footer.className = "ht-footer";
      footer.innerHTML = `<div class="ht-footer-row">
      <span>j/k (vim) ${upKey}/${downKey} nav</span>
      <span>${switchKey} list</span>
      <span>C clear</span>
      <span>${acceptKey} jump</span>
      <span>${closeKey} close</span>
    </div>`;
      panel.appendChild(footer);
      let allEntries = [];
      let filtered = [];
      let activeIndex = 0;
      let query = "";
      let activeItemEl = null;
      let highlightRegex = null;
      let renderRafId = 0;
      let firstRender = true;
      async function jumpToTab(entry) {
        if (!entry) return;
        close2();
        await import_webextension_polyfill4.default.runtime.sendMessage({
          type: "SWITCH_TO_TAB",
          tabId: entry.tabId
        });
      }
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      titlebar.querySelector(".ht-dot-close").addEventListener("click", close2);
      listEl.addEventListener("click", onListClick2);
      listEl.addEventListener("wheel", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (filtered.length === 0) return;
        if (event.deltaY > 0) {
          updateActiveHighlight2(Math.min(activeIndex + 1, filtered.length - 1));
        } else {
          updateActiveHighlight2(Math.max(activeIndex - 1, 0));
        }
      });
      input.addEventListener("focus", () => {
        listEl.classList.remove("focused");
      });
      listEl.addEventListener("focus", () => {
        listEl.classList.add("focused");
      }, true);
      input.addEventListener("input", () => {
        query = input.value;
        buildHighlightRegex2();
        applyFilter2();
        renderList2();
      });
      allEntries = await import_webextension_polyfill4.default.runtime.sendMessage({
        type: "FRECENCY_LIST"
      });
      filtered = [...allEntries];
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      renderList2();
      input.focus();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open search open tabs:", err);
    }
  }

  // src/lib/bookmarks/bookmarks.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/bookmarks/bookmarks.css
  var bookmarks_default = "/* Bookmarks overlay \u2014 browse, fuzzy-filter, add/remove browser bookmarks */\n\n.ht-bookmark-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 980px); height: min(78vh, 680px); min-height: 300px;\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-bookmark-body { flex: 1; display: flex; flex-direction: column; overflow: hidden; background: var(--ht-color-bg); }\n.ht-bookmark-input-wrap {\n  display: flex; align-items: center; padding: 8px 14px;\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-bookmark-prompt { color: var(--ht-color-accent); margin-right: 8px; font-weight: 600; font-size: 14px; }\n.ht-bookmark-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text); font-family: inherit; font-size: 13px;\n  caret-color: var(--ht-color-text-strong); caret-shape: block;\n}\n.ht-bookmark-input::placeholder { color: var(--ht-color-text-dim); }\n\n/* Titlebar \u2014 left-aligned with filter indicators and count */\n.ht-bookmark-container .ht-titlebar-text {\n  flex: 1; text-align: left; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  display: flex; align-items: center; gap: 8px;\n  margin-right: 0;\n}\n.ht-bm-title-label { flex-shrink: 0; color: var(--ht-color-text-title); }\n.ht-bm-title-sep { color: var(--ht-color-text-faint); flex-shrink: 0; }\n.ht-bm-title-filters { color: var(--ht-color-text-muted); font-size: 11px; flex-shrink: 0; }\n.ht-bm-title-filter { color: var(--ht-color-text-dim); }\n.ht-bm-title-filter.active { color: var(--ht-color-accent); font-weight: 600; }\n.ht-bm-title-count { color: var(--ht-color-text-muted); font-size: 11px; margin-left: auto; flex-shrink: 0; }\n\n/* Filter pills */\n.ht-bm-filter-pills {\n  display: flex; gap: 6px; padding: 0 14px 6px; flex-wrap: wrap;\n}\n.ht-bm-filter-pill {\n  display: inline-flex; align-items: center; gap: 3px;\n  background: var(--ht-color-accent-active); color: var(--ht-color-accent);\n  font-size: 10px; font-weight: 600; padding: 2px 8px;\n  border-radius: var(--ht-radius); user-select: none;\n}\n.ht-bm-filter-pill-x {\n  cursor: pointer; opacity: 0.6; font-size: 11px;\n}\n.ht-bm-filter-pill-x:hover { opacity: 1; }\n\n.ht-bookmark-columns { flex: 1; display: flex; overflow: hidden; background: var(--ht-color-bg); }\n\n/* Left pane: results list */\n.ht-bm-results-pane {\n  width: 40%; border-right: 1px solid var(--ht-color-border-soft);\n  overflow-y: auto; position: relative; background: var(--ht-color-bg);\n}\n.ht-bm-results-sentinel { width: 100%; pointer-events: none; }\n.ht-bm-results-list {\n  position: absolute; top: 0; left: 0; right: 0; padding: 0;\n  will-change: transform;\n}\n.ht-bm-item {\n  padding: 4px 10px; cursor: pointer;\n  border-bottom: 1px solid var(--ht-color-border-faint);\n  display: flex; align-items: center;\n  height: 44px; box-sizing: border-box;\n  outline: none; user-select: none;\n}\n.ht-bm-item:hover { background: var(--ht-color-border-soft); }\n.ht-bm-item.active {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-accent);\n}\n.ht-bm-results-pane.focused .ht-bm-item.active {\n  background: var(--ht-color-focus-active);\n  border-left: 2px solid var(--ht-color-text-strong);\n}\n/* Dim active item when tree pane is focused (treeNav mode) */\n.ht-bm-results-pane.dimmed .ht-bm-item.active {\n  background: var(--ht-color-border-faint);\n  border-left: 2px solid var(--ht-color-surface-strong);\n}\n.ht-bm-info { flex: 1; overflow: hidden; }\n.ht-bm-title {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 12px; color: var(--ht-color-text);\n}\n.ht-bm-title mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-bm-url-line {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 10px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-bm-url-line mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-bm-folder-tag { color: var(--ht-color-accent); margin-right: 4px; }\n.ht-bm-folder-tag mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n\n/* Right pane: detail / folder picker */\n.ht-bm-detail-pane {\n  width: 60%; display: flex; flex-direction: column; overflow: hidden;\n  background: var(--ht-color-bg);\n  border-left: 2px solid transparent;\n  transition: border-color 0.15s, background 0.15s;\n}\n.ht-bm-detail-pane.focused {\n  background: var(--ht-color-bg-detail-focus);\n  border-left-color: var(--ht-color-accent);\n}\n.ht-bm-detail-pane.focused .ht-bm-detail-header {\n  background: var(--ht-color-bg-detail-focus-header);\n  color: var(--ht-color-text-detail-focus);\n}\n.ht-bm-detail-pane.focused .ht-bm-detail-content {\n  background: var(--ht-color-bg-detail-focus);\n}\n.ht-bm-detail-header {\n  padding: 5px 14px; font-size: 11px; color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated); border-bottom: 1px solid var(--ht-color-border-faint);\n  font-weight: 500; display: flex; align-items: center;\n}\n.ht-bm-detail-header-text { flex: 1; }\n.ht-bm-detail-header-close {\n  display: none; cursor: pointer; color: var(--ht-color-text-muted); font-size: 14px;\n  line-height: 1; padding: 0 2px; border: none; background: none;\n  font-family: inherit;\n}\n.ht-bm-detail-header-close:hover { color: var(--ht-color-text); }\n.ht-bm-detail-content {\n  flex: 1; overflow-y: auto; padding: 16px 20px;\n  background: var(--ht-color-bg);\n}\n.ht-bm-detail-placeholder {\n  flex: 1; display: flex; align-items: center; justify-content: center;\n  color: var(--ht-color-text-faint); font-size: 14px; background: var(--ht-color-bg);\n}\n.ht-bm-no-results {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n\n/* Tree visualization in detail pane */\n.ht-bm-tree {\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  background: var(--ht-color-bg-elevated);\n  padding: 6px 0;\n  margin-bottom: 14px;\n  max-height: 160px;\n  overflow-y: auto;\n  font-size: 11px;\n  line-height: 1.6;\n}\n.ht-bm-tree-node {\n  padding: 1px 10px;\n  color: var(--ht-color-text-title);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  font-weight: 600;\n}\n.ht-bm-tree-node.active {\n  color: var(--ht-color-accent);\n  background: var(--ht-color-accent-soft);\n}\n.ht-bm-tree-entry {\n  padding: 1px 10px;\n  color: var(--ht-color-text-muted);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  font-size: 10px;\n}\n.ht-bm-tree-entry.active {\n  color: var(--ht-color-accent);\n  background: var(--ht-color-accent-soft-faint);\n  font-weight: 600;\n}\n.ht-bm-tree-domain {\n  color: var(--ht-color-text-faint);\n  margin-left: 4px;\n}\n.ht-bm-tree-node.tree-cursor,\n.ht-bm-tree-entry.tree-cursor {\n  background: var(--ht-color-tree-cursor-bg);\n  color: var(--ht-color-tree-cursor);\n}\n.ht-bm-tree-node.active.tree-cursor {\n  background: var(--ht-color-tree-cursor-bg-strong);\n  color: var(--ht-color-tree-cursor);\n}\n.ht-bm-tree-entry.active.tree-cursor {\n  background: var(--ht-color-tree-cursor-bg-soft);\n  color: var(--ht-color-tree-cursor);\n}\n.ht-bm-tree-collapse {\n  color: var(--ht-color-text-faint);\n  font-size: 9px;\n  margin-right: 3px;\n}\n.ht-bm-tree-label { font-size: 11px; }\n\n/* Move mode folder list in detail pane */\n.ht-bm-move-list {\n  overflow-y: auto; padding: 4px 0;\n}\n.ht-bm-move-item {\n  padding: 6px 14px; cursor: pointer; font-size: 12px;\n  color: var(--ht-color-text); white-space: nowrap; overflow: hidden;\n  text-overflow: ellipsis; outline: none; user-select: none;\n}\n.ht-bm-move-item:hover { background: var(--ht-color-border-soft); }\n.ht-bm-move-item.active {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-accent);\n}\n\n/* Confirm dialog in detail pane */\n.ht-bm-confirm {\n  display: flex; flex-direction: column; align-items: center;\n  justify-content: center; height: 100%; gap: 16px; padding: 20px;\n}\n.ht-bm-confirm-icon { font-size: 28px; }\n.ht-bm-confirm-msg {\n  font-size: 13px; color: var(--ht-color-text); text-align: center;\n  line-height: 1.6; max-width: 280px;\n}\n.ht-bm-confirm-title {\n  color: var(--ht-color-text-strong); font-weight: 600;\n}\n.ht-bm-confirm-path {\n  font-size: 11px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-bm-confirm-arrow {\n  display: flex; align-items: center; justify-content: center; gap: 10px;\n  font-size: 13px; color: var(--ht-color-text-muted); margin-top: 8px; width: 100%;\n}\n.ht-bm-confirm-from { color: var(--ht-color-text-muted); text-align: right; flex: 1; }\n.ht-bm-confirm-to { color: var(--ht-color-accent); font-weight: 600; text-align: left; flex: 1; }\n.ht-bm-confirm-hint {\n  font-size: 11px; color: var(--ht-color-text-faint);\n}\n\n@media (max-width: 860px), (max-height: 620px) {\n  .ht-bookmark-container {\n    width: 96vw;\n    height: min(90vh, 760px);\n    min-height: 260px;\n  }\n  .ht-bookmark-columns {\n    flex-direction: column;\n  }\n  .ht-bm-results-pane {\n    width: 100%;\n    height: 46%;\n    border-right: none;\n    border-bottom: 1px solid var(--ht-color-border-soft);\n  }\n  .ht-bm-detail-pane {\n    width: 100%;\n    height: 54%;\n    border-left: none;\n    border-top: 2px solid transparent;\n  }\n  .ht-bm-detail-pane.focused {\n    border-left-color: transparent;\n    border-top-color: var(--ht-color-accent);\n  }\n}\n\n@media (max-width: 520px) {\n  .ht-bookmark-container { border-radius: 8px; }\n  .ht-bookmark-input-wrap { padding: 8px 10px; }\n  .ht-bm-item { padding: 4px 8px; }\n  .ht-bm-detail-content { padding: 12px; }\n}\n";

  // src/lib/bookmarks/bookmarks.ts
  var ITEM_HEIGHT2 = 44;
  var POOL_BUFFER2 = 5;
  var VALID_FILTERS2 = {
    "/folder": "folder"
  };
  function flattenFolders(folders) {
    const flat = [];
    function walk(nodes) {
      for (const folder of nodes) {
        flat.push({ id: folder.id, title: folder.title, depth: folder.depth });
        if (folder.children.length > 0) walk(folder.children);
      }
    }
    walk(folders);
    return flat;
  }
  function shortPath(folderPath) {
    const segments = folderPath.split(" \u203A ");
    return segments.length > 2 ? segments.slice(-2).join(" \u203A ") : folderPath;
  }
  async function openBookmarkOverlay(config) {
    try {
      let setFocusedPane2 = function(pane) {
        focusedPane = pane;
        resultsPane.classList.toggle("focused", pane === "results");
      }, close2 = function() {
        panelOpen = false;
        document.removeEventListener("keydown", keyHandler2, true);
        if (detailRafId !== null) cancelAnimationFrame(detailRafId);
        if (scrollRafId !== null) cancelAnimationFrame(scrollRafId);
        removePanelHost();
      }, parseInput2 = function(raw) {
        return parseSlashFilterQuery(raw, VALID_FILTERS2);
      }, updateTitle2 = function() {
        titleFilterSpans.forEach((span) => {
          const filter = span.dataset.filter;
          span.classList.toggle("active", activeFilters.includes(filter));
        });
        titleCount.textContent = filtered.length > 0 ? `${filtered.length} bookmark${filtered.length !== 1 ? "s" : ""}` : "";
      }, updateFilterPills2 = function() {
        if (activeFilters.length === 0) {
          filterPills.style.display = "none";
          return;
        }
        filterPills.style.display = "flex";
        filterPills.innerHTML = activeFilters.map(
          (filter) => `<span class="ht-bm-filter-pill" data-filter="${filter}">/${filter}<span class="ht-bm-filter-pill-x">\xD7</span></span>`
        ).join("");
        filterPills.querySelectorAll(".ht-bm-filter-pill-x").forEach((removeButton) => {
          removeButton.addEventListener("click", (event) => {
            event.stopPropagation();
            const pill = removeButton.parentElement;
            const filter = pill.dataset.filter;
            const tokens = input.value.trimStart().split(/\s+/);
            const remaining = tokens.filter((token) => token !== `/${filter}`);
            input.value = remaining.join(" ");
            input.dispatchEvent(new Event("input"));
            input.focus();
          });
        });
      }, buildHighlightRegex2 = function() {
        if (!currentQuery) {
          highlightRegex = null;
          return;
        }
        try {
          const terms = currentQuery.split(/\s+/).filter(Boolean);
          const pattern = terms.map((term) => `(${escapeRegex(escapeHtml(term))})`).join("|");
          highlightRegex = new RegExp(pattern, "gi");
        } catch (_) {
          highlightRegex = null;
        }
      }, highlightMatch2 = function(text) {
        const escaped = escapeHtml(text);
        if (!highlightRegex) return escaped;
        return escaped.replace(highlightRegex, "<mark>$1</mark>");
      }, getPoolItem2 = function(poolIdx) {
        if (poolIdx < itemPool.length) return itemPool[poolIdx];
        const item = document.createElement("div");
        item.className = "ht-bm-item";
        item.tabIndex = -1;
        const info = document.createElement("div");
        info.className = "ht-bm-info";
        const title = document.createElement("div");
        title.className = "ht-bm-title";
        const urlLine = document.createElement("div");
        urlLine.className = "ht-bm-url-line";
        info.appendChild(title);
        info.appendChild(urlLine);
        item.appendChild(info);
        itemPool.push(item);
        return item;
      }, bindPoolItem2 = function(item, resultIdx) {
        const entry = filtered[resultIdx];
        item.dataset.index = String(resultIdx);
        const info = item.firstElementChild;
        const titleEl = info.firstElementChild;
        titleEl.innerHTML = highlightMatch2(entry.title || "Untitled");
        const urlEl = info.lastElementChild;
        const pathDisplay = entry.folderPath ? shortPath(entry.folderPath) : "";
        if (pathDisplay) {
          urlEl.innerHTML = `<span class="ht-bm-folder-tag">${highlightMatch2(pathDisplay)}</span>`;
        } else {
          urlEl.textContent = "\u2013";
        }
        if (resultIdx === activeIndex) {
          item.classList.add("active");
          activeItemEl = item;
        } else {
          item.classList.remove("active");
        }
      }, renderVisibleItems2 = function() {
        withPerfTrace("bookmarks.renderVisibleItems", () => {
          const scrollTop = resultsPane.scrollTop;
          const viewHeight = resultsPane.clientHeight;
          const newStart = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT2) - POOL_BUFFER2);
          const newEnd = Math.min(
            filtered.length,
            Math.ceil((scrollTop + viewHeight) / ITEM_HEIGHT2) + POOL_BUFFER2
          );
          if (newStart === vsStart && newEnd === vsEnd) return;
          vsStart = newStart;
          vsEnd = newEnd;
          resultsList.style.top = `${vsStart * ITEM_HEIGHT2}px`;
          const count = vsEnd - vsStart;
          while (resultsList.children.length > count) {
            resultsList.removeChild(resultsList.lastChild);
          }
          activeItemEl = null;
          for (let i = 0; i < count; i++) {
            const item = getPoolItem2(i);
            bindPoolItem2(item, vsStart + i);
            if (i < resultsList.children.length) {
              if (resultsList.children[i] !== item) {
                resultsList.replaceChild(item, resultsList.children[i]);
              }
            } else {
              resultsList.appendChild(item);
            }
          }
        });
      }, renderResults2 = function() {
        buildHighlightRegex2();
        updateTitle2();
        if (filtered.length === 0) {
          resultsSentinel.style.height = "0px";
          resultsList.style.top = "0px";
          resultsList.textContent = "";
          resultsList.innerHTML = `<div class="ht-bm-no-results">${currentQuery || activeFilters.length > 0 ? "No matching bookmarks" : "No bookmarks found"}</div>`;
          activeItemEl = null;
          vsStart = 0;
          vsEnd = 0;
          showDetailPlaceholder2(true);
          return;
        }
        resultsSentinel.style.height = `${filtered.length * ITEM_HEIGHT2}px`;
        resultsPane.scrollTop = 0;
        vsStart = -1;
        vsEnd = -1;
        renderVisibleItems2();
        scheduleDetailUpdate2();
      }, scheduleVisibleRender2 = function() {
        if (scrollRafId !== null) return;
        scrollRafId = requestAnimationFrame(() => {
          scrollRafId = null;
          if (filtered.length > 0) renderVisibleItems2();
        });
      }, setActiveIndex2 = function(newIndex) {
        if (newIndex < 0 || newIndex >= filtered.length) return;
        if (newIndex === activeIndex && activeItemEl) {
          scheduleDetailUpdate2();
          return;
        }
        if (activeItemEl) activeItemEl.classList.remove("active");
        activeIndex = newIndex;
        activeItemEl = null;
        if (newIndex >= vsStart && newIndex < vsEnd) {
          const poolIdx = newIndex - vsStart;
          const el = resultsList.children[poolIdx];
          if (el) {
            el.classList.add("active");
            activeItemEl = el;
          }
        }
        scrollActiveIntoView2();
        scheduleDetailUpdate2();
      }, scrollActiveIntoView2 = function() {
        const itemTop = activeIndex * ITEM_HEIGHT2;
        const itemBottom = itemTop + ITEM_HEIGHT2;
        const scrollTop = resultsPane.scrollTop;
        const viewHeight = resultsPane.clientHeight;
        if (itemTop < scrollTop) {
          resultsPane.scrollTop = itemTop;
        } else if (itemBottom > scrollTop + viewHeight) {
          resultsPane.scrollTop = itemBottom - viewHeight;
        }
      }, showDetailPlaceholder2 = function(show) {
        detailPlaceholder.style.display = show ? "flex" : "none";
        detailContent.style.display = show ? "none" : "block";
      }, scheduleDetailUpdate2 = function() {
        if (detailRafId !== null) return;
        detailRafId = requestAnimationFrame(() => {
          detailRafId = null;
          updateDetail2();
        });
      }, updateDetail2 = function() {
        if (detailMode === "move") return;
        if (detailMode === "confirmDelete") return;
        if (detailMode === "confirmMove") return;
        renderTreeView2();
      }, scoreMatch2 = function(lowerText, rawText, lowerQuery, fuzzyRe) {
        if (lowerText === lowerQuery) return 0;
        if (lowerText.startsWith(lowerQuery)) return 1;
        if (lowerText.includes(lowerQuery)) return 2;
        if (fuzzyRe.test(rawText)) return 3;
        return -1;
      }, applyFilter2 = function() {
        withPerfTrace("bookmarks.applyFilter", () => {
          let results = allEntries;
          const trimmedQuery = currentQuery.trim();
          if (trimmedQuery) {
            const re = buildFuzzyPattern(trimmedQuery);
            const substringRe = new RegExp(escapeRegex(trimmedQuery), "i");
            if (re) {
              if (activeFilters.length === 0) {
                const lowerQuery = trimmedQuery.toLowerCase();
                const ranked = [];
                for (const entry of results) {
                  const title = entry.title || "";
                  const url = entry.url || "";
                  const folder = entry.folderPath || "";
                  if (!(substringRe.test(title) || substringRe.test(url) || folder !== "" && substringRe.test(folder) || re.test(title) || re.test(url) || folder !== "" && re.test(folder))) {
                    continue;
                  }
                  const titleScore = scoreMatch2(title.toLowerCase(), title, lowerQuery, re);
                  const folderScore = folder !== "" ? scoreMatch2(folder.toLowerCase(), folder, lowerQuery, re) : -1;
                  ranked.push({
                    entry,
                    titleScore,
                    titleHit: titleScore >= 0,
                    titleLen: title.length,
                    folderScore,
                    folderHit: folderScore >= 0
                  });
                }
                ranked.sort((a, b) => {
                  if (a.titleHit !== b.titleHit) return a.titleHit ? -1 : 1;
                  if (a.titleHit && b.titleHit) {
                    if (a.titleScore !== b.titleScore) return a.titleScore - b.titleScore;
                    return a.titleLen - b.titleLen;
                  }
                  if (a.folderHit !== b.folderHit) return a.folderHit ? -1 : 1;
                  if (a.folderHit && b.folderHit) return a.folderScore - b.folderScore;
                  return 0;
                });
                results = ranked.map((r) => r.entry);
              } else {
                results = results.filter((entry) => !!entry.folderPath && (substringRe.test(entry.folderPath) || re.test(entry.folderPath)));
              }
            }
          } else if (activeFilters.length > 0) {
            results = results.filter((entry) => !!entry.folderPath);
          }
          filtered = results;
          activeIndex = 0;
        });
      }, renderMoveView2 = function() {
        const entry = filtered[activeIndex];
        detailHeader.textContent = `Move: ${entry?.title || "bookmark"}`;
        showDetailPlaceholder2(false);
        let html = '<div class="ht-bm-move-list">';
        for (let i = 0; i < moveFolders.length; i++) {
          const folder = moveFolders[i];
          const indent = (folder.depth - 1) * 16;
          const isActive = moveTargetIndex === i;
          html += `<div class="ht-bm-move-item${isActive ? " active" : ""}" data-midx="${i}" style="padding-left:${14 + indent}px">`;
          html += `\u{1F4C1} ${escapeHtml(folder.title)}`;
          html += "</div>";
        }
        html += "</div>";
        detailContent.innerHTML = html;
        const list = detailContent.querySelector(".ht-bm-move-list");
        if (list) {
          list.addEventListener("click", (event) => {
            const item = event.target.closest("[data-midx]");
            if (!item) return;
            moveTargetIndex = parseInt(item.dataset.midx);
            const activeEntry = filtered[activeIndex];
            if (!activeEntry) return;
            pendingMoveEntry = activeEntry;
            pendingMoveParentId = moveFolders[moveTargetIndex]?.id || null;
            detailMode = "confirmMove";
            renderMoveConfirm2();
            updateFooter2();
          });
        }
        const activeEl = detailContent.querySelector(".ht-bm-move-item.active");
        if (activeEl) activeEl.scrollIntoView({ block: "nearest" });
      }, renderTreeView2 = function() {
        const entry = filtered[activeIndex];
        detailHeader.textContent = "Bookmark Tree";
        showDetailPlaceholder2(false);
        const isFiltering = currentQuery.trim() !== "" || activeFilters.length > 0;
        const byParent = /* @__PURE__ */ new Map();
        const sourceEntries = isFiltering ? filtered : allEntries;
        for (const bm of sourceEntries) {
          if (!bm.parentId) continue;
          let list = byParent.get(bm.parentId);
          if (!list) {
            list = [];
            byParent.set(bm.parentId, list);
          }
          list.push(bm);
        }
        let visibleFolderIds = null;
        if (isFiltering) {
          visibleFolderIds = /* @__PURE__ */ new Set();
          for (const [folderId] of byParent) {
            visibleFolderIds.add(folderId);
          }
          const ancestorIds = /* @__PURE__ */ new Set();
          for (const folderId of visibleFolderIds) {
            const folderIndex = flatFolderList.findIndex((folder) => folder.id === folderId);
            if (folderIndex < 0) continue;
            const folderDepth = flatFolderList[folderIndex].depth;
            let targetDepth = folderDepth - 1;
            for (let i = folderIndex - 1; i >= 0 && targetDepth > 0; i--) {
              if (flatFolderList[i].depth === targetDepth) {
                ancestorIds.add(flatFolderList[i].id);
                targetDepth--;
              }
            }
          }
          for (const id of ancestorIds) visibleFolderIds.add(id);
        }
        treeVisibleItems = [];
        let idx = 0;
        const showCursor = detailMode === "treeNav";
        let html = '<div class="ht-bm-tree" style="max-height:none; border:none; border-radius:0; margin:0; padding:8px 0;">';
        for (const folder of flatFolderList) {
          if (folder.depth === 0) continue;
          if (visibleFolderIds && !visibleFolderIds.has(folder.id)) continue;
          const folderIsActive = entry && folder.id === entry.parentId;
          const indent = (folder.depth - 1) * 14;
          const collapsed = isFiltering ? false : treeCollapsed.has(folder.id);
          const children = byParent.get(folder.id);
          const count = children ? children.length : 0;
          const hasChildren = count > 0;
          const arrow = hasChildren ? collapsed ? "\u25B6" : "\u25BC" : "\xA0\xA0";
          const isCursor = showCursor && idx === treeCursorIndex;
          treeVisibleItems.push({ type: "folder", id: folder.id });
          html += `<div class="ht-bm-tree-node${folderIsActive ? " active" : ""}${isCursor ? " tree-cursor" : ""}" data-tree-idx="${idx}" style="padding-left:${10 + indent}px">`;
          html += `<span class="ht-bm-tree-collapse">${arrow}</span> \u{1F4C1} ${escapeHtml(folder.title)}${count > 0 ? ` (${count})` : ""}`;
          html += "</div>";
          idx++;
          if (children && !collapsed) {
            const entryIndent = indent + 14;
            for (const bm of children) {
              const isActive = entry && bm.id === entry.id;
              const domain = extractDomain(bm.url);
              const title = bm.title || "Untitled";
              const isCur = showCursor && idx === treeCursorIndex;
              treeVisibleItems.push({ type: "entry", id: bm.id });
              html += `<div class="ht-bm-tree-entry${isActive ? " active" : ""}${isCur ? " tree-cursor" : ""}" data-tree-idx="${idx}" style="padding-left:${10 + entryIndent}px">`;
              html += `\u{1F4C4} ${escapeHtml(title)}<span class="ht-bm-tree-domain">\xB7 ${escapeHtml(domain)}</span>`;
              html += "</div>";
              idx++;
            }
          }
        }
        html += "</div>";
        detailContent.innerHTML = html;
        if (treeCursorIndex >= treeVisibleItems.length) {
          treeCursorIndex = Math.max(0, treeVisibleItems.length - 1);
        }
        const cursorEl = detailContent.querySelector(".tree-cursor");
        if (cursorEl) {
          cursorEl.scrollIntoView({ block: "nearest" });
        }
      }, moveTreeCursor2 = function(delta) {
        if (treeVisibleItems.length === 0) return;
        const oldIdx = treeCursorIndex;
        treeCursorIndex = Math.max(0, Math.min(treeVisibleItems.length - 1, treeCursorIndex + delta));
        if (treeCursorIndex === oldIdx) return;
        const tree = detailContent.querySelector(".ht-bm-tree");
        if (!tree) return;
        const oldEl = tree.querySelector(`[data-tree-idx="${oldIdx}"]`);
        const newEl = tree.querySelector(`[data-tree-idx="${treeCursorIndex}"]`);
        if (oldEl) oldEl.classList.remove("tree-cursor");
        if (newEl) {
          newEl.classList.add("tree-cursor");
          newEl.scrollIntoView({ block: "nearest" });
        }
      }, toggleTreeCollapse2 = function() {
        const item = treeVisibleItems[treeCursorIndex];
        if (!item || item.type !== "folder") return;
        if (treeCollapsed.has(item.id)) {
          treeCollapsed.delete(item.id);
        } else {
          treeCollapsed.add(item.id);
        }
        renderTreeView2();
      }, renderTreeOpenConfirm2 = function() {
        if (!pendingTreeOpenEntry) return;
        detailHeader.textContent = "Open Bookmark";
        showDetailPlaceholder2(false);
        const path = pendingTreeOpenEntry.folderPath || "";
        detailContent.innerHTML = `<div class="ht-bm-confirm">
        <div class="ht-bm-confirm-icon">\u{1F517}</div>
        <div class="ht-bm-confirm-msg">
          Open <span class="ht-bm-confirm-title">&ldquo;${escapeHtml(pendingTreeOpenEntry.title || "Untitled")}&rdquo;</span>?
          ${path ? `<div class="ht-bm-confirm-path">${escapeHtml(path)}</div>` : ""}
        </div>
        <div class="ht-bm-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, renderTreeDeleteConfirm2 = function() {
        if (!pendingTreeDeleteEntry) return;
        detailHeader.textContent = "Confirm Delete";
        showDetailPlaceholder2(false);
        const path = pendingTreeDeleteEntry.folderPath || "";
        detailContent.innerHTML = `<div class="ht-bm-confirm">
        <div class="ht-bm-confirm-icon">\u{1F5D1}</div>
        <div class="ht-bm-confirm-msg">
          Delete this bookmark?<br>
          <span class="ht-bm-confirm-title">${escapeHtml(pendingTreeDeleteEntry.title || "Untitled")}</span>
          ${path ? `<div class="ht-bm-confirm-path">${escapeHtml(path)}</div>` : ""}
        </div>
        <div class="ht-bm-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, getDescendantFolderIds2 = function(folderId) {
        const ids = /* @__PURE__ */ new Set([folderId]);
        let found = false;
        let parentDepth = -1;
        for (const f of flatFolderList) {
          if (f.id === folderId) {
            found = true;
            parentDepth = f.depth;
            continue;
          }
          if (found) {
            if (f.depth > parentDepth) {
              ids.add(f.id);
            } else {
              break;
            }
          }
        }
        return ids;
      }, renderTreeDeleteFolderConfirm2 = function() {
        if (!pendingTreeDeleteFolder) return;
        detailHeader.textContent = "Confirm Delete";
        showDetailPlaceholder2(false);
        const descendantIds = getDescendantFolderIds2(pendingTreeDeleteFolder.id);
        const childCount = allEntries.filter((e) => e.parentId && descendantIds.has(e.parentId)).length;
        detailContent.innerHTML = `<div class="ht-bm-confirm">
        <div class="ht-bm-confirm-icon">\u{1F5D1}</div>
        <div class="ht-bm-confirm-msg">
          Delete this folder and all its contents?<br>
          <span class="ht-bm-confirm-title">${escapeHtml(pendingTreeDeleteFolder.title)}</span>
          <div class="ht-bm-confirm-path">${childCount} bookmark${childCount !== 1 ? "s" : ""} inside</div>
        </div>
        <div class="ht-bm-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, renderDeleteConfirm2 = function() {
        if (!pendingDeleteEntry) return;
        detailHeader.textContent = "Confirm Delete";
        showDetailPlaceholder2(false);
        const path = pendingDeleteEntry.folderPath || "";
        detailContent.innerHTML = `<div class="ht-bm-confirm">
        <div class="ht-bm-confirm-icon">\u{1F5D1}</div>
        <div class="ht-bm-confirm-msg">
          Delete this bookmark?<br>
          <span class="ht-bm-confirm-title">${escapeHtml(pendingDeleteEntry.title || "Untitled")}</span>
          ${path ? `<div class="ht-bm-confirm-path">${escapeHtml(path)}</div>` : ""}
        </div>
        <div class="ht-bm-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, renderMoveConfirm2 = function() {
        if (!pendingMoveEntry || !pendingMoveParentId) return;
        detailHeader.textContent = "Confirm Move";
        showDetailPlaceholder2(false);
        const fromPath = pendingMoveEntry.folderPath || "Unknown";
        const dest = moveFolders[moveTargetIndex];
        const title = pendingMoveEntry.title || "Untitled";
        const destSegments = [];
        if (dest) {
          const targetDepth = dest.depth;
          destSegments.push(dest.title);
          for (let i = moveTargetIndex - 1; i >= 0; i--) {
            if (moveFolders[i].depth < targetDepth && moveFolders[i].depth >= 1) {
              destSegments.unshift(moveFolders[i].title);
              if (moveFolders[i].depth === 1) break;
            }
          }
        }
        const toPath = destSegments.length > 0 ? destSegments.join(" \u203A ") : "folder";
        detailContent.innerHTML = `<div class="ht-bm-confirm">
        <div class="ht-bm-confirm-icon">\u{1F4C2}</div>
        <div class="ht-bm-confirm-msg">
          Move this bookmark?<br>
          <span class="ht-bm-confirm-title">${escapeHtml(title)}</span>
        </div>
        <div class="ht-bm-confirm-arrow">
          <span class="ht-bm-confirm-from">${escapeHtml(fromPath)}</span>
          <span style="font-weight:700">\u2192</span>
          <span class="ht-bm-confirm-to">${escapeHtml(toPath)}</span>
        </div>
        <div class="ht-bm-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, updateFooter2 = function() {
        detailHeaderClose.style.display = detailMode === "tree" ? "none" : "block";
        detailPane.classList.toggle("focused", detailMode === "treeNav");
        resultsPane.classList.toggle("dimmed", detailMode === "treeNav");
        if (detailMode === "confirmDelete" || detailMode === "confirmMove") {
          footerEl.innerHTML = `<div class="ht-footer-row">
          <span>Y / ${acceptKey} confirm</span>
          <span>N / ${closeKey} cancel</span>
        </div>`;
        } else if (detailMode === "move") {
          footerEl.innerHTML = `<div class="ht-footer-row">
          <span>j/k (vim) ${upKey}/${downKey} nav</span>
          <span>${acceptKey} confirm</span>
          <span>${closeKey} / M back</span>
        </div>`;
        } else if (detailMode === "treeNav") {
          if (pendingTreeOpenEntry || pendingTreeDeleteEntry || pendingTreeDeleteFolder) {
            footerEl.innerHTML = `<div class="ht-footer-row">
            <span>Y / ${acceptKey} confirm</span>
            <span>N / ${closeKey} cancel</span>
          </div>`;
          } else {
            footerEl.innerHTML = `<div class="ht-footer-row">
            <span>j/k (vim) ${upKey}/${downKey} nav</span>
            <span>D del</span>
            <span>${acceptKey} fold/open</span>
            <span>${closeKey} / T back</span>
          </div>`;
          }
        } else {
          footerEl.innerHTML = `<div class="ht-footer-row">
          <span>j/k (vim) ${upKey}/${downKey} nav</span>
          <span>${switchKey} list</span>
          <span>${acceptKey} open</span>
          <span>${closeKey} close</span>
        </div>
        <div class="ht-footer-row">
          <span>T focus tree</span>
          <span>C clear</span>
          <span>D del</span>
          <span>M move</span>
        </div>`;
        }
      }, keyHandler2 = function(event) {
        if (!panelOpen) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (detailMode === "move") {
          if (event.key === "Escape" || event.key.toLowerCase() === "m") {
            event.preventDefault();
            event.stopPropagation();
            detailMode = "tree";
            scheduleDetailUpdate2();
            updateFooter2();
            return;
          }
          if (event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            const entry = filtered[activeIndex];
            if (!entry) return;
            pendingMoveEntry = entry;
            pendingMoveParentId = moveFolders[moveTargetIndex]?.id || null;
            detailMode = "confirmMove";
            renderMoveConfirm2();
            updateFooter2();
            return;
          }
          const vim = config.navigationMode === "vim";
          if (event.key === "ArrowDown" || vim && event.key.toLowerCase() === "j") {
            event.preventDefault();
            event.stopPropagation();
            moveTargetIndex = Math.min(moveTargetIndex + 1, moveFolders.length - 1);
            renderMoveView2();
            return;
          }
          if (event.key === "ArrowUp" || vim && event.key.toLowerCase() === "k") {
            event.preventDefault();
            event.stopPropagation();
            moveTargetIndex = Math.max(moveTargetIndex - 1, 0);
            renderMoveView2();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (detailMode === "treeNav") {
          if (pendingTreeOpenEntry) {
            if (event.key === "y" || event.key === "Enter") {
              event.preventDefault();
              event.stopPropagation();
              const entry = pendingTreeOpenEntry;
              pendingTreeOpenEntry = null;
              openBookmark(entry);
              return;
            }
            if (event.key === "n" || event.key === "Escape") {
              event.preventDefault();
              event.stopPropagation();
              pendingTreeOpenEntry = null;
              renderTreeView2();
              updateFooter2();
              return;
            }
            event.stopPropagation();
            return;
          }
          if (pendingTreeDeleteEntry) {
            if (event.key === "y" || event.key === "Enter") {
              event.preventDefault();
              event.stopPropagation();
              removeTreeBookmark();
              updateFooter2();
              return;
            }
            if (event.key === "n" || event.key === "Escape") {
              event.preventDefault();
              event.stopPropagation();
              pendingTreeDeleteEntry = null;
              renderTreeView2();
              updateFooter2();
              return;
            }
            event.stopPropagation();
            return;
          }
          if (pendingTreeDeleteFolder) {
            if (event.key === "y" || event.key === "Enter") {
              event.preventDefault();
              event.stopPropagation();
              removeTreeFolder();
              updateFooter2();
              return;
            }
            if (event.key === "n" || event.key === "Escape") {
              event.preventDefault();
              event.stopPropagation();
              pendingTreeDeleteFolder = null;
              renderTreeView2();
              updateFooter2();
              return;
            }
            event.stopPropagation();
            return;
          }
          if (event.key === "Escape" || event.key.toLowerCase() === "t") {
            event.preventDefault();
            event.stopPropagation();
            detailMode = "tree";
            scheduleDetailUpdate2();
            updateFooter2();
            return;
          }
          if (event.key.toLowerCase() === "d" && !event.ctrlKey && !event.altKey && !event.metaKey) {
            event.preventDefault();
            event.stopPropagation();
            const item = treeVisibleItems[treeCursorIndex];
            if (!item) return;
            if (item.type === "entry") {
              const entry = allEntries.find((bm) => bm.id === item.id);
              if (!entry) return;
              pendingTreeDeleteEntry = entry;
              renderTreeDeleteConfirm2();
            } else {
              const folder = flatFolderList.find((f) => f.id === item.id);
              if (!folder) return;
              pendingTreeDeleteFolder = { id: folder.id, title: folder.title };
              renderTreeDeleteFolderConfirm2();
            }
            updateFooter2();
            return;
          }
          if (event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            const item = treeVisibleItems[treeCursorIndex];
            if (!item) return;
            if (item.type === "folder") {
              toggleTreeCollapse2();
            } else {
              const entry = allEntries.find((bm) => bm.id === item.id);
              if (entry) {
                pendingTreeOpenEntry = entry;
                renderTreeOpenConfirm2();
                updateFooter2();
              }
            }
            return;
          }
          const vim = config.navigationMode === "vim";
          if (event.key === "ArrowDown" || vim && event.key.toLowerCase() === "j") {
            event.preventDefault();
            event.stopPropagation();
            moveTreeCursor2(1);
            return;
          }
          if (event.key === "ArrowUp" || vim && event.key.toLowerCase() === "k") {
            event.preventDefault();
            event.stopPropagation();
            moveTreeCursor2(-1);
            return;
          }
          event.stopPropagation();
          return;
        }
        if (detailMode === "confirmDelete") {
          if (event.key === "y" || event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            pendingDeleteEntry = null;
            detailMode = "tree";
            removeSelectedBookmark();
            updateFooter2();
            return;
          }
          if (event.key === "n" || event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            pendingDeleteEntry = null;
            detailMode = "tree";
            scheduleDetailUpdate2();
            updateFooter2();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (detailMode === "confirmMove") {
          if (event.key === "y" || event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            pendingMoveEntry = null;
            pendingMoveParentId = null;
            detailMode = "tree";
            confirmMove();
            updateFooter2();
            return;
          }
          if (event.key === "n" || event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            pendingMoveEntry = null;
            pendingMoveParentId = null;
            detailMode = "tree";
            scheduleDetailUpdate2();
            updateFooter2();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (matchesAction(event, config, "search", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (event.key === "Backspace" && focusedPane === "input" && input.value === "" && activeFilters.length > 0) {
          event.preventDefault();
          activeFilters.pop();
          input.value = activeFilters.map((f) => `/${f}`).join(" ") + (activeFilters.length ? " " : "");
          updateTitle2();
          updateFilterPills2();
          currentQuery = "";
          applyFilter2();
          renderResults2();
          return;
        }
        if (matchesAction(event, config, "search", "accept")) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered[activeIndex]) openBookmark(filtered[activeIndex]);
          return;
        }
        if (event.key === "Tab" && !event.ctrlKey && !event.altKey && !event.metaKey) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length === 0) return;
          if (focusedPane === "input") {
            if (activeItemEl) {
              activeItemEl.focus();
            } else {
              const first = resultsList.querySelector(".ht-bm-item");
              if (first) first.focus();
            }
            setFocusedPane2("results");
          } else {
            input.focus();
            setFocusedPane2("input");
          }
          return;
        }
        const inputFocused = focusedPane === "input";
        if (event.key.toLowerCase() === "d" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          const entry = filtered[activeIndex];
          if (!entry) return;
          pendingDeleteEntry = entry;
          detailMode = "confirmDelete";
          renderDeleteConfirm2();
          updateFooter2();
          return;
        }
        if (event.key.toLowerCase() === "m" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          if (!filtered[activeIndex]) return;
          detailMode = "move";
          moveFolders = flatFolderList.filter((f) => f.depth > 0);
          moveTargetIndex = 0;
          renderMoveView2();
          updateFooter2();
          return;
        }
        if (event.key.toLowerCase() === "t" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          if (flatFolderList.length === 0) return;
          detailMode = "treeNav";
          treeCursorIndex = 0;
          renderTreeView2();
          const entry = filtered[activeIndex];
          if (entry) {
            const matchIdx = treeVisibleItems.findIndex(
              (item) => item.type === "entry" && item.id === entry.id
            );
            if (matchIdx >= 0) {
              treeCursorIndex = matchIdx;
              renderTreeView2();
            }
          }
          updateFooter2();
          return;
        }
        if (event.key.toLowerCase() === "c" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          input.value = "";
          activeFilters = [];
          currentQuery = "";
          updateTitle2();
          updateFilterPills2();
          applyFilter2();
          renderResults2();
          scheduleDetailUpdate2();
          return;
        }
        if (matchesAction(event, config, "search", "moveDown")) {
          const lk = event.key.toLowerCase();
          if ((lk === "j" || lk === "k") && inputFocused) return;
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length > 0) {
            setActiveIndex2(Math.min(activeIndex + 1, filtered.length - 1));
          }
          return;
        }
        if (matchesAction(event, config, "search", "moveUp")) {
          const lk = event.key.toLowerCase();
          if ((lk === "j" || lk === "k") && inputFocused) return;
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length > 0) {
            setActiveIndex2(Math.max(activeIndex - 1, 0));
          }
          return;
        }
        event.stopPropagation();
      };
      var setFocusedPane = setFocusedPane2, close = close2, parseInput = parseInput2, updateTitle = updateTitle2, updateFilterPills = updateFilterPills2, buildHighlightRegex = buildHighlightRegex2, highlightMatch = highlightMatch2, getPoolItem = getPoolItem2, bindPoolItem = bindPoolItem2, renderVisibleItems = renderVisibleItems2, renderResults = renderResults2, scheduleVisibleRender = scheduleVisibleRender2, setActiveIndex = setActiveIndex2, scrollActiveIntoView = scrollActiveIntoView2, showDetailPlaceholder = showDetailPlaceholder2, scheduleDetailUpdate = scheduleDetailUpdate2, updateDetail = updateDetail2, scoreMatch = scoreMatch2, applyFilter = applyFilter2, renderMoveView = renderMoveView2, renderTreeView = renderTreeView2, moveTreeCursor = moveTreeCursor2, toggleTreeCollapse = toggleTreeCollapse2, renderTreeOpenConfirm = renderTreeOpenConfirm2, renderTreeDeleteConfirm = renderTreeDeleteConfirm2, getDescendantFolderIds = getDescendantFolderIds2, renderTreeDeleteFolderConfirm = renderTreeDeleteFolderConfirm2, renderDeleteConfirm = renderDeleteConfirm2, renderMoveConfirm = renderMoveConfirm2, updateFooter = updateFooter2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      let panelOpen = true;
      const upKey = keyToDisplay(config.bindings.search.moveUp.key);
      const downKey = keyToDisplay(config.bindings.search.moveDown.key);
      const switchKey = keyToDisplay(config.bindings.search.switchPane.key);
      const acceptKey = keyToDisplay(config.bindings.search.accept.key);
      const closeKey = keyToDisplay(config.bindings.search.close.key);
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + bookmarks_default;
      shadow.appendChild(style);
      const wrapper = document.createElement("div");
      wrapper.innerHTML = `
      <div class="ht-backdrop"></div>
      <div class="ht-bookmark-container">
        <div class="ht-titlebar">
          <div class="ht-traffic-lights">
            <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
          </div>
          <span class="ht-titlebar-text">
            <span class="ht-bm-title-label">Bookmarks</span>
            <span class="ht-bm-title-sep">|</span>
            <span class="ht-bm-title-filters">Filters:
              <span class="ht-bm-title-filter" data-filter="folder">/folder</span>
            </span>
            <span class="ht-bm-title-count"></span>
          </span>
          ${vimBadgeHtml(config)}
        </div>
        <div class="ht-bookmark-body">
          <div class="ht-bookmark-input-wrap">
            <span class="ht-bookmark-prompt">&gt;</span>
            <input type="text" class="ht-bookmark-input" placeholder="Filter bookmarks..." />
          </div>
          <div class="ht-bm-filter-pills"></div>
          <div class="ht-bookmark-columns">
            <div class="ht-bm-results-pane">
              <div class="ht-bm-results-sentinel"></div>
              <div class="ht-bm-results-list"></div>
            </div>
            <div class="ht-bm-detail-pane">
              <div class="ht-bm-detail-header"><span class="ht-bm-detail-header-text">Bookmark Tree</span><button class="ht-bm-detail-header-close" title="Back">&times;</button></div>
              <div class="ht-bm-detail-placeholder">No bookmarks</div>
              <div class="ht-bm-detail-content" style="display:none;"></div>
            </div>
          </div>
          <div class="ht-footer">
            <div class="ht-footer-row">
              <span>j/k (vim) ${upKey}/${downKey} nav</span>
              <span>${switchKey} list</span>
              <span>${acceptKey} open</span>
              <span>${closeKey} close</span>
            </div>
            <div class="ht-footer-row">
              <span>T focus tree</span>
              <span>C clear</span>
              <span>D del</span>
              <span>M move</span>
            </div>
          </div>
        </div>
      </div>
    `;
      shadow.appendChild(wrapper);
      const input = shadow.querySelector(".ht-bookmark-input");
      const resultsList = shadow.querySelector(".ht-bm-results-list");
      const resultsSentinel = shadow.querySelector(".ht-bm-results-sentinel");
      const resultsPane = shadow.querySelector(".ht-bm-results-pane");
      const detailHeader = shadow.querySelector(".ht-bm-detail-header-text");
      const detailHeaderClose = shadow.querySelector(".ht-bm-detail-header-close");
      const detailPane = shadow.querySelector(".ht-bm-detail-pane");
      const detailPlaceholder = shadow.querySelector(".ht-bm-detail-placeholder");
      const detailContent = shadow.querySelector(".ht-bm-detail-content");
      const closeBtn = shadow.querySelector(".ht-dot-close");
      const backdrop = shadow.querySelector(".ht-backdrop");
      const titleFilterSpans = shadow.querySelectorAll(".ht-bm-title-filter");
      const titleCount = shadow.querySelector(".ht-bm-title-count");
      const filterPills = shadow.querySelector(".ht-bm-filter-pills");
      const footerEl = shadow.querySelector(".ht-footer");
      let allEntries = [];
      let filtered = [];
      let activeIndex = 0;
      let activeItemEl = null;
      let focusedPane = "input";
      let activeFilters = [];
      let currentQuery = "";
      let vsStart = 0;
      let vsEnd = 0;
      let itemPool = [];
      let highlightRegex = null;
      let detailRafId = null;
      let scrollRafId = null;
      let folderTree = [];
      let flatFolderList = [];
      let detailMode = "tree";
      let moveFolders = [];
      let moveTargetIndex = 0;
      let pendingDeleteEntry = null;
      let pendingMoveEntry = null;
      let pendingMoveParentId = null;
      let treeCursorIndex = 0;
      let treeCollapsed = /* @__PURE__ */ new Set();
      let treeVisibleItems = [];
      let pendingTreeOpenEntry = null;
      let pendingTreeDeleteEntry = null;
      let pendingTreeDeleteFolder = null;
      resultsPane.addEventListener("scroll", scheduleVisibleRender2, { passive: true });
      async function openBookmark(entry) {
        if (!entry) return;
        close2();
        await import_webextension_polyfill5.default.runtime.sendMessage({
          type: "OPEN_BOOKMARK_TAB",
          url: entry.url
        });
      }
      async function removeSelectedBookmark() {
        const entry = filtered[activeIndex];
        if (!entry) return;
        const result = await import_webextension_polyfill5.default.runtime.sendMessage({
          type: "BOOKMARK_REMOVE",
          id: entry.id,
          url: entry.url
        });
        if (result.ok) {
          showFeedback(`Removed: ${entry.title || entry.url}`);
          allEntries = allEntries.filter((e) => e.id !== entry.id);
          applyFilter2();
          renderResults2();
        } else {
          showFeedback("Failed to remove bookmark");
        }
      }
      async function confirmMove() {
        const entry = filtered[activeIndex];
        if (!entry) return;
        const parentId = moveFolders[moveTargetIndex]?.id;
        if (!parentId) return;
        const result = await import_webextension_polyfill5.default.runtime.sendMessage({
          type: "BOOKMARK_MOVE",
          id: entry.id,
          parentId
        });
        if (result.ok) {
          const destLabel = moveFolders[moveTargetIndex]?.title || "folder";
          showFeedback(`Moved to: ${destLabel}`);
          allEntries = await import_webextension_polyfill5.default.runtime.sendMessage({
            type: "BOOKMARK_LIST"
          });
          applyFilter2();
          renderResults2();
        } else {
          showFeedback("Failed to move bookmark");
        }
        detailMode = "tree";
        scheduleDetailUpdate2();
        updateFooter2();
      }
      async function removeTreeBookmark() {
        if (!pendingTreeDeleteEntry) return;
        const entry = pendingTreeDeleteEntry;
        pendingTreeDeleteEntry = null;
        const result = await import_webextension_polyfill5.default.runtime.sendMessage({
          type: "BOOKMARK_REMOVE",
          id: entry.id,
          url: entry.url
        });
        if (result.ok) {
          showFeedback(`Removed: ${entry.title || entry.url}`);
          allEntries = allEntries.filter((e) => e.id !== entry.id);
          applyFilter2();
          renderTreeView2();
        } else {
          showFeedback("Failed to remove bookmark");
          renderTreeView2();
        }
      }
      async function removeTreeFolder() {
        if (!pendingTreeDeleteFolder) return;
        const folder = pendingTreeDeleteFolder;
        pendingTreeDeleteFolder = null;
        const descendantIds = getDescendantFolderIds2(folder.id);
        const result = await import_webextension_polyfill5.default.runtime.sendMessage({
          type: "BOOKMARK_REMOVE_TREE",
          id: folder.id
        });
        if (result.ok) {
          showFeedback(`Removed folder: ${folder.title}`);
          allEntries = allEntries.filter((e) => !e.parentId || !descendantIds.has(e.parentId));
          const folders2 = await import_webextension_polyfill5.default.runtime.sendMessage({ type: "BOOKMARK_FOLDERS" });
          folderTree = folders2;
          flatFolderList = flattenFolders(folders2);
          applyFilter2();
          renderTreeView2();
        } else {
          showFeedback("Failed to remove folder");
          renderTreeView2();
        }
      }
      closeBtn.addEventListener("click", close2);
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      detailHeaderClose.addEventListener("click", () => {
        if (detailMode !== "tree") {
          detailMode = "tree";
          pendingDeleteEntry = null;
          pendingMoveEntry = null;
          pendingMoveParentId = null;
          pendingTreeOpenEntry = null;
          pendingTreeDeleteEntry = null;
          scheduleDetailUpdate2();
          updateFooter2();
        }
      });
      resultsList.addEventListener("click", (event) => {
        const item = event.target.closest(".ht-bm-item");
        if (!item || !item.dataset.index) return;
        setActiveIndex2(Number(item.dataset.index));
      });
      resultsList.addEventListener("dblclick", (event) => {
        const item = event.target.closest(".ht-bm-item");
        if (!item || !item.dataset.index) return;
        const idx = Number(item.dataset.index);
        activeIndex = idx;
        if (filtered[idx]) openBookmark(filtered[idx]);
      });
      input.addEventListener("focus", () => {
        setFocusedPane2("input");
      });
      resultsList.addEventListener("focus", () => {
        setFocusedPane2("results");
      }, true);
      resultsPane.addEventListener("wheel", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (filtered.length === 0) return;
        if (event.deltaY > 0) {
          setActiveIndex2(Math.min(activeIndex + 1, filtered.length - 1));
        } else {
          setActiveIndex2(Math.max(activeIndex - 1, 0));
        }
      });
      detailContent.addEventListener("click", (event) => {
        if (detailMode !== "tree" && detailMode !== "treeNav") return;
        const target = event.target.closest("[data-tree-idx]");
        if (!target) return;
        const idx = Number(target.dataset.treeIdx);
        if (isNaN(idx) || idx < 0 || idx >= treeVisibleItems.length) return;
        const item = treeVisibleItems[idx];
        if (item.type === "folder") {
          treeCursorIndex = idx;
          toggleTreeCollapse2();
        } else if (detailMode === "treeNav") {
          const oldIdx = treeCursorIndex;
          treeCursorIndex = idx;
          const tree = detailContent.querySelector(".ht-bm-tree");
          if (tree) {
            const oldEl = tree.querySelector(`[data-tree-idx="${oldIdx}"]`);
            const newEl = tree.querySelector(`[data-tree-idx="${idx}"]`);
            if (oldEl) oldEl.classList.remove("tree-cursor");
            if (newEl) {
              newEl.classList.add("tree-cursor");
              newEl.scrollIntoView({ block: "nearest" });
            }
          }
        }
      });
      detailContent.addEventListener("dblclick", (event) => {
        if (detailMode !== "treeNav") return;
        const target = event.target.closest("[data-tree-idx]");
        if (!target) return;
        const idx = Number(target.dataset.treeIdx);
        if (isNaN(idx) || idx < 0 || idx >= treeVisibleItems.length) return;
        const item = treeVisibleItems[idx];
        if (item.type !== "entry") return;
        treeCursorIndex = idx;
        const entry = allEntries.find((bm) => bm.id === item.id);
        if (entry) {
          pendingTreeOpenEntry = entry;
          renderTreeOpenConfirm2();
          updateFooter2();
        }
      });
      detailContent.addEventListener("wheel", (event) => {
        if (detailMode !== "treeNav") return;
        event.preventDefault();
        event.stopPropagation();
        moveTreeCursor2(event.deltaY > 0 ? 1 : -1);
      });
      input.addEventListener("input", () => {
        const { filters, query } = parseInput2(input.value);
        activeFilters = filters;
        currentQuery = query;
        updateTitle2();
        updateFilterPills2();
        applyFilter2();
        renderResults2();
      });
      const [bookmarks, folders] = await Promise.all([
        import_webextension_polyfill5.default.runtime.sendMessage({ type: "BOOKMARK_LIST" }),
        import_webextension_polyfill5.default.runtime.sendMessage({ type: "BOOKMARK_FOLDERS" })
      ]);
      allEntries = bookmarks;
      folderTree = folders;
      flatFolderList = flattenFolders(folders);
      filtered = [...allEntries];
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      renderResults2();
      input.focus();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open bookmark overlay:", err);
    }
  }

  // src/lib/addBookmark/addBookmark.ts
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());

  // src/lib/addBookmark/addBookmark.css
  var addBookmark_default = "/* Add Bookmark overlay \u2014 file/folder creation wizard */\n\n.ht-addbm-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 420px); max-height: min(86vh, 520px); background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border); border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-addbm-list { flex: 1; overflow-y: auto; padding: 4px 0; max-height: 340px; }\n.ht-addbm-item {\n  padding: 8px 14px; cursor: pointer; font-size: 12px;\n  color: var(--ht-color-text); display: flex; align-items: center; gap: 8px;\n  outline: none; user-select: none;\n}\n.ht-addbm-item:hover { background: var(--ht-color-border-soft); }\n.ht-addbm-item.active {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-accent);\n}\n.ht-addbm-icon { flex-shrink: 0; font-size: 14px; }\n.ht-addbm-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.ht-addbm-desc { font-size: 10px; color: var(--ht-color-text-muted); }\n.ht-addbm-none {\n  padding: 8px 14px; cursor: pointer; font-size: 12px;\n  color: var(--ht-color-text-muted); display: flex; align-items: center; gap: 8px;\n  outline: none; user-select: none; font-style: italic;\n}\n.ht-addbm-none:hover { background: var(--ht-color-border-soft); }\n.ht-addbm-none.active {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-accent);\n}\n.ht-addbm-input-wrap {\n  display: flex; align-items: center; padding: 8px 14px;\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-addbm-prompt {\n  color: var(--ht-color-accent); margin-right: 8px; font-weight: 600; font-size: 13px;\n}\n.ht-addbm-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text); font-family: inherit; font-size: 13px; caret-color: var(--ht-color-accent);\n}\n.ht-addbm-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-addbm-error {\n  padding: 4px 14px; font-size: 10px; color: var(--ht-color-danger); display: none;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-addbm-container { border-radius: 8px; }\n  .ht-addbm-list { max-height: min(56vh, 300px); }\n  .ht-addbm-input-wrap { padding: 8px 10px; }\n}\n";

  // src/lib/addBookmark/addBookmark.ts
  function flattenFolders2(folders) {
    const flat = [];
    function walk(nodes) {
      for (const folder of nodes) {
        flat.push({ id: folder.id, title: folder.title, depth: folder.depth });
        if (folder.children.length > 0) walk(folder.children);
      }
    }
    walk(folders);
    return flat;
  }
  async function openAddBookmarkOverlay(config) {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        removePanelHost();
      }, renderChooseType2 = function() {
        titleText.textContent = "Add Bookmark";
        activeIndex = 0;
        body.innerHTML = `<div class="ht-addbm-list">
        <div class="ht-addbm-item active" data-idx="0">
          <span class="ht-addbm-icon">\u{1F4C4}</span>
          <div>
            <div class="ht-addbm-name">Create a Bookmark</div>
            <div class="ht-addbm-desc">Save current page as a bookmark</div>
          </div>
        </div>
        <div class="ht-addbm-item" data-idx="1">
          <span class="ht-addbm-icon">\u{1F4C1}</span>
          <div>
            <div class="ht-addbm-name">Create a New Folder</div>
            <div class="ht-addbm-desc">Create an empty folder</div>
          </div>
        </div>
        <div class="ht-addbm-item" data-idx="2">
          <span class="ht-addbm-icon">\u{1F4C2}</span>
          <div>
            <div class="ht-addbm-name">Bookmark into New Folder</div>
            <div class="ht-addbm-desc">Create a folder and save current page in it</div>
          </div>
        </div>
      </div>`;
        footer.innerHTML = `<div class="ht-footer-row">
        <span>j/k (vim) \u2191/\u2193 nav</span>
         <span>Enter select</span>
         <span>Esc cancel</span>
      </div>`;
        const list = body.querySelector(".ht-addbm-list");
        list.addEventListener("click", (event) => {
          const item = event.target.closest("[data-idx]");
          if (!item) return;
          const idx = parseInt(item.dataset.idx);
          chosenType = idx === 0 ? "file" : idx === 1 ? "folder" : "folderAndFile";
          transitionToChooseDest();
        });
      }, renderChooseDest2 = function() {
        let html = `<div class="ht-addbm-list">
        <div class="ht-addbm-none${activeIndex === 0 ? " active" : ""}" data-idx="0">
          \u2014 Root (no folder)
        </div>`;
        for (let i = 0; i < flatFolders.length; i++) {
          const folder = flatFolders[i];
          const indent = folder.depth > 0 ? `padding-left:${14 + folder.depth * 16}px;` : "";
          html += `<div class="ht-addbm-item${activeIndex === i + 1 ? " active" : ""}" data-idx="${i + 1}" style="${indent}">
          <span class="ht-addbm-icon">\u{1F4C1}</span>
          <span class="ht-addbm-name">${escapeHtml(folder.title)}</span>
        </div>`;
        }
        html += `</div>`;
        body.innerHTML = html;
        footer.innerHTML = `<div class="ht-footer-row">
        <span>j/k (vim) \u2191/\u2193 nav</span>
         <span>Enter select</span>
         <span>Esc back</span>
      </div>`;
        const list = body.querySelector(".ht-addbm-list");
        list.addEventListener("click", (event) => {
          const item = event.target.closest("[data-idx]");
          if (!item) return;
          const idx = parseInt(item.dataset.idx);
          confirmDest(idx);
        });
      }, getParentId2 = function(idx) {
        return idx === 0 ? void 0 : flatFolders[idx - 1]?.id;
      }, getParentLabel2 = function(idx) {
        return idx === 0 ? "" : ` in ${flatFolders[idx - 1]?.title || "folder"}`;
      }, transitionToNameInput2 = function(destIdx) {
        step = "nameInput";
        const destLabel = destIdx === 0 ? "root" : flatFolders[destIdx - 1]?.title || "folder";
        titleText.textContent = `New folder in ${destLabel}`;
        body.innerHTML = `
        <div class="ht-addbm-input-wrap">
          <span class="ht-addbm-prompt">Name:</span>
          <input type="text" class="ht-addbm-input"
                 placeholder="e.g. Work, Research, Recipes..." maxlength="60" />
        </div>
        <div class="ht-addbm-error"></div>`;
        footer.innerHTML = `<div class="ht-footer-row">
        <span>Enter create</span>
        <span>Esc back</span>
      </div>`;
        nameInputEl = body.querySelector(".ht-addbm-input");
        errorEl = body.querySelector(".ht-addbm-error");
        nameInputEl.focus();
        nameInputEl.dataset.destIdx = String(destIdx);
      }, showError2 = function(message) {
        if (!errorEl) return;
        errorEl.textContent = message;
        errorEl.style.display = "";
        if (nameInputEl) nameInputEl.style.borderBottom = "1px solid #ff5f57";
        setTimeout(() => {
          if (errorEl) errorEl.style.display = "none";
          if (nameInputEl) nameInputEl.style.borderBottom = "";
        }, 2e3);
      }, updateHighlight2 = function(newIndex, totalItems) {
        if (newIndex < 0 || newIndex >= totalItems) return;
        const items = body.querySelectorAll("[data-idx]");
        items.forEach((el) => el.classList.remove("active"));
        activeIndex = newIndex;
        const activeEl = items[newIndex];
        if (activeEl) {
          activeEl.classList.add("active");
          activeEl.scrollIntoView({ block: "nearest" });
        }
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (step === "nameInput") {
          if (event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            step = "chooseDest";
            nameInputEl = null;
            errorEl = null;
            renderChooseDest2();
            return;
          }
          if (event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            confirmFolderCreate();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          if (step === "chooseDest") {
            step = "chooseType";
            activeIndex = 0;
            renderChooseType2();
          } else {
            close2();
          }
          return;
        }
        if (event.key === "Enter") {
          event.preventDefault();
          event.stopPropagation();
          if (step === "chooseType") {
            chosenType = activeIndex === 0 ? "file" : activeIndex === 1 ? "folder" : "folderAndFile";
            transitionToChooseDest();
          } else if (step === "chooseDest") {
            confirmDest(activeIndex);
          }
          return;
        }
        const totalItems = step === "chooseType" ? 3 : flatFolders.length + 1;
        const vim = config.navigationMode === "vim";
        if (event.key === "ArrowDown" || vim && event.key === "j") {
          event.preventDefault();
          event.stopPropagation();
          updateHighlight2(Math.min(activeIndex + 1, totalItems - 1), totalItems);
          return;
        }
        if (event.key === "ArrowUp" || vim && event.key === "k") {
          event.preventDefault();
          event.stopPropagation();
          updateHighlight2(Math.max(activeIndex - 1, 0), totalItems);
          return;
        }
        event.stopPropagation();
      };
      var close = close2, renderChooseType = renderChooseType2, renderChooseDest = renderChooseDest2, getParentId = getParentId2, getParentLabel = getParentLabel2, transitionToNameInput = transitionToNameInput2, showError = showError2, updateHighlight = updateHighlight2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + addBookmark_default;
      shadow.appendChild(style);
      const backdrop = document.createElement("div");
      backdrop.className = "ht-backdrop";
      shadow.appendChild(backdrop);
      const panel = document.createElement("div");
      panel.className = "ht-addbm-container";
      shadow.appendChild(panel);
      const titlebar = document.createElement("div");
      titlebar.className = "ht-titlebar";
      titlebar.innerHTML = `
      <div class="ht-traffic-lights">
        <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
      </div>
      <span class="ht-titlebar-text">Add Bookmark</span>
      ${vimBadgeHtml(config)}`;
      panel.appendChild(titlebar);
      const body = document.createElement("div");
      body.style.cssText = "display:flex;flex-direction:column;flex:1;overflow:hidden;";
      panel.appendChild(body);
      const footer = document.createElement("div");
      footer.className = "ht-footer";
      panel.appendChild(footer);
      const titleText = titlebar.querySelector(".ht-titlebar-text");
      let step = "chooseType";
      let chosenType = "file";
      let activeIndex = 0;
      let flatFolders = [];
      let nameInputEl = null;
      let errorEl = null;
      async function transitionToChooseDest() {
        step = "chooseDest";
        activeIndex = 0;
        const label = chosenType === "file" ? "save bookmark" : "create folder";
        titleText.textContent = `Choose where to ${label}`;
        const folders = await import_webextension_polyfill6.default.runtime.sendMessage({
          type: "BOOKMARK_FOLDERS"
        });
        flatFolders = flattenFolders2(folders);
        renderChooseDest2();
      }
      async function confirmDest(idx) {
        if (chosenType === "file") {
          const parentId = getParentId2(idx);
          const bookmarkAddRequest = { type: "BOOKMARK_ADD" };
          if (parentId) bookmarkAddRequest.parentId = parentId;
          const result = await import_webextension_polyfill6.default.runtime.sendMessage(bookmarkAddRequest);
          if (result.ok) {
            showFeedback(`Bookmarked: ${result.title || "current page"}${getParentLabel2(idx)}`);
          } else {
            showFeedback("Failed to add bookmark");
          }
          close2();
        } else {
          transitionToNameInput2(idx);
        }
      }
      async function confirmFolderCreate() {
        if (!nameInputEl) return;
        const name = nameInputEl.value.trim();
        if (!name) {
          showError2("A folder name is required");
          return;
        }
        const destIdx = parseInt(nameInputEl.dataset.destIdx || "0");
        const parentId = getParentId2(destIdx);
        const createFolderRequest = {
          type: "BOOKMARK_CREATE_FOLDER",
          title: name
        };
        if (parentId) createFolderRequest.parentId = parentId;
        const result = await import_webextension_polyfill6.default.runtime.sendMessage(createFolderRequest);
        if (!result.ok) {
          showFeedback(result.reason || "Failed to create folder");
          close2();
          return;
        }
        if (chosenType === "folderAndFile" && result.id) {
          const addResult = await import_webextension_polyfill6.default.runtime.sendMessage({
            type: "BOOKMARK_ADD",
            parentId: result.id
          });
          if (addResult.ok) {
            showFeedback(`Created folder "${name}" and bookmarked: ${addResult.title || "current page"}`);
          } else {
            showFeedback(`Created folder "${name}" but failed to add bookmark`);
          }
        } else {
          showFeedback(`Created folder: ${name}${getParentLabel2(destIdx)}`);
        }
        close2();
      }
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      titlebar.querySelector(".ht-dot-close").addEventListener("click", close2);
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      renderChooseType2();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open add-bookmark overlay:", err);
    }
  }

  // src/lib/history/history.ts
  var import_webextension_polyfill7 = __toESM(require_browser_polyfill());

  // src/lib/history/history.css
  var history_default = "/* History overlay \u2014 browse and search browser history with fuzzy filter */\n\n.ht-history-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(92vw, 980px); height: min(78vh, 680px); min-height: 300px;\n  background: var(--ht-color-bg); border: 1px solid var(--ht-color-border);\n  border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-history-body { flex: 1; display: flex; flex-direction: column; overflow: hidden; background: var(--ht-color-bg); }\n.ht-history-input-wrap {\n  display: flex; align-items: center; padding: 8px 14px;\n  border-bottom: 1px solid var(--ht-color-border-soft); background: var(--ht-color-bg-elevated);\n}\n.ht-history-prompt { color: var(--ht-color-accent); margin-right: 8px; font-weight: 600; font-size: 14px; }\n.ht-history-input {\n  flex: 1; background: transparent; border: none; outline: none;\n  color: var(--ht-color-text); font-family: inherit; font-size: 13px;\n  caret-color: var(--ht-color-text-strong); caret-shape: block;\n}\n.ht-history-input::placeholder { color: var(--ht-color-text-dim); }\n.ht-history-columns { flex: 1; display: flex; overflow: hidden; background: var(--ht-color-bg); }\n\n/* Left pane: results list */\n.ht-hist-results-pane {\n  width: 40%; border-right: 1px solid var(--ht-color-border-soft);\n  overflow-y: auto; position: relative; background: var(--ht-color-bg);\n}\n.ht-hist-results-sentinel { width: 100%; pointer-events: none; }\n.ht-hist-results-list {\n  position: absolute; top: 0; left: 0; right: 0; padding: 0;\n  will-change: transform;\n}\n.ht-hist-item {\n  padding: 4px 10px; cursor: pointer;\n  border-bottom: 1px solid var(--ht-color-border-faint);\n  display: flex; align-items: center;\n  height: 44px; box-sizing: border-box;\n  outline: none; user-select: none;\n}\n.ht-hist-item:hover { background: var(--ht-color-border-soft); }\n.ht-hist-item.active {\n  background: var(--ht-color-accent-active);\n  border-left: 2px solid var(--ht-color-accent);\n}\n.ht-hist-results-pane.focused .ht-hist-item.active {\n  background: var(--ht-color-focus-active);\n  border-left: 2px solid var(--ht-color-text-strong);\n}\n/* Dim active item when tree pane is focused (treeNav mode) */\n.ht-hist-results-pane.dimmed .ht-hist-item.active {\n  background: var(--ht-color-border-faint);\n  border-left: 2px solid var(--ht-color-surface-strong);\n}\n.ht-hist-info { flex: 1; overflow: hidden; }\n.ht-hist-title {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 12px; color: var(--ht-color-text);\n}\n.ht-hist-title mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-hist-url-line {\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  font-size: 10px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-hist-url-line mark {\n  background: var(--ht-color-mark-bg); color: var(--ht-color-bg); border-radius: 2px; padding: 0 1px;\n}\n.ht-hist-time-tag { color: var(--ht-color-accent); margin-right: 4px; font-size: 10px; }\n\n/* Right pane: detail / tree */\n.ht-hist-detail-pane {\n  width: 60%; display: flex; flex-direction: column; overflow: hidden;\n  background: var(--ht-color-bg);\n  border-left: 2px solid transparent;\n  transition: border-color 0.15s, background 0.15s;\n}\n.ht-hist-detail-pane.focused {\n  background: var(--ht-color-bg-detail-focus);\n  border-left-color: var(--ht-color-accent);\n}\n.ht-hist-detail-pane.focused .ht-hist-detail-header {\n  background: var(--ht-color-bg-detail-focus-header);\n  color: var(--ht-color-text-detail-focus);\n}\n.ht-hist-detail-pane.focused .ht-hist-detail-content {\n  background: var(--ht-color-bg-detail-focus);\n}\n.ht-hist-detail-header {\n  padding: 5px 14px; font-size: 11px; color: var(--ht-color-text-muted);\n  background: var(--ht-color-bg-elevated); border-bottom: 1px solid var(--ht-color-border-faint);\n  font-weight: 500; display: flex; align-items: center;\n}\n.ht-hist-detail-header-text { flex: 1; }\n.ht-hist-detail-header-close {\n  display: none; cursor: pointer; color: var(--ht-color-text-muted); font-size: 14px;\n  line-height: 1; padding: 0 2px; border: none; background: none;\n  font-family: inherit;\n}\n.ht-hist-detail-header-close:hover { color: var(--ht-color-text); }\n.ht-hist-detail-content {\n  flex: 1; overflow-y: auto; padding: 16px 20px;\n  background: var(--ht-color-bg);\n}\n.ht-hist-detail-placeholder {\n  flex: 1; display: flex; align-items: center; justify-content: center;\n  color: var(--ht-color-text-faint); font-size: 14px; background: var(--ht-color-bg);\n}\n.ht-hist-no-results {\n  padding: 24px; text-align: center; color: var(--ht-color-text-muted); font-size: 12px;\n}\n\n\n/* Titlebar \u2014 left-aligned with filter indicators */\n.ht-history-container .ht-titlebar-text {\n  flex: 1; text-align: left; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n  display: flex; align-items: center; gap: 8px;\n  margin-right: 0;\n}\n.ht-hist-title-label { flex-shrink: 0; color: var(--ht-color-text-title); }\n.ht-hist-title-sep { color: var(--ht-color-text-faint); flex-shrink: 0; }\n.ht-hist-title-filters { color: var(--ht-color-text-muted); font-size: 11px; flex-shrink: 0; }\n.ht-hist-title-filter { color: var(--ht-color-text-dim); }\n.ht-hist-title-filter.active { color: var(--ht-color-accent); font-weight: 600; }\n.ht-hist-title-count { color: var(--ht-color-text-muted); font-size: 11px; margin-left: auto; flex-shrink: 0; }\n\n/* Filter pills */\n.ht-hist-filter-pills {\n  display: flex; gap: 6px; padding: 0 14px 6px; flex-wrap: wrap;\n}\n.ht-hist-filter-pill {\n  display: inline-flex; align-items: center; gap: 3px;\n  background: var(--ht-color-accent-active); color: var(--ht-color-accent);\n  font-size: 10px; font-weight: 600; padding: 2px 8px;\n  border-radius: var(--ht-radius); user-select: none;\n}\n.ht-hist-filter-pill-x {\n  cursor: pointer; opacity: 0.6; font-size: 11px;\n}\n.ht-hist-filter-pill-x:hover { opacity: 1; }\n\n/* Tree visualization in detail pane */\n.ht-hist-tree {\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  background: var(--ht-color-bg-elevated);\n  padding: 6px 0;\n  margin-bottom: 14px;\n  max-height: 160px;\n  overflow-y: auto;\n  font-size: 11px;\n  line-height: 1.6;\n}\n.ht-hist-tree-node {\n  padding: 1px 10px;\n  color: var(--ht-color-text-title);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  font-weight: 600;\n}\n.ht-hist-tree-node.active {\n  color: var(--ht-color-accent);\n  background: var(--ht-color-accent-soft);\n}\n.ht-hist-tree-entry {\n  padding: 1px 10px 1px 28px;\n  color: var(--ht-color-text-muted);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  font-size: 10px;\n}\n.ht-hist-tree-entry.active {\n  color: var(--ht-color-accent);\n  background: var(--ht-color-accent-soft-faint);\n  font-weight: 600;\n}\n.ht-hist-tree-domain {\n  color: var(--ht-color-text-faint);\n  margin-left: 4px;\n}\n.ht-hist-tree-node.tree-cursor,\n.ht-hist-tree-entry.tree-cursor {\n  background: var(--ht-color-tree-cursor-bg);\n  color: var(--ht-color-tree-cursor);\n}\n.ht-hist-tree-node.active.tree-cursor {\n  background: var(--ht-color-tree-cursor-bg-strong);\n  color: var(--ht-color-tree-cursor);\n}\n.ht-hist-tree-entry.active.tree-cursor {\n  background: var(--ht-color-tree-cursor-bg-soft);\n  color: var(--ht-color-tree-cursor);\n}\n.ht-hist-tree-collapse {\n  color: var(--ht-color-text-faint);\n  font-size: 9px;\n  margin-right: 3px;\n}\n\n/* Confirm dialog in detail pane */\n.ht-hist-confirm {\n  display: flex; flex-direction: column; align-items: center;\n  justify-content: center; height: 100%; gap: 16px; padding: 20px;\n}\n.ht-hist-confirm-icon { font-size: 28px; }\n.ht-hist-confirm-msg {\n  font-size: 13px; color: var(--ht-color-text); text-align: center;\n  line-height: 1.6; max-width: 280px;\n}\n.ht-hist-confirm-title {\n  color: var(--ht-color-text-strong); font-weight: 600;\n}\n.ht-hist-confirm-path {\n  font-size: 11px; color: var(--ht-color-text-muted); margin-top: 2px;\n}\n.ht-hist-confirm-hint {\n  font-size: 11px; color: var(--ht-color-text-faint);\n}\n\n@media (max-width: 860px), (max-height: 620px) {\n  .ht-history-container {\n    width: 96vw;\n    height: min(90vh, 760px);\n    min-height: 260px;\n  }\n  .ht-history-columns {\n    flex-direction: column;\n  }\n  .ht-hist-results-pane {\n    width: 100%;\n    height: 46%;\n    border-right: none;\n    border-bottom: 1px solid var(--ht-color-border-soft);\n  }\n  .ht-hist-detail-pane {\n    width: 100%;\n    height: 54%;\n    border-left: none;\n    border-top: 2px solid transparent;\n  }\n  .ht-hist-detail-pane.focused {\n    border-left-color: transparent;\n    border-top-color: var(--ht-color-accent);\n  }\n}\n\n@media (max-width: 520px) {\n  .ht-history-container { border-radius: 8px; }\n  .ht-history-input-wrap { padding: 8px 10px; }\n  .ht-hist-item { padding: 4px 8px; }\n  .ht-hist-detail-content { padding: 12px; }\n}\n";

  // src/lib/history/history.ts
  var ITEM_HEIGHT3 = 44;
  var POOL_BUFFER3 = 5;
  var MAX_HISTORY = 200;
  var VALID_FILTERS3 = {
    "/hour": "hour",
    "/today": "today",
    "/week": "week",
    "/month": "month"
  };
  var FILTER_RANGES = {
    hour: 60 * 60 * 1e3,
    // 1 hour
    today: 24 * 60 * 60 * 1e3,
    // 24 hours
    week: 7 * 24 * 60 * 60 * 1e3,
    // 7 days
    month: 30 * 24 * 60 * 60 * 1e3
    // 30 days
  };
  function relativeTime(ts) {
    if (!ts) return "";
    const diff = Date.now() - ts;
    const seconds = Math.floor(diff / 1e3);
    if (seconds < 60) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    const weeks = Math.floor(days / 7);
    if (weeks < 5) return `${weeks}w ago`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}mo ago`;
    const years = Math.floor(days / 365);
    return `${years}y ago`;
  }
  async function openHistoryOverlay(config) {
    try {
      let setFocusedPane2 = function(pane) {
        focusedPane = pane;
        resultsPane.classList.toggle("focused", pane === "results");
      }, close2 = function() {
        panelOpen = false;
        document.removeEventListener("keydown", keyHandler2, true);
        if (detailRafId !== null) cancelAnimationFrame(detailRafId);
        if (scrollRafId !== null) cancelAnimationFrame(scrollRafId);
        removePanelHost();
      }, parseInput2 = function(raw) {
        return parseSlashFilterQuery(raw, VALID_FILTERS3);
      }, updateTitle2 = function() {
        titleFilterSpans.forEach((span) => {
          const filter = span.dataset.filter;
          span.classList.toggle("active", activeFilters.includes(filter));
        });
        titleCount.textContent = filtered.length > 0 ? `${filtered.length} entr${filtered.length !== 1 ? "ies" : "y"}` : "";
      }, updateFilterPills2 = function() {
        if (activeFilters.length === 0) {
          filterPills.style.display = "none";
          return;
        }
        filterPills.style.display = "flex";
        filterPills.innerHTML = activeFilters.map(
          (filter) => `<span class="ht-hist-filter-pill" data-filter="${filter}">/${filter}<span class="ht-hist-filter-pill-x">\xD7</span></span>`
        ).join("");
        filterPills.querySelectorAll(".ht-hist-filter-pill-x").forEach((removeButton) => {
          removeButton.addEventListener("click", (event) => {
            event.stopPropagation();
            const pill = removeButton.parentElement;
            const filter = pill.dataset.filter;
            const tokens = input.value.trimStart().split(/\s+/);
            const remaining = tokens.filter((token) => token !== `/${filter}`);
            input.value = remaining.join(" ");
            input.dispatchEvent(new Event("input"));
            input.focus();
          });
        });
      }, buildHighlightRegex2 = function() {
        if (!currentQuery) {
          highlightRegex = null;
          return;
        }
        try {
          const terms = currentQuery.split(/\s+/).filter(Boolean);
          const pattern = terms.map((term) => `(${escapeRegex(escapeHtml(term))})`).join("|");
          highlightRegex = new RegExp(pattern, "gi");
        } catch (_) {
          highlightRegex = null;
        }
      }, highlightMatch2 = function(text) {
        const escaped = escapeHtml(text);
        if (!highlightRegex) return escaped;
        return escaped.replace(highlightRegex, "<mark>$1</mark>");
      }, getPoolItem2 = function(poolIdx) {
        if (poolIdx < itemPool.length) return itemPool[poolIdx];
        const item = document.createElement("div");
        item.className = "ht-hist-item";
        item.tabIndex = -1;
        const info = document.createElement("div");
        info.className = "ht-hist-info";
        const title = document.createElement("div");
        title.className = "ht-hist-title";
        const urlLine = document.createElement("div");
        urlLine.className = "ht-hist-url-line";
        info.appendChild(title);
        info.appendChild(urlLine);
        item.appendChild(info);
        itemPool.push(item);
        return item;
      }, bindPoolItem2 = function(item, resultIdx) {
        const entry = filtered[resultIdx];
        item.dataset.index = String(resultIdx);
        const info = item.firstElementChild;
        const titleEl = info.firstElementChild;
        titleEl.innerHTML = highlightMatch2(entry.title || "Untitled");
        const urlEl = info.lastElementChild;
        const timeStr = relativeTime(entry.lastVisitTime);
        urlEl.innerHTML = `<span class="ht-hist-time-tag">${escapeHtml(timeStr)}</span>${highlightMatch2(extractDomain(entry.url))}`;
        if (resultIdx === activeIndex) {
          item.classList.add("active");
          activeItemEl = item;
        } else {
          item.classList.remove("active");
        }
      }, renderVisibleItems2 = function() {
        withPerfTrace("history.renderVisibleItems", () => {
          const scrollTop = resultsPane.scrollTop;
          const viewHeight = resultsPane.clientHeight;
          const newStart = Math.max(0, Math.floor(scrollTop / ITEM_HEIGHT3) - POOL_BUFFER3);
          const newEnd = Math.min(
            filtered.length,
            Math.ceil((scrollTop + viewHeight) / ITEM_HEIGHT3) + POOL_BUFFER3
          );
          if (newStart === vsStart && newEnd === vsEnd) return;
          vsStart = newStart;
          vsEnd = newEnd;
          resultsList.style.top = `${vsStart * ITEM_HEIGHT3}px`;
          const count = vsEnd - vsStart;
          while (resultsList.children.length > count) {
            resultsList.removeChild(resultsList.lastChild);
          }
          activeItemEl = null;
          for (let i = 0; i < count; i++) {
            const item = getPoolItem2(i);
            bindPoolItem2(item, vsStart + i);
            if (i < resultsList.children.length) {
              if (resultsList.children[i] !== item) {
                resultsList.replaceChild(item, resultsList.children[i]);
              }
            } else {
              resultsList.appendChild(item);
            }
          }
        });
      }, renderResults2 = function() {
        buildHighlightRegex2();
        updateTitle2();
        if (filtered.length === 0) {
          resultsSentinel.style.height = "0px";
          resultsList.style.top = "0px";
          resultsList.textContent = "";
          resultsList.innerHTML = `<div class="ht-hist-no-results">${currentQuery || activeFilters.length > 0 ? "No matching history" : "No history entries"}</div>`;
          activeItemEl = null;
          vsStart = 0;
          vsEnd = 0;
          showDetailPlaceholder2(true);
          return;
        }
        resultsSentinel.style.height = `${filtered.length * ITEM_HEIGHT3}px`;
        resultsPane.scrollTop = 0;
        vsStart = -1;
        vsEnd = -1;
        renderVisibleItems2();
        scheduleDetailUpdate2();
      }, scheduleVisibleRender2 = function() {
        if (scrollRafId !== null) return;
        scrollRafId = requestAnimationFrame(() => {
          scrollRafId = null;
          if (filtered.length > 0) renderVisibleItems2();
        });
      }, setActiveIndex2 = function(newIndex) {
        if (newIndex < 0 || newIndex >= filtered.length) return;
        if (newIndex === activeIndex && activeItemEl) {
          scheduleDetailUpdate2();
          return;
        }
        if (activeItemEl) activeItemEl.classList.remove("active");
        activeIndex = newIndex;
        activeItemEl = null;
        if (newIndex >= vsStart && newIndex < vsEnd) {
          const poolIdx = newIndex - vsStart;
          const el = resultsList.children[poolIdx];
          if (el) {
            el.classList.add("active");
            activeItemEl = el;
          }
        }
        scrollActiveIntoView2();
        scheduleDetailUpdate2();
      }, scrollActiveIntoView2 = function() {
        const itemTop = activeIndex * ITEM_HEIGHT3;
        const itemBottom = itemTop + ITEM_HEIGHT3;
        const scrollTop = resultsPane.scrollTop;
        const viewHeight = resultsPane.clientHeight;
        if (itemTop < scrollTop) {
          resultsPane.scrollTop = itemTop;
        } else if (itemBottom > scrollTop + viewHeight) {
          resultsPane.scrollTop = itemBottom - viewHeight;
        }
      }, showDetailPlaceholder2 = function(show) {
        detailPlaceholder.style.display = show ? "flex" : "none";
        detailContent.style.display = show ? "none" : "block";
      }, scheduleDetailUpdate2 = function() {
        if (detailRafId !== null) return;
        detailRafId = requestAnimationFrame(() => {
          detailRafId = null;
          updateDetail2();
        });
      }, updateDetail2 = function() {
        if (detailMode === "confirmDelete") return;
        if (detailMode === "treeNav" && (pendingTreeOpenEntry || pendingTreeDeleteEntry)) return;
        renderTreeView2();
      }, scoreMatch2 = function(lowerText, rawText, lowerQuery, fuzzyRe) {
        if (lowerText === lowerQuery) return 0;
        if (lowerText.startsWith(lowerQuery)) return 1;
        if (lowerText.includes(lowerQuery)) return 2;
        if (fuzzyRe.test(rawText)) return 3;
        return -1;
      }, applyFilter2 = function() {
        withPerfTrace("history.applyFilter", () => {
          let results = allEntries;
          if (activeFilters.length > 0) {
            const now = Date.now();
            let maxRange = 0;
            for (const filter of activeFilters) {
              maxRange = Math.max(maxRange, FILTER_RANGES[filter]);
            }
            const cutoff = now - maxRange;
            results = results.filter((entry) => entry.lastVisitTime >= cutoff);
          }
          const trimmedQuery = currentQuery.trim();
          if (trimmedQuery) {
            const re = buildFuzzyPattern(trimmedQuery);
            const substringRe = new RegExp(escapeRegex(trimmedQuery), "i");
            if (re) {
              const lowerQuery = trimmedQuery.toLowerCase();
              const ranked = [];
              for (const entry of results) {
                const title = entry.title || "";
                const url = entry.url || "";
                if (!(substringRe.test(title) || substringRe.test(url) || re.test(title) || re.test(url))) {
                  continue;
                }
                const titleScore = scoreMatch2(title.toLowerCase(), title, lowerQuery, re);
                const urlScore = scoreMatch2(url.toLowerCase(), url, lowerQuery, re);
                ranked.push({
                  entry,
                  titleScore,
                  titleHit: titleScore >= 0,
                  titleLen: title.length,
                  urlScore,
                  urlHit: urlScore >= 0
                });
              }
              ranked.sort((a, b) => {
                if (a.titleHit !== b.titleHit) return a.titleHit ? -1 : 1;
                if (a.titleHit && b.titleHit) {
                  if (a.titleScore !== b.titleScore) return a.titleScore - b.titleScore;
                  return a.titleLen - b.titleLen;
                }
                if (a.urlHit !== b.urlHit) return a.urlHit ? -1 : 1;
                if (a.urlHit && b.urlHit) return a.urlScore - b.urlScore;
                return 0;
              });
              results = ranked.map((r) => r.entry);
            }
          }
          filtered = results;
          activeIndex = 0;
        });
      }, renderDeleteConfirm2 = function() {
        if (!pendingDeleteEntry) return;
        detailHeader.textContent = "Confirm Delete";
        showDetailPlaceholder2(false);
        const domain = extractDomain(pendingDeleteEntry.url);
        detailContent.innerHTML = `<div class="ht-hist-confirm">
        <div class="ht-hist-confirm-icon">\u{1F5D1}</div>
        <div class="ht-hist-confirm-msg">
          Delete this history entry?<br>
          <span class="ht-hist-confirm-title">${escapeHtml(pendingDeleteEntry.title || "Untitled")}</span>
          <div class="ht-hist-confirm-path">${escapeHtml(domain)}</div>
        </div>
        <div class="ht-hist-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, buildTimeBuckets2 = function(entries) {
        const now = Date.now();
        const DAY = 24 * 60 * 60 * 1e3;
        const buckets = [
          { label: "Today", icon: "\u{1F4C5}", entries: [] },
          { label: "Yesterday", icon: "\u{1F4C5}", entries: [] },
          { label: "This Week", icon: "\u{1F4C6}", entries: [] },
          { label: "Last Week", icon: "\u{1F4C6}", entries: [] },
          { label: "This Month", icon: "\u{1F4C5}", entries: [] },
          { label: "Older", icon: "\u{1F4C2}", entries: [] }
        ];
        for (const historyEntry of entries) {
          const age = now - historyEntry.lastVisitTime;
          if (age < DAY) buckets[0].entries.push(historyEntry);
          else if (age < 2 * DAY) buckets[1].entries.push(historyEntry);
          else if (age < 7 * DAY) buckets[2].entries.push(historyEntry);
          else if (age < 14 * DAY) buckets[3].entries.push(historyEntry);
          else if (age < 30 * DAY) buckets[4].entries.push(historyEntry);
          else buckets[5].entries.push(historyEntry);
        }
        return buckets;
      }, renderTreeView2 = function() {
        const entry = filtered[activeIndex];
        detailHeader.textContent = "Time Tree";
        showDetailPlaceholder2(false);
        const isFiltering = currentQuery.trim() !== "" || activeFilters.length > 0;
        const buckets = buildTimeBuckets2(filtered);
        const showCursor = detailMode === "treeNav";
        treeVisibleItems = [];
        let idx = 0;
        let html = '<div class="ht-hist-tree" style="max-height:none; border:none; border-radius:0; margin:0; padding:8px 0;">';
        for (const bucket of buckets) {
          if (bucket.entries.length === 0) continue;
          const bucketHasActive = entry && bucket.entries.some(
            (historyEntry) => historyEntry.url === entry.url && historyEntry.lastVisitTime === entry.lastVisitTime
          );
          const collapsed = isFiltering ? false : treeCollapsed.has(bucket.label);
          const arrow = collapsed ? "\u25B6" : "\u25BC";
          const isCursor = showCursor && idx === treeCursorIndex;
          treeVisibleItems.push({ type: "bucket", id: bucket.label });
          html += `<div class="ht-hist-tree-node${bucketHasActive ? " active" : ""}${isCursor ? " tree-cursor" : ""}" data-tree-idx="${idx}">`;
          html += `<span class="ht-hist-tree-collapse">${arrow}</span> ${bucket.icon} ${escapeHtml(bucket.label)} (${bucket.entries.length})`;
          html += "</div>";
          idx++;
          if (!collapsed) {
            for (const child of bucket.entries) {
              const isActive = entry && child.url === entry.url && child.lastVisitTime === entry.lastVisitTime;
              const domain = extractDomain(child.url);
              const title = child.title || "Untitled";
              const isCur = showCursor && idx === treeCursorIndex;
              treeVisibleItems.push({ type: "entry", id: `${child.lastVisitTime}:${child.url}` });
              html += `<div class="ht-hist-tree-entry${isActive ? " active" : ""}${isCur ? " tree-cursor" : ""}" data-tree-idx="${idx}">`;
              html += `\u{1F4C4} ${escapeHtml(title)}<span class="ht-hist-tree-domain">\xB7 ${escapeHtml(domain)}</span>`;
              html += "</div>";
              idx++;
            }
          }
        }
        html += "</div>";
        detailContent.innerHTML = html;
        if (treeCursorIndex >= treeVisibleItems.length) {
          treeCursorIndex = Math.max(0, treeVisibleItems.length - 1);
        }
        if (showCursor) {
          const cursorEl = detailContent.querySelector(".tree-cursor");
          if (cursorEl) {
            cursorEl.scrollIntoView({ block: "nearest" });
          }
        }
      }, moveTreeCursor2 = function(delta) {
        if (treeVisibleItems.length === 0) return;
        const oldIdx = treeCursorIndex;
        treeCursorIndex = Math.max(0, Math.min(treeVisibleItems.length - 1, treeCursorIndex + delta));
        if (treeCursorIndex === oldIdx) return;
        const tree = detailContent.querySelector(".ht-hist-tree");
        if (!tree) return;
        const oldEl = tree.querySelector(`[data-tree-idx="${oldIdx}"]`);
        const newEl = tree.querySelector(`[data-tree-idx="${treeCursorIndex}"]`);
        if (oldEl) oldEl.classList.remove("tree-cursor");
        if (newEl) {
          newEl.classList.add("tree-cursor");
          newEl.scrollIntoView({ block: "nearest" });
        }
      }, toggleTreeCollapse2 = function() {
        const item = treeVisibleItems[treeCursorIndex];
        if (!item || item.type !== "bucket") return;
        if (treeCollapsed.has(item.id)) {
          treeCollapsed.delete(item.id);
        } else {
          treeCollapsed.add(item.id);
        }
        renderTreeView2();
      }, renderTreeOpenConfirm2 = function() {
        if (!pendingTreeOpenEntry) return;
        detailHeader.textContent = "Open Entry";
        showDetailPlaceholder2(false);
        const domain = extractDomain(pendingTreeOpenEntry.url);
        detailContent.innerHTML = `<div class="ht-hist-confirm">
        <div class="ht-hist-confirm-icon">\u{1F517}</div>
        <div class="ht-hist-confirm-msg">
          Open <span class="ht-hist-confirm-title">&ldquo;${escapeHtml(pendingTreeOpenEntry.title || "Untitled")}&rdquo;</span>?
          ${domain ? `<div class="ht-hist-confirm-path">${escapeHtml(domain)}</div>` : ""}
        </div>
        <div class="ht-hist-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, renderTreeDeleteConfirm2 = function() {
        if (!pendingTreeDeleteEntry) return;
        detailHeader.textContent = "Confirm Delete";
        showDetailPlaceholder2(false);
        const domain = extractDomain(pendingTreeDeleteEntry.url);
        detailContent.innerHTML = `<div class="ht-hist-confirm">
        <div class="ht-hist-confirm-icon">\u{1F5D1}</div>
        <div class="ht-hist-confirm-msg">
          Delete this history entry?<br>
          <span class="ht-hist-confirm-title">${escapeHtml(pendingTreeDeleteEntry.title || "Untitled")}</span>
          <div class="ht-hist-confirm-path">${escapeHtml(domain)}</div>
        </div>
        <div class="ht-hist-confirm-hint">y / Enter confirm &middot; n / Esc cancel</div>
      </div>`;
      }, updateFooter2 = function() {
        detailHeaderClose.style.display = detailMode === "tree" ? "none" : "block";
        detailPane.classList.toggle("focused", detailMode === "treeNav");
        resultsPane.classList.toggle("dimmed", detailMode === "treeNav");
        if (detailMode === "confirmDelete") {
          footerEl.innerHTML = `<div class="ht-footer-row">
          <span>Y / ${acceptKey} confirm</span>
          <span>N / ${closeKey} cancel</span>
        </div>`;
        } else if (detailMode === "treeNav") {
          if (pendingTreeOpenEntry || pendingTreeDeleteEntry) {
            footerEl.innerHTML = `<div class="ht-footer-row">
            <span>Y / ${acceptKey} confirm</span>
            <span>N / ${closeKey} cancel</span>
          </div>`;
          } else {
            footerEl.innerHTML = `<div class="ht-footer-row">
            <span>j/k (vim) ${upKey}/${downKey} nav</span>
            <span>D del</span>
            <span>${acceptKey} fold/open</span>
            <span>${closeKey} / T back</span>
          </div>`;
          }
        } else {
          footerEl.innerHTML = `<div class="ht-footer-row">
          <span>j/k (vim) ${upKey}/${downKey} nav</span>
          <span>${switchKey} list</span>
          <span>${acceptKey} open</span>
          <span>${closeKey} close</span>
        </div>
        <div class="ht-footer-row">
          <span>T focus tree</span>
          <span>C clear</span>
          <span>D del</span>
        </div>`;
        }
      }, keyHandler2 = function(event) {
        if (!panelOpen) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (detailMode === "confirmDelete") {
          if (event.key === "y" || event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            pendingDeleteEntry = null;
            detailMode = "tree";
            removeSelectedHistory();
            updateFooter2();
            return;
          }
          if (event.key === "n" || event.key === "Escape") {
            event.preventDefault();
            event.stopPropagation();
            pendingDeleteEntry = null;
            detailMode = "tree";
            scheduleDetailUpdate2();
            updateFooter2();
            return;
          }
          event.stopPropagation();
          return;
        }
        if (detailMode === "treeNav") {
          if (pendingTreeOpenEntry) {
            if (event.key === "y" || event.key === "Enter") {
              event.preventDefault();
              event.stopPropagation();
              const entry = pendingTreeOpenEntry;
              pendingTreeOpenEntry = null;
              openHistoryEntry(entry);
              return;
            }
            if (event.key === "n" || event.key === "Escape") {
              event.preventDefault();
              event.stopPropagation();
              pendingTreeOpenEntry = null;
              renderTreeView2();
              updateFooter2();
              return;
            }
            event.stopPropagation();
            return;
          }
          if (pendingTreeDeleteEntry) {
            if (event.key === "y" || event.key === "Enter") {
              event.preventDefault();
              event.stopPropagation();
              removeTreeHistoryEntry();
              updateFooter2();
              return;
            }
            if (event.key === "n" || event.key === "Escape") {
              event.preventDefault();
              event.stopPropagation();
              pendingTreeDeleteEntry = null;
              renderTreeView2();
              updateFooter2();
              return;
            }
            event.stopPropagation();
            return;
          }
          if (event.key === "Escape" || event.key.toLowerCase() === "t") {
            event.preventDefault();
            event.stopPropagation();
            detailMode = "tree";
            scheduleDetailUpdate2();
            updateFooter2();
            return;
          }
          if (event.key.toLowerCase() === "d" && !event.ctrlKey && !event.altKey && !event.metaKey) {
            event.preventDefault();
            event.stopPropagation();
            const item = treeVisibleItems[treeCursorIndex];
            if (!item || item.type !== "entry") return;
            const sepIdx = item.id.indexOf(":");
            const ts = Number(item.id.substring(0, sepIdx));
            const url = item.id.substring(sepIdx + 1);
            const entry = filtered.find((h) => h.lastVisitTime === ts && h.url === url);
            if (!entry) return;
            pendingTreeDeleteEntry = entry;
            renderTreeDeleteConfirm2();
            updateFooter2();
            return;
          }
          if (event.key === "Enter") {
            event.preventDefault();
            event.stopPropagation();
            const item = treeVisibleItems[treeCursorIndex];
            if (!item) return;
            if (item.type === "bucket") {
              toggleTreeCollapse2();
            } else {
              const sepIdx = item.id.indexOf(":");
              const ts = Number(item.id.substring(0, sepIdx));
              const url = item.id.substring(sepIdx + 1);
              const entry = filtered.find((h) => h.lastVisitTime === ts && h.url === url);
              if (entry) {
                pendingTreeOpenEntry = entry;
                renderTreeOpenConfirm2();
                updateFooter2();
              }
            }
            return;
          }
          const vim = config.navigationMode === "vim";
          if (event.key === "ArrowDown" || vim && event.key.toLowerCase() === "j") {
            event.preventDefault();
            event.stopPropagation();
            moveTreeCursor2(1);
            return;
          }
          if (event.key === "ArrowUp" || vim && event.key.toLowerCase() === "k") {
            event.preventDefault();
            event.stopPropagation();
            moveTreeCursor2(-1);
            return;
          }
          event.stopPropagation();
          return;
        }
        if (matchesAction(event, config, "search", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        if (event.key === "Backspace" && focusedPane === "input" && input.value === "" && activeFilters.length > 0) {
          event.preventDefault();
          activeFilters.pop();
          input.value = activeFilters.map((f) => `/${f}`).join(" ") + (activeFilters.length ? " " : "");
          updateTitle2();
          updateFilterPills2();
          currentQuery = "";
          applyFilter2();
          renderResults2();
          return;
        }
        if (matchesAction(event, config, "search", "accept")) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered[activeIndex]) openHistoryEntry(filtered[activeIndex]);
          return;
        }
        if (event.key === "Tab" && !event.ctrlKey && !event.altKey && !event.metaKey) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length === 0) return;
          if (focusedPane === "input") {
            if (activeItemEl) {
              activeItemEl.focus();
            } else {
              const first = resultsList.querySelector(".ht-hist-item");
              if (first) first.focus();
            }
            setFocusedPane2("results");
          } else {
            input.focus();
            setFocusedPane2("input");
          }
          return;
        }
        const inputFocused = focusedPane === "input";
        if (event.key.toLowerCase() === "d" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          const entry = filtered[activeIndex];
          if (!entry) return;
          pendingDeleteEntry = entry;
          detailMode = "confirmDelete";
          renderDeleteConfirm2();
          updateFooter2();
          return;
        }
        if (event.key.toLowerCase() === "t" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length === 0) return;
          detailMode = "treeNav";
          treeCursorIndex = 0;
          renderTreeView2();
          const entry = filtered[activeIndex];
          if (entry) {
            const matchIdx = treeVisibleItems.findIndex(
              (item) => item.type === "entry" && item.id === `${entry.lastVisitTime}:${entry.url}`
            );
            if (matchIdx >= 0) {
              treeCursorIndex = matchIdx;
              renderTreeView2();
            }
          }
          updateFooter2();
          return;
        }
        if (event.key.toLowerCase() === "c" && !event.ctrlKey && !event.altKey && !event.metaKey && !inputFocused) {
          event.preventDefault();
          event.stopPropagation();
          input.value = "";
          activeFilters = [];
          currentQuery = "";
          updateTitle2();
          updateFilterPills2();
          applyFilter2();
          renderResults2();
          scheduleDetailUpdate2();
          return;
        }
        if (matchesAction(event, config, "search", "moveDown")) {
          const lk = event.key.toLowerCase();
          if ((lk === "j" || lk === "k") && inputFocused) return;
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length > 0) {
            setActiveIndex2(Math.min(activeIndex + 1, filtered.length - 1));
          }
          return;
        }
        if (matchesAction(event, config, "search", "moveUp")) {
          const lk = event.key.toLowerCase();
          if ((lk === "j" || lk === "k") && inputFocused) return;
          event.preventDefault();
          event.stopPropagation();
          if (filtered.length > 0) {
            setActiveIndex2(Math.max(activeIndex - 1, 0));
          }
          return;
        }
        event.stopPropagation();
      };
      var setFocusedPane = setFocusedPane2, close = close2, parseInput = parseInput2, updateTitle = updateTitle2, updateFilterPills = updateFilterPills2, buildHighlightRegex = buildHighlightRegex2, highlightMatch = highlightMatch2, getPoolItem = getPoolItem2, bindPoolItem = bindPoolItem2, renderVisibleItems = renderVisibleItems2, renderResults = renderResults2, scheduleVisibleRender = scheduleVisibleRender2, setActiveIndex = setActiveIndex2, scrollActiveIntoView = scrollActiveIntoView2, showDetailPlaceholder = showDetailPlaceholder2, scheduleDetailUpdate = scheduleDetailUpdate2, updateDetail = updateDetail2, scoreMatch = scoreMatch2, applyFilter = applyFilter2, renderDeleteConfirm = renderDeleteConfirm2, buildTimeBuckets = buildTimeBuckets2, renderTreeView = renderTreeView2, moveTreeCursor = moveTreeCursor2, toggleTreeCollapse = toggleTreeCollapse2, renderTreeOpenConfirm = renderTreeOpenConfirm2, renderTreeDeleteConfirm = renderTreeDeleteConfirm2, updateFooter = updateFooter2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      let panelOpen = true;
      const upKey = keyToDisplay(config.bindings.search.moveUp.key);
      const downKey = keyToDisplay(config.bindings.search.moveDown.key);
      const switchKey = keyToDisplay(config.bindings.search.switchPane.key);
      const acceptKey = keyToDisplay(config.bindings.search.accept.key);
      const closeKey = keyToDisplay(config.bindings.search.close.key);
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + history_default;
      shadow.appendChild(style);
      const wrapper = document.createElement("div");
      wrapper.innerHTML = `
      <div class="ht-backdrop"></div>
      <div class="ht-history-container">
        <div class="ht-titlebar">
          <div class="ht-traffic-lights">
            <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
          </div>
          <span class="ht-titlebar-text">
            <span class="ht-hist-title-label">History</span>
            <span class="ht-hist-title-sep">|</span>
            <span class="ht-hist-title-filters">Filters:
              <span class="ht-hist-title-filter" data-filter="hour">/hour</span>
              <span class="ht-hist-title-filter" data-filter="today">/today</span>
              <span class="ht-hist-title-filter" data-filter="week">/week</span>
              <span class="ht-hist-title-filter" data-filter="month">/month</span>
            </span>
            <span class="ht-hist-title-count"></span>
          </span>
          ${vimBadgeHtml(config)}
        </div>
        <div class="ht-history-body">
          <div class="ht-history-input-wrap">
            <span class="ht-history-prompt">&gt;</span>
            <input type="text" class="ht-history-input" placeholder="Filter history..." />
          </div>
          <div class="ht-hist-filter-pills"></div>
          <div class="ht-history-columns">
            <div class="ht-hist-results-pane">
              <div class="ht-hist-results-sentinel"></div>
              <div class="ht-hist-results-list"></div>
            </div>
            <div class="ht-hist-detail-pane">
              <div class="ht-hist-detail-header"><span class="ht-hist-detail-header-text">Details</span><button class="ht-hist-detail-header-close" title="Back">&times;</button></div>
              <div class="ht-hist-detail-placeholder">Select a history entry</div>
              <div class="ht-hist-detail-content" style="display:none;"></div>
            </div>
          </div>
          <div class="ht-footer">
            <div class="ht-footer-row">
              <span>j/k (vim) ${upKey}/${downKey} nav</span>
              <span>${switchKey} list</span>
              <span>${acceptKey} open</span>
              <span>${closeKey} close</span>
            </div>
            <div class="ht-footer-row">
              <span>T focus tree</span>
              <span>C clear</span>
              <span>D del</span>
            </div>
          </div>
        </div>
      </div>
    `;
      shadow.appendChild(wrapper);
      const input = shadow.querySelector(".ht-history-input");
      const resultsList = shadow.querySelector(".ht-hist-results-list");
      const resultsSentinel = shadow.querySelector(".ht-hist-results-sentinel");
      const resultsPane = shadow.querySelector(".ht-hist-results-pane");
      const detailHeader = shadow.querySelector(".ht-hist-detail-header-text");
      const detailHeaderClose = shadow.querySelector(".ht-hist-detail-header-close");
      const detailPane = shadow.querySelector(".ht-hist-detail-pane");
      const detailPlaceholder = shadow.querySelector(".ht-hist-detail-placeholder");
      const detailContent = shadow.querySelector(".ht-hist-detail-content");
      const closeBtn = shadow.querySelector(".ht-dot-close");
      const backdrop = shadow.querySelector(".ht-backdrop");
      const titleFilterSpans = shadow.querySelectorAll(".ht-hist-title-filter");
      const titleCount = shadow.querySelector(".ht-hist-title-count");
      const filterPills = shadow.querySelector(".ht-hist-filter-pills");
      const footerEl = shadow.querySelector(".ht-footer");
      let allEntries = [];
      let filtered = [];
      let activeIndex = 0;
      let activeItemEl = null;
      let focusedPane = "input";
      let activeFilters = [];
      let currentQuery = "";
      let vsStart = 0;
      let vsEnd = 0;
      let itemPool = [];
      let highlightRegex = null;
      let detailRafId = null;
      let scrollRafId = null;
      let detailMode = "tree";
      let pendingDeleteEntry = null;
      let treeCursorIndex = 0;
      let treeCollapsed = /* @__PURE__ */ new Set();
      let treeVisibleItems = [];
      let pendingTreeOpenEntry = null;
      let pendingTreeDeleteEntry = null;
      resultsPane.addEventListener("scroll", scheduleVisibleRender2, { passive: true });
      async function openHistoryEntry(entry) {
        if (!entry) return;
        close2();
        try {
          const tabs = await import_webextension_polyfill7.default.tabs.query({ currentWindow: true });
          const existing = tabs.find((t) => t.url === entry.url);
          if (existing && existing.id) {
            await import_webextension_polyfill7.default.tabs.update(existing.id, { active: true });
          } else {
            await import_webextension_polyfill7.default.tabs.create({ url: entry.url, active: true });
          }
        } catch (_) {
          await import_webextension_polyfill7.default.tabs.create({ url: entry.url, active: true });
        }
      }
      async function removeSelectedHistory() {
        const entry = filtered[activeIndex];
        if (!entry) return;
        try {
          await import_webextension_polyfill7.default.history.deleteUrl({ url: entry.url });
          showFeedback(`Removed: ${entry.title || entry.url}`);
          allEntries = allEntries.filter((e) => e.url !== entry.url);
          applyFilter2();
          renderResults2();
        } catch (_) {
          showFeedback("Failed to remove history entry");
        }
      }
      async function removeTreeHistoryEntry() {
        if (!pendingTreeDeleteEntry) return;
        const entry = pendingTreeDeleteEntry;
        pendingTreeDeleteEntry = null;
        try {
          await import_webextension_polyfill7.default.history.deleteUrl({ url: entry.url });
          showFeedback(`Removed: ${entry.title || entry.url}`);
          allEntries = allEntries.filter((e) => e.url !== entry.url);
          applyFilter2();
          renderTreeView2();
        } catch (_) {
          showFeedback("Failed to remove history entry");
          renderTreeView2();
        }
      }
      closeBtn.addEventListener("click", close2);
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      detailHeaderClose.addEventListener("click", () => {
        if (detailMode !== "tree") {
          detailMode = "tree";
          pendingDeleteEntry = null;
          pendingTreeOpenEntry = null;
          pendingTreeDeleteEntry = null;
          scheduleDetailUpdate2();
          updateFooter2();
        }
      });
      resultsList.addEventListener("click", (event) => {
        const item = event.target.closest(".ht-hist-item");
        if (!item || !item.dataset.index) return;
        setActiveIndex2(Number(item.dataset.index));
      });
      resultsList.addEventListener("dblclick", (event) => {
        const item = event.target.closest(".ht-hist-item");
        if (!item || !item.dataset.index) return;
        const idx = Number(item.dataset.index);
        activeIndex = idx;
        if (filtered[idx]) openHistoryEntry(filtered[idx]);
      });
      input.addEventListener("focus", () => {
        setFocusedPane2("input");
      });
      resultsList.addEventListener("focus", () => {
        setFocusedPane2("results");
      }, true);
      resultsPane.addEventListener("wheel", (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (filtered.length === 0) return;
        if (event.deltaY > 0) {
          setActiveIndex2(Math.min(activeIndex + 1, filtered.length - 1));
        } else {
          setActiveIndex2(Math.max(activeIndex - 1, 0));
        }
      });
      detailContent.addEventListener("click", (event) => {
        if (detailMode !== "tree" && detailMode !== "treeNav") return;
        const target = event.target.closest("[data-tree-idx]");
        if (!target) return;
        const idx = Number(target.dataset.treeIdx);
        if (isNaN(idx) || idx < 0 || idx >= treeVisibleItems.length) return;
        const item = treeVisibleItems[idx];
        if (item.type === "bucket") {
          if (detailMode === "treeNav") treeCursorIndex = idx;
          toggleTreeCollapse2();
        } else if (detailMode === "treeNav") {
          const oldIdx = treeCursorIndex;
          treeCursorIndex = idx;
          const tree = detailContent.querySelector(".ht-hist-tree");
          if (tree) {
            const oldEl = tree.querySelector(`[data-tree-idx="${oldIdx}"]`);
            const newEl = tree.querySelector(`[data-tree-idx="${idx}"]`);
            if (oldEl) oldEl.classList.remove("tree-cursor");
            if (newEl) {
              newEl.classList.add("tree-cursor");
              newEl.scrollIntoView({ block: "nearest" });
            }
          }
        }
      });
      detailContent.addEventListener("dblclick", (event) => {
        if (detailMode !== "treeNav") return;
        const target = event.target.closest("[data-tree-idx]");
        if (!target) return;
        const idx = Number(target.dataset.treeIdx);
        if (isNaN(idx) || idx < 0 || idx >= treeVisibleItems.length) return;
        const item = treeVisibleItems[idx];
        if (item.type !== "entry") return;
        treeCursorIndex = idx;
        const sepIdx = item.id.indexOf(":");
        const ts = Number(item.id.substring(0, sepIdx));
        const url = item.id.substring(sepIdx + 1);
        const entry = filtered.find((h) => h.lastVisitTime === ts && h.url === url);
        if (entry) {
          pendingTreeOpenEntry = entry;
          renderTreeOpenConfirm2();
          updateFooter2();
        }
      });
      detailContent.addEventListener("wheel", (event) => {
        if (detailMode !== "treeNav") return;
        event.preventDefault();
        event.stopPropagation();
        moveTreeCursor2(event.deltaY > 0 ? 1 : -1);
      });
      input.addEventListener("input", () => {
        const { filters, query } = parseInput2(input.value);
        activeFilters = filters;
        currentQuery = query;
        updateTitle2();
        updateFilterPills2();
        applyFilter2();
        renderResults2();
      });
      allEntries = await import_webextension_polyfill7.default.runtime.sendMessage({
        type: "HISTORY_LIST",
        maxResults: MAX_HISTORY
      });
      filtered = [...allEntries];
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      renderResults2();
      input.focus();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open history overlay:", err);
    }
  }

  // src/lib/help/help.css
  var help_default = ".ht-help-container {\n  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n  width: min(94vw, 680px); max-height: min(88vh, 760px); background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border); border-radius: var(--ht-radius);\n  display: flex; flex-direction: column; overflow: hidden;\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  overscroll-behavior: contain;\n}\n.ht-help-titlebar-text {\n  flex: 1; text-align: left; font-size: 12px; color: var(--ht-color-text);\n  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;\n}\n.ht-help-title-label { color: var(--ht-color-text-title); }\n.ht-help-body {\n  flex: 1; overflow-y: auto; padding: 8px 0;\n  scroll-behavior: auto;\n}\n.ht-help-section { margin-bottom: 4px; }\n.ht-help-header {\n  display: flex; align-items: center; padding: 6px 20px;\n  font-size: 11px; font-weight: 700; text-transform: uppercase;\n  letter-spacing: 0.8px; color: var(--ht-color-accent);\n  user-select: none;\n}\n.ht-help-items { overflow: hidden; }\n.ht-help-row {\n  display: flex; align-items: center; justify-content: space-between;\n  padding: 4px 20px 4px 38px; font-size: 12px; cursor: default;\n}\n.ht-help-label { color: var(--ht-color-text-soft); }\n.ht-help-key {\n  font-size: 11px; color: var(--ht-color-text); background: var(--ht-color-surface);\n  padding: 2px 8px; border-radius: 4px; font-weight: 600;\n  white-space: nowrap; flex-shrink: 0; margin-left: 12px;\n}\n.ht-help-tip {\n  font-size: 11px; color: var(--ht-color-text-muted); padding: 10px 20px;\n  border-top: 1px solid var(--ht-color-border-soft);\n  text-align: center; line-height: 1.6;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-help-container { border-radius: 8px; }\n  .ht-help-row { padding: 4px 10px 4px 12px; font-size: 11px; }\n  .ht-help-header { padding: 6px 10px; }\n  .ht-help-key { margin-left: 8px; padding: 2px 6px; }\n}\n";

  // src/lib/help/help.ts
  var SCROLL_STEP = 80;
  function buildSections(config) {
    const g = config.bindings.global;
    const h = config.bindings.tabManager;
    const s = config.bindings.search;
    const k = (b) => keyToDisplay(b.key);
    return [
      {
        title: "Open Panels",
        items: [
          { label: "Search Current Page", key: k(g.searchInPage) },
          { label: "Search Open Tabs", key: k(g.openFrecency) },
          { label: "Tab Manager", key: k(g.openTabManager) },
          { label: "Bookmarks", key: k(g.openBookmarks) },
          { label: "History", key: k(g.openHistory) },
          { label: "Help (this menu)", key: k(g.openHelp) }
        ]
      },
      {
        title: "Vim Mode (optional)",
        items: [
          { label: "Toggle vim mode", key: k(g.toggleVim) },
          { label: "Adds j / k for up / down", key: "in all panels" }
        ]
      },
      {
        title: "Inside Any Panel",
        items: [
          { label: "Navigate up / down", key: `${k(s.moveUp)} / ${k(s.moveDown)}` },
          { label: "Switch input and results", key: k(s.switchPane) },
          { label: "Open / jump to selection", key: k(s.accept) },
          { label: "Close panel", key: k(s.close) },
          { label: "Click item to select or open", key: "mouse" },
          { label: "Scroll wheel to navigate", key: "mouse" }
        ]
      },
      {
        title: "Tab Manager Panel",
        items: [
          { label: "Add current tab to Tab Manager", key: k(g.addTab) },
          { label: "Jump to slot 1 \u2014 4", key: `${k(g.jumpSlot1)} \u2014 ${k(g.jumpSlot4)}` },
          { label: "Cycle prev / next slot", key: `${k(g.cyclePrev)} / ${k(g.cycleNext)}` },
          { label: "Swap mode", key: k(h.swap).toLowerCase() },
          { label: "Del entry", key: k(h.remove).toLowerCase() },
          { label: "Undo remove", key: "u" },
          { label: "Save session", key: k(h.saveSession).toLowerCase() },
          { label: "Load session", key: k(h.loadSession).toLowerCase() },
          { label: "Rename session (in session list)", key: "r" },
          { label: "Overwrite session (in session list)", key: "o" }
        ]
      },
      {
        title: "Bookmarks Panel",
        items: [
          { label: "Add bookmark", key: k(g.addBookmark) },
          { label: "Focus tree", key: "t" },
          { label: "Clear search", key: "c" },
          { label: "Del bookmark", key: "d" },
          { label: "Move to folder", key: "m" }
        ]
      },
      {
        title: "History Panel",
        items: [
          { label: "Focus tree", key: "t" },
          { label: "Clear search", key: "c" },
          { label: "Del entry", key: "d" }
        ]
      },
      {
        title: "Search Current Page",
        items: [
          { label: "Clear search", key: "c" }
        ]
      },
      {
        title: "Search Open Tabs",
        items: [
          { label: "Clear search", key: "c" }
        ]
      },
      {
        title: "Search Filters \u2014 type in search input",
        items: [
          { label: "Code blocks (<pre>, <code>)", key: "/code" },
          { label: "Headings (<h1>-<h6>)", key: "/headings" },
          { label: "Images (<img> alt text)", key: "/img" },
          { label: "Links (<a> elements)", key: "/links" },
          { label: "Combine filters (union)", key: "/code /links" },
          { label: "Bookmark: folder path", key: "/folder" },
          { label: "History: last hour", key: "/hour" },
          { label: "History: today", key: "/today" },
          { label: "History: last 7 days", key: "/week" },
          { label: "History: last 30 days", key: "/month" }
        ]
      }
    ];
  }
  function openHelpOverlay(config) {
    try {
      let close2 = function() {
        document.removeEventListener("keydown", keyHandler2, true);
        removePanelHost();
      }, keyHandler2 = function(event) {
        if (!document.getElementById("ht-panel-host")) {
          document.removeEventListener("keydown", keyHandler2, true);
          return;
        }
        if (matchesAction(event, config, "search", "close")) {
          event.preventDefault();
          event.stopPropagation();
          close2();
          return;
        }
        const isDown = matchesAction(event, config, "search", "moveDown");
        const isUp = matchesAction(event, config, "search", "moveUp");
        if (isDown) {
          event.preventDefault();
          event.stopPropagation();
          body.scrollTop += SCROLL_STEP;
          return;
        }
        if (isUp) {
          event.preventDefault();
          event.stopPropagation();
          body.scrollTop -= SCROLL_STEP;
          return;
        }
        event.stopPropagation();
      };
      var close = close2, keyHandler = keyHandler2;
      const { host, shadow } = createPanelHost();
      const closeKey = keyToDisplay(config.bindings.search.close.key);
      const style = document.createElement("style");
      style.textContent = getBaseStyles() + help_default;
      shadow.appendChild(style);
      const backdrop = document.createElement("div");
      backdrop.className = "ht-backdrop";
      shadow.appendChild(backdrop);
      const panel = document.createElement("div");
      panel.className = "ht-help-container";
      shadow.appendChild(panel);
      const titlebar = document.createElement("div");
      titlebar.className = "ht-titlebar";
      titlebar.innerHTML = `
      <div class="ht-traffic-lights">
        <button class="ht-dot ht-dot-close" title="Close (Esc)"></button>
      </div>
      <span class="ht-help-titlebar-text">
        <span class="ht-help-title-label">Help</span>
      </span>
      ${vimBadgeHtml(config)}`;
      panel.appendChild(titlebar);
      const body = document.createElement("div");
      body.className = "ht-help-body";
      panel.appendChild(body);
      const footer = document.createElement("div");
      footer.className = "ht-footer";
      footer.innerHTML = `<div class="ht-footer-row">
      <span>j/k (vim) \u2191/\u2193 scroll</span>
      <span>wheel scroll</span>
      <span>${closeKey} close</span>
    </div>`;
      panel.appendChild(footer);
      const sections = buildSections(config);
      for (const section of sections) {
        const sectionEl = document.createElement("div");
        sectionEl.className = "ht-help-section";
        const header = document.createElement("div");
        header.className = "ht-help-header";
        const titleSpan = document.createElement("span");
        titleSpan.textContent = section.title;
        header.appendChild(titleSpan);
        sectionEl.appendChild(header);
        const itemsEl = document.createElement("div");
        itemsEl.className = "ht-help-items";
        for (const item of section.items) {
          const row = document.createElement("div");
          row.className = "ht-help-row";
          const label = document.createElement("span");
          label.className = "ht-help-label";
          label.textContent = item.label;
          const key = document.createElement("span");
          key.className = "ht-help-key";
          key.textContent = item.key;
          row.appendChild(label);
          row.appendChild(key);
          itemsEl.appendChild(row);
        }
        sectionEl.appendChild(itemsEl);
        body.appendChild(sectionEl);
      }
      const tip = document.createElement("div");
      tip.className = "ht-help-tip";
      tip.innerHTML = "Keybindings Can Be <strong>Customized</strong> In The <strong>Extension Options Page</strong>";
      body.appendChild(tip);
      backdrop.addEventListener("click", close2);
      backdrop.addEventListener("mousedown", (event) => event.preventDefault());
      titlebar.querySelector(".ht-dot-close").addEventListener("click", close2);
      document.addEventListener("keydown", keyHandler2, true);
      registerPanelCleanup(close2);
      host.focus();
    } catch (err) {
      console.error("[Harpoon Telescope] Failed to open help overlay:", err);
    }
  }

  // src/lib/appInit/appInit.ts
  function initApp() {
    if (window.__harpoonTelescopeCleanup) {
      window.__harpoonTelescopeCleanup();
    }
    let cachedConfig = null;
    import_webextension_polyfill8.default.runtime.sendMessage({ type: "GET_KEYBINDINGS" }).then((loadedConfig) => {
      cachedConfig = loadedConfig;
    }).catch(() => {
    });
    async function getConfig() {
      if (cachedConfig) return cachedConfig;
      cachedConfig = await import_webextension_polyfill8.default.runtime.sendMessage({
        type: "GET_KEYBINDINGS"
      });
      return cachedConfig;
    }
    import_webextension_polyfill8.default.storage.onChanged.addListener((changes) => {
      if (changes.keybindings) {
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "GET_KEYBINDINGS" }).then((loadedConfig) => {
          cachedConfig = loadedConfig;
        }).catch(() => {
        });
      }
    });
    let panelDebounce = 0;
    const PANEL_DEBOUNCE_MS = 50;
    function openPanel(fn) {
      const now = Date.now();
      if (now - panelDebounce < PANEL_DEBOUNCE_MS) return;
      panelDebounce = now;
      try {
        fn();
      } catch (err) {
        console.error("[Harpoon Telescope] panel open failed:", err);
        showFeedback("Panel failed to open");
      }
    }
    function globalKeyHandler(event) {
      if (!cachedConfig) return;
      const config = cachedConfig;
      if (matchesAction(event, config, "global", "toggleVim")) {
        event.preventDefault();
        event.stopImmediatePropagation();
        config.navigationMode = config.navigationMode === "vim" ? "basic" : "vim";
        saveKeybindings(config);
        showFeedback(config.navigationMode === "vim" ? "Vim motions ON" : "Vim motions OFF");
        const panelHost = document.getElementById("ht-panel-host");
        if (panelHost?.shadowRoot) {
          const badge = panelHost.shadowRoot.querySelector(".ht-vim-badge");
          if (badge) {
            badge.classList.toggle("on", config.navigationMode === "vim");
            badge.classList.toggle("off", config.navigationMode !== "vim");
          }
        }
        return;
      }
      if (document.getElementById("ht-panel-host")) return;
      if (matchesAction(event, config, "global", "openTabManager")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openTabManager(config));
      } else if (matchesAction(event, config, "global", "addTab")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_ADD" });
      } else if (matchesAction(event, config, "global", "jumpSlot1")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_JUMP", slot: 1 });
      } else if (matchesAction(event, config, "global", "jumpSlot2")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_JUMP", slot: 2 });
      } else if (matchesAction(event, config, "global", "jumpSlot3")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_JUMP", slot: 3 });
      } else if (matchesAction(event, config, "global", "jumpSlot4")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_JUMP", slot: 4 });
      } else if (matchesAction(event, config, "global", "cyclePrev")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_CYCLE", direction: "prev" });
      } else if (matchesAction(event, config, "global", "cycleNext")) {
        event.preventDefault();
        event.stopPropagation();
        import_webextension_polyfill8.default.runtime.sendMessage({ type: "TAB_MANAGER_CYCLE", direction: "next" });
      } else if (matchesAction(event, config, "global", "searchInPage")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openSearchCurrentPage(config));
      } else if (matchesAction(event, config, "global", "openFrecency")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openSearchOpenTabs(config));
      } else if (matchesAction(event, config, "global", "openBookmarks")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openBookmarkOverlay(config));
      } else if (matchesAction(event, config, "global", "addBookmark")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openAddBookmarkOverlay(config));
      } else if (matchesAction(event, config, "global", "openHistory")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openHistoryOverlay(config));
      } else if (matchesAction(event, config, "global", "openHelp")) {
        event.preventDefault();
        event.stopPropagation();
        openPanel(() => openHelpOverlay(config));
      }
    }
    document.addEventListener("keydown", globalKeyHandler, true);
    function messageHandler(message) {
      const receivedMessage = message;
      switch (receivedMessage.type) {
        case "GET_SCROLL":
          return Promise.resolve({
            scrollX: window.scrollX,
            scrollY: window.scrollY
          });
        case "SET_SCROLL":
          window.scrollTo(receivedMessage.scrollX, receivedMessage.scrollY);
          return Promise.resolve({ ok: true });
        case "GREP":
          return Promise.resolve(
            grepPage(
              receivedMessage.query,
              receivedMessage.filters || []
            )
          );
        case "GET_CONTENT":
          return Promise.resolve(getPageContent());
        case "OPEN_SEARCH_CURRENT_PAGE":
          if (!document.getElementById("ht-panel-host"))
            getConfig().then((config) => openPanel(() => openSearchCurrentPage(config))).catch(() => showFeedback("Panel failed to open"));
          return Promise.resolve({ ok: true });
        case "OPEN_TAB_MANAGER":
          if (!document.getElementById("ht-panel-host"))
            getConfig().then((config) => openPanel(() => openTabManager(config))).catch(() => showFeedback("Panel failed to open"));
          return Promise.resolve({ ok: true });
        case "OPEN_FRECENCY":
          if (!document.getElementById("ht-panel-host"))
            getConfig().then((config) => openPanel(() => openSearchOpenTabs(config))).catch(() => showFeedback("Panel failed to open"));
          return Promise.resolve({ ok: true });
        case "OPEN_BOOKMARKS":
          if (!document.getElementById("ht-panel-host"))
            getConfig().then((config) => openPanel(() => openBookmarkOverlay(config))).catch(() => showFeedback("Panel failed to open"));
          return Promise.resolve({ ok: true });
        case "OPEN_HISTORY":
          if (!document.getElementById("ht-panel-host"))
            getConfig().then((config) => openPanel(() => openHistoryOverlay(config))).catch(() => showFeedback("Panel failed to open"));
          return Promise.resolve({ ok: true });
        case "SHOW_SESSION_RESTORE":
          if (!document.getElementById("ht-panel-host"))
            openSessionRestoreOverlay();
          return Promise.resolve({ ok: true });
        case "SCROLL_TO_TEXT":
          scrollToText(receivedMessage.text);
          return Promise.resolve({ ok: true });
        case "TAB_MANAGER_ADDED_FEEDBACK":
          showFeedback(
            receivedMessage.alreadyAdded ? `Already in Tab Manager [${receivedMessage.slot}]` : `Added to Tab Manager [${receivedMessage.slot}]`
          );
          return Promise.resolve({ ok: true });
        case "TAB_MANAGER_FULL_FEEDBACK":
          showFeedback(`Tab Manager is full (${receivedMessage.max}/${receivedMessage.max})`);
          return Promise.resolve({ ok: true });
      }
    }
    import_webextension_polyfill8.default.runtime.onMessage.addListener(messageHandler);
    import_webextension_polyfill8.default.runtime.sendMessage({ type: "CONTENT_SCRIPT_READY" }).catch(() => {
    });
    function visibilityHandler() {
      if (document.visibilityState === "hidden") {
        dismissPanel();
      }
    }
    document.addEventListener("visibilitychange", visibilityHandler);
    window.__harpoonTelescopeCleanup = () => {
      document.removeEventListener("keydown", globalKeyHandler, true);
      document.removeEventListener("visibilitychange", visibilityHandler);
      import_webextension_polyfill8.default.runtime.onMessage.removeListener(messageHandler);
      const host = document.getElementById("ht-panel-host");
      if (host) host.remove();
      const toast = document.getElementById("ht-feedback-toast");
      if (toast) toast.remove();
    };
  }

  // src/entrypoints/content-script/content-script.ts
  initApp();
})();
