// Content script entry point — runs on every page.
// Delegates all logic to the app init layer.

import { initApp } from "../../lib/appInit/appInit";

initApp();
